#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

let passes = 0;
let failures = 0;

function check(description, condition) {
  if (condition) {
    console.log(`✓ ${description}`);
    passes++;
  } else {
    console.log(`✗ ${description}`);
    failures++;
  }
}

function fail(description, error) {
  console.log(`✗ ${description}`);
  if (error) console.log(`  Error: ${error}`);
  failures++;
}

// Read answer file
let answer;
try {
  const content = fs.readFileSync('retrieval-answer.json', 'utf8');
  answer = JSON.parse(content);
  check('JSON parses successfully', true);
} catch (e) {
  fail('JSON parses successfully', e.message);
  process.exit(1);
}

// CHECK 1: JSON structure and literal fields
const requiredFields = ['questionId', 'snapshotId', 'snapshotSha256', 'status', 'facts'];
check('Has all required top-level fields', requiredFields.every(f => f in answer));
check('questionId is "northstar-01"', answer.questionId === 'northstar-01');
check('snapshotId is "northstar-v1"', answer.snapshotId === 'northstar-v1');
check('snapshotSha256 is "31d63c88fa2aac63a8220091713f04c30b50a29a40019b4839b21e72d289654c"',
      answer.snapshotSha256 === '31d63c88fa2aac63a8220091713f04c30b50a29a40019b4839b21e72d289654c');

// CHECK 2: status and facts consistency
check('status is "answered" or "not_found"', ['answered', 'not_found'].includes(answer.status));
const factsIsEmpty = Array.isArray(answer.facts) && answer.facts.length === 0;
const shouldBeEmpty = answer.status === 'not_found';
check('facts is [] iff status is "not_found"', factsIsEmpty === shouldBeEmpty);

// CHECK 3: answered-state fact structure
if (answer.status === 'answered') {
  check('facts is a non-empty array', Array.isArray(answer.facts) && answer.facts.length > 0);
  
  if (Array.isArray(answer.facts) && answer.facts.length > 0) {
    const fact = answer.facts[0];
    check('fact has key "annual-price-cents"', fact.key === 'annual-price-cents');
    check('value is a JSON number (not string)', typeof fact.value === 'number');
    check('value is 19000', fact.value === 19000);
    check('citations is a non-empty array', Array.isArray(fact.citations) && fact.citations.length > 0);
    
    // CHECK 4 & 5: Citation validation
    if (Array.isArray(fact.citations)) {
      fact.citations.forEach((citation, idx) => {
        const citPath = citation.path;
        console.log(`\nValidating citation ${idx + 1}: ${citPath}`);
        
        // Check not CORPUS.json or executable
        check(`Citation ${idx + 1} is not CORPUS.json`, citPath !== 'CORPUS.json');
        const execPattern = /\.(exe|bin|sh|bat|cmd)$/i;
        check(`Citation ${idx + 1} is not executable`, !execPattern.test(citPath));
        
        // Check path exists
        if (!fs.existsSync(citPath)) {
          fail(`Citation ${idx + 1} path exists (${citPath})`);
          return;
        }
        check(`Citation ${idx + 1} path exists`, true);
        
        // Compute SHA-256
        const fileContent = fs.readFileSync(citPath, 'utf8');
        const actualSha256 = crypto.createHash('sha256').update(fileContent).digest('hex');
        check(`Citation ${idx + 1} SHA-256 matches (${citation.sha256.slice(0, 8)}...)`,
              actualSha256 === citation.sha256);
        
        if (actualSha256 !== citation.sha256) {
          console.log(`  Expected: ${citation.sha256}`);
          console.log(`  Got:      ${actualSha256}`);
        }
        
        // Validate line range
        const lines = fileContent.split('\n');
        const startLine = citation.startLine;
        const endLine = citation.endLine;
        
        check(`Citation ${idx + 1} startLine >= 1`, startLine >= 1);
        check(`Citation ${idx + 1} endLine >= startLine`, endLine >= startLine);
        check(`Citation ${idx + 1} endLine <= total lines (${lines.length})`, endLine <= lines.length);
        check(`Citation ${idx + 1} span <= 16 lines`, endLine - startLine + 1 <= 16);
        
        // Extract and verify quote
        // Lines are 1-based, so convert to 0-based array indices
        let extractedLines = [];
        for (let i = startLine - 1; i < endLine && i < lines.length; i++) {
          extractedLines.push(lines[i]);
        }
        
        // Reconstruct with newlines (all lines get a newline except possibly the last)
        let reconstructedQuote = '';
        for (let i = 0; i < extractedLines.length; i++) {
          reconstructedQuote += extractedLines[i];
          // Add newline after each line, including the last one if the original file has it
          const fileLineIndex = startLine - 1 + i;
          if (fileLineIndex < lines.length - 1 || 
              (fileLineIndex === lines.length - 1 && fileContent.endsWith('\n'))) {
            reconstructedQuote += '\n';
          }
        }
        
        const expectedQuote = citation.quote;
        check(`Citation ${idx + 1} quote byte-identical`,
              reconstructedQuote === expectedQuote);
        
        if (reconstructedQuote !== expectedQuote) {
          console.log(`  Expected bytes: ${JSON.stringify(expectedQuote)}`);
          console.log(`  Got bytes:      ${JSON.stringify(reconstructedQuote)}`);
        }
      });
    }
  }
}

console.log(`\n${'='.repeat(60)}`);
console.log(`Passed: ${passes} | Failed: ${failures}`);
if (failures === 0) {
  console.log('RESULT: PASS');
  process.exit(0);
} else {
  console.log('RESULT: FAIL');
  process.exit(1);
}
