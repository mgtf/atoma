#!/usr/bin/env node

const fs = require('fs');
const crypto = require('crypto');
const path = require('path');

// ANSI color codes for output
const RED = '\x1b[31m';
const GREEN = '\x1b[32m';
const YELLOW = '\x1b[33m';
const RESET = '\x1b[0m';

let assertions_passed = 0;
let assertions_failed = 0;

function pass(msg) {
  console.log(`${GREEN}✓${RESET} ${msg}`);
  assertions_passed++;
}

function fail(msg) {
  console.log(`${RED}✗${RESET} ${msg}`);
  assertions_failed++;
}

function info(msg) {
  console.log(`${YELLOW}ℹ${RESET} ${msg}`);
}

function computeSha256(filePath) {
  const content = fs.readFileSync(filePath);
  return crypto.createHash('sha256').update(content).digest('hex');
}

function extractLineRange(filePath, startLine, endLine) {
  const content = fs.readFileSync(filePath, 'utf8');
  const lines = content.split('\n');
  
  // Lines are 1-based in the citation
  const startIdx = startLine - 1;
  const endIdx = endLine - 1;
  
  if (startIdx < 0 || endIdx >= lines.length) {
    return null;
  }
  
  // Extract the lines and join with newline, then add final newline
  const extracted = lines.slice(startIdx, endIdx + 1).join('\n');
  return extracted + '\n';
}

function main() {
  console.log('=== Verification of retrieval-answer.json ===\n');
  
  // (a) Parse JSON and validate structure
  let data;
  try {
    const rawContent = fs.readFileSync('retrieval-answer.json', 'utf8');
    data = JSON.parse(rawContent);
    pass('JSON is valid');
  } catch (e) {
    fail(`JSON parsing failed: ${e.message}`);
    process.exit(1);
  }
  
  // Check exact field set
  const expectedFields = ['questionId', 'snapshotId', 'snapshotSha256', 'status', 'facts'];
  const actualFields = Object.keys(data).sort();
  const expectedFieldsSorted = expectedFields.sort();
  
  if (JSON.stringify(actualFields) === JSON.stringify(expectedFieldsSorted)) {
    pass(`Exact field set present: ${expectedFields.join(', ')}`);
  } else {
    fail(`Field set mismatch. Expected: ${expectedFieldsSorted}, Got: ${actualFields}`);
  }
  
  // Check specific field values
  if (data.questionId === 'northstar-05') {
    pass('questionId = "northstar-05"');
  } else {
    fail(`questionId incorrect: ${data.questionId}`);
  }
  
  if (data.snapshotId === 'northstar-v1') {
    pass('snapshotId = "northstar-v1"');
  } else {
    fail(`snapshotId incorrect: ${data.snapshotId}`);
  }
  
  if (data.snapshotSha256 === '31d63c88fa2aac63a8220091713f04c30b50a29a40019b4839b21e72d289654c') {
    pass('snapshotSha256 matches expected value');
  } else {
    fail(`snapshotSha256 incorrect: ${data.snapshotSha256}`);
  }
  
  // (b) Validate status enum
  if (data.status === 'answered' || data.status === 'not_found') {
    pass(`status = "${data.status}" (valid enum)`);
  } else {
    fail(`status invalid: ${data.status} (must be "answered" or "not_found")`);
  }
  
  // (c) If answered, validate facts structure
  if (data.status === 'answered') {
    if (!Array.isArray(data.facts)) {
      fail('facts is not an array');
      process.exit(1);
    }
    
    if (data.facts.length !== 1) {
      fail(`facts array has ${data.facts.length} entries (expected 1)`);
      process.exit(1);
    }
    
    const fact = data.facts[0];
    
    if (fact.key !== 'refund-days') {
      fail(`fact.key is "${fact.key}" (expected "refund-days")`);
    } else {
      pass('fact.key = "refund-days"');
    }
    
    if (typeof fact.value !== 'number') {
      fail(`fact.value is not a number: ${typeof fact.value}`);
    } else {
      pass(`fact.value is a number: ${fact.value}`);
      info(`EXTRACTED VALUE: refund-days = ${fact.value}`);
    }
    
    if (!Array.isArray(fact.citations) || fact.citations.length === 0) {
      fail(`fact.citations is not a non-empty array`);
      process.exit(1);
    } else {
      pass(`fact.citations is a non-empty array (${fact.citations.length} citation(s))`);
    }
    
    // (d) Validate each citation
    for (let i = 0; i < fact.citations.length; i++) {
      const citation = fact.citations[i];
      info(`\nValidating citation ${i + 1}:`);
      
      // Check path exists
      if (!fs.existsSync(citation.path)) {
        fail(`  Citation path does not exist: ${citation.path}`);
        continue;
      }
      pass(`  Path exists: ${citation.path}`);
      
      // Compute sha256 of file
      const computedSha256 = computeSha256(citation.path);
      if (computedSha256 !== citation.sha256) {
        fail(`  SHA256 mismatch for ${citation.path}`);
        fail(`    Expected: ${citation.sha256}`);
        fail(`    Computed: ${computedSha256}`);
        continue;
      }
      pass(`  SHA256 matches: ${computedSha256}`);
      
      // Validate line range
      const { startLine, endLine } = citation;
      const lineCount = endLine - startLine + 1;
      
      if (!Number.isInteger(startLine) || !Number.isInteger(endLine)) {
        fail(`  Line numbers are not integers: startLine=${startLine}, endLine=${endLine}`);
        continue;
      }
      pass(`  Line numbers are integers: startLine=${startLine}, endLine=${endLine}`);
      
      if (startLine < 1) {
        fail(`  startLine is not 1-based: ${startLine}`);
        continue;
      }
      
      if (startLine > endLine) {
        fail(`  startLine > endLine: ${startLine} > ${endLine}`);
        continue;
      }
      pass(`  Line range is 1-based inclusive: ${startLine}-${endLine}`);
      
      if (lineCount > 16) {
        fail(`  Line span exceeds 16 lines: ${lineCount} lines`);
        continue;
      }
      pass(`  Line span is ≤16 lines: ${lineCount} line(s)`);
      
      // Extract bytes and compare with quote
      const extracted = extractLineRange(citation.path, startLine, endLine);
      if (extracted === null) {
        fail(`  Could not extract line range ${startLine}-${endLine}`);
        continue;
      }
      
      if (extracted !== citation.quote) {
        fail(`  Quote does not match extracted bytes`);
        fail(`    Expected: ${JSON.stringify(citation.quote)}`);
        fail(`    Extracted: ${JSON.stringify(extracted)}`);
        continue;
      }
      pass(`  Quote matches exact file bytes (with trailing newline)`);
      
      // (e) Check not CORPUS.json or executable
      if (citation.path === 'CORPUS.json') {
        fail(`  Citation points to CORPUS.json (forbidden)`);
        continue;
      }
      
      // Check if path is executable
      try {
        const stats = fs.statSync(citation.path);
        const isExecutable = (stats.mode & parseInt('0111', 8)) !== 0;
        if (isExecutable) {
          fail(`  Citation points to an executable asset (forbidden)`);
          continue;
        }
      } catch (e) {
        fail(`  Could not check if path is executable: ${e.message}`);
        continue;
      }
      pass(`  Citation does not point to CORPUS.json or executable`);
    }
  }
  
  console.log(`\n=== Summary ===`);
  console.log(`Assertions passed: ${assertions_passed}`);
  console.log(`Assertions failed: ${assertions_failed}`);
  
  if (assertions_failed > 0) {
    process.exit(1);
  } else {
    process.exit(0);
  }
}

main();
