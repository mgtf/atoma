import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';

const ans = JSON.parse(readFileSync('retrieval-answer.json', 'utf8'));
const corpus = JSON.parse(readFileSync('CORPUS.json', 'utf8'));
const byPath = new Map(corpus.documents.map((d) => [d.path, d.sha256]));
let failures = 0;
const fail = (m) => { failures++; console.log('FAIL ' + m); };

if (ans.snapshotSha256 !== corpus.snapshotSha256) fail('snapshotSha256 mismatch');
if (ans.snapshotId !== corpus.snapshotId) fail('snapshotId mismatch');
if (Object.keys(ans).join(',') !== 'questionId,snapshotId,snapshotSha256,status,facts') fail('field set: ' + Object.keys(ans));

const want = [
  ['annual-price-cents', 'number'],
  ['monthly-price-cents', 'number'],
  ['refund-days', 'number'],
];
if (ans.facts.length !== want.length) fail('fact count ' + ans.facts.length);
for (const [i, [key, type]] of want.entries()) {
  const f = ans.facts[i];
  if (!f || f.key !== key) { fail('missing fact ' + key); continue; }
  if (typeof f.value !== type) fail(`${key}: valueType ${typeof f.value} != ${type}`);
  if (!Array.isArray(f.citations) || f.citations.length === 0) { fail(key + ': no citations'); continue; }
  for (const c of f.citations) {
    const declared = byPath.get(c.path);
    if (!declared) { fail(`${key}: ${c.path} not a corpus document`); continue; }
    if (/CORPUS\.json|\.mjs$/.test(c.path)) fail(`${key}: forbidden source ${c.path}`);
    const bytes = readFileSync(c.path);
    const actual = createHash('sha256').update(bytes).digest('hex');
    if (actual !== declared) fail(`${c.path}: file digest drifted`);
    if (c.sha256 !== declared) fail(`${key}: cited sha256 != corpus digest for ${c.path}`);
    const lines = bytes.toString('utf8').split('\n');
    const total = lines[lines.length - 1] === '' ? lines.length - 1 : lines.length;
    if (!(c.startLine >= 1 && c.endLine >= c.startLine && c.endLine <= total)) fail(`${key}: bad range ${c.startLine}-${c.endLine} (file has ${total})`);
    if (c.endLine - c.startLine + 1 > 16) fail(`${key}: >16 lines cited`);
    let exact = '';
    for (let n = c.startLine; n <= c.endLine; n++) exact += lines[n - 1] + (n < total || lines[lines.length - 1] === '' ? '\n' : '');
    if (c.quote !== exact) fail(`${key}: quote not byte-exact for ${c.path}:${c.startLine}-${c.endLine}\n  got: ${JSON.stringify(c.quote)}\n  exp: ${JSON.stringify(exact)}`);
    const num = String(f.value);
    if (!exact.includes(num)) fail(`${key}: value ${num} absent from quoted evidence`);
  }
}

// Config invariants: annual enabled, everything else preserved.
const p = JSON.parse(readFileSync('pricing.json', 'utf8'));
const expect = { currency: 'EUR', monthlyCents: 1900, annualCents: 19000, refundWindowDays: 14 };
for (const [k, v] of Object.entries(expect)) if (p[k] !== v) fail(`pricing.json ${k} = ${JSON.stringify(p[k])} != ${JSON.stringify(v)}`);
if (Object.keys(p).length !== 4) fail('pricing.json extra/missing keys: ' + Object.keys(p));
const byFact = Object.fromEntries(ans.facts.map((f) => [f.key, f.value]));
if (p.annualCents !== byFact['annual-price-cents']) fail('pricing.json annualCents disagrees with answer');
if (p.monthlyCents !== byFact['monthly-price-cents']) fail('pricing.json monthlyCents disagrees with answer');
if (p.refundWindowDays !== byFact['refund-days']) fail('pricing.json refundWindowDays disagrees with answer');

console.log(failures === 0 ? 'OK all citations byte-exact and config consistent' : `${failures} failure(s)`);
process.exit(failures === 0 ? 0 : 1);
