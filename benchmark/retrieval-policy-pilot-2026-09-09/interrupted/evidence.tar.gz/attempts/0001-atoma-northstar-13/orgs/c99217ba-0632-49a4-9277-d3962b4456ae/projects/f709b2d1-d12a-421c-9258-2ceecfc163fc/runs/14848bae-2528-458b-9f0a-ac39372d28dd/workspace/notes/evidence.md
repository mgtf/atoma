# Pricing Facts Evidence

## Fact 1: annual-price-cents

**Document**: docs/billing.md  
**SHA-256**: 98efd32bfe73a29b17086fc9be347ae3acfa5b5f061d1b17561295a85fe51e9b  
**Lines**: 3-4 (1-based inclusive)  
**Value Type**: number  
**Value**: 19000

**Byte-exact quote**:
```
The annual subscription costs 19000 euro cents per seat for twelve months.
```

**Context**: This fact appears in the "Accepted offers" section of the billing policy document and establishes the required annual price for the annual subscription offer.

---

## Fact 2: monthly-price-cents

**Document**: docs/billing.md  
**SHA-256**: 98efd32bfe73a29b17086fc9be347ae3acfa5b5f061d1b17561295a85fe51e9b  
**Lines**: 3-3 (1-based inclusive)  
**Value Type**: number  
**Value**: 1900

**Byte-exact quote**:
```
The monthly subscription costs 1900 euro cents per seat.
```

**Context**: This fact appears in the "Accepted offers" section and establishes the current monthly price already configured in pricing.json.

---

## Fact 3: refund-days

**Document**: docs/billing.md  
**SHA-256**: 98efd32bfe73a29b17086fc9be347ae3acfa5b5f061d1b17561295a85fe51e9b  
**Lines**: 8-8 (1-based inclusive)  
**Value Type**: number  
**Value**: 14

**Byte-exact quote**:
```
The refund request window is 14 calendar days after the initial payment.
```

**Context**: This fact appears in the "Cancellation and refunds" section and establishes the refund window already configured in pricing.json.

---

## preview.mjs Validation Logic

The preview.mjs script validates pricing.json with the following requirements:

- `monthlyCents`: Must be a non-negative integer
- `annualCents`: Must be either null or a non-negative integer (null indicates the offer is not enabled)
- `refundWindowDays`: Must be a non-negative integer
- `currency`: Must be a string

The script outputs a JSON structure showing quote calculations for monthly and annual offers at 1 and 3 seat counts. When `annualCents` is null, the annual quotes show `"available": false`.

---

## Related Documentation

**Configuration key for annual offer**: From docs/billing.md line 5, the annual offer uses the configuration key `stripe_price_annual_studio`.

**Enabling the annual offer**: Based on preview.mjs validation logic and pricing.json structure, the annual offer is enabled by setting the `annualCents` field to the documented annual price (19000) instead of null. The monthly price (1900) and refund window (14) are already correctly configured in pricing.json.
