// Self-check: validates retrieval-answer.json against CORPUS.json and the documents on disk.
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';

const sha = (b) => createHash('sha256').update(b).digest('hex');
const corpus = JSON.parse(readFileSync('CORPUS.json', 'utf8'));
const ans = JSON.parse(readFileSync('retrieval-answer.json', 'utf8'));
const byPath = new Map(corpus.documents.map((d) => [d.path, d]));
const failures = [];
const ck = (cond, msg) => { if (!cond) failures.push(msg); };

ck(ans.questionId === 'northstar-13', 'questionId');
ck(ans.snapshotId === corpus.snapshotId, 'snapshotId matches CORPUS');
ck(ans.snapshotSha256 === corpus.snapshotSha256, 'snapshotSha256 matches CORPUS');
ck(['answered', 'not_found'].includes(ans.status), 'status enum');
ck(Object.keys(ans).length === 5, 'exactly 5 top-level fields');

const wanted = [
  ['annual-price-cents', 'number'],
  ['monthly-price-cents', 'number'],
  ['refund-days', 'number'],
];
ck(ans.facts.length === wanted.length, 'fact count');
for (const [i, [key, vt]] of wanted.entries()) {
  const f = ans.facts[i];
  ck(f && f.key === key, `fact ${i} key is ${key}`);
  ck(f && typeof f.value === vt, `${key} valueType ${vt}`);
  ck(f && Array.isArray(f.citations) && f.citations.length > 0, `${key} has citations`);
  for (const c of f?.citations ?? []) {
    const doc = byPath.get(c.path);
    ck(!!doc, `${key}: ${c.path} declared in CORPUS`);
    ck(!/CORPUS\.json$/.test(c.path) && !/\.mjs$/.test(c.path), `${key}: ${c.path} is not corpus/executable`);
    if (!doc) continue;
    const raw = readFileSync(c.path);
    ck(sha(raw) === doc.sha256, `${c.path} on-disk digest matches CORPUS`);
    ck(c.sha256 === doc.sha256, `${key}: citation sha256 matches CORPUS for ${c.path}`);
    ck(c.endLine - c.startLine + 1 <= 16, `${key}: <=16 lines cited`);
    // Rebuild the exact byte span for [startLine, endLine], keeping final newlines.
    const text = raw.toString('utf8');
    const lines = text.split('\n');
    const total = text.endsWith('\n') ? lines.length - 1 : lines.length;
    ck(c.startLine >= 1 && c.endLine >= c.startLine && c.endLine <= total, `${key}: line range in bounds`);
    let span = '';
    for (let n = c.startLine; n <= c.endLine; n++) {
      span += lines[n - 1] + (n < total || text.endsWith('\n') ? '\n' : '');
    }
    ck(c.quote === span, `${key}: quote is byte-exact for ${c.path}:${c.startLine}-${c.endLine}`);
    ck(text.includes(c.quote), `${key}: quote occurs in ${c.path}`);
  }
}

// The answer's numbers must agree with the enabled configuration.
const cfg = JSON.parse(readFileSync('pricing.json', 'utf8'));
const val = (k) => ans.facts.find((f) => f.key === k)?.value;
ck(cfg.annualCents === val('annual-price-cents'), 'pricing.annualCents == annual-price-cents');
ck(cfg.monthlyCents === val('monthly-price-cents'), 'pricing.monthlyCents == monthly-price-cents');
ck(cfg.refundWindowDays === val('refund-days'), 'pricing.refundWindowDays == refund-days');
ck(cfg.currency === 'EUR', 'currency preserved as EUR');
ck(Object.keys(cfg).length === 4, 'pricing.json keys unchanged');

console.log(failures.length ? 'FAIL\n' + failures.join('\n') : `PASS: ${wanted.length} facts, all citations byte-exact and digest-verified`);
process.exit(failures.length ? 1 : 0);
