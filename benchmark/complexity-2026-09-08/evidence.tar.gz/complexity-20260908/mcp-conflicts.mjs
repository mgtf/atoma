import {CreateTaskResultSchema,CallToolResultSchema} from '@modelcontextprotocol/sdk/types.js';
import {Client} from '@modelcontextprotocol/sdk/client/index.js';
import {StreamableHTTPClientTransport} from '@modelcontextprotocol/sdk/client/streamableHttp.js';
import {readFileSync,writeFileSync} from 'node:fs';
const token=readFileSync('/private/tmp/atoma-complexity-mcp-token.txt','utf8').split('\n').find(l=>l.startsWith('atoma_'));
if(!token)throw Error('Missing MCP token');
const client=new Client({name:'atoma-complexity-campaign',version:'1.0'},{capabilities:{tasks:{requests:{tools:{call:{}}}}}});
const transport=new StreamableHTTPClientTransport(new URL('http://127.0.0.1:5173/mcp'),{requestInit:{headers:{Authorization:`Bearer ${token}`}}});
await client.connect(transport);
console.log('Connected',JSON.stringify(client.getServerVersion()));
const saved=JSON.parse(readFileSync('runs/complexity-20260908/mcp-inventory-1-request.json'));
const args={projectId:saved.projectId,goal:saved.goal,idempotencyKey:saved.idempotencyKey};
const task=await client.request({method:'tools/call',params:{name:'atoma_run_start',arguments:args,task:{ttl:3600000}}},CreateTaskResultSchema);
console.log('Repeated request task',JSON.stringify(task));
console.log('Repeated request status',JSON.stringify(await client.experimental.tasks.getTask(task.task.taskId)));
if(task.task.status==='failed')console.log('Duplicate task result',JSON.stringify(await client.experimental.tasks.getTaskResult(task.task.taskId,CallToolResultSchema)));
for (const variant of [{...args,goal:args.goal+' Different input.'},{...args,idempotencyKey:args.idempotencyKey+'-concurrent'}]) {
 const refused=await client.request({method:'tools/call',params:{name:'atoma_run_start',arguments:variant,task:{}}},CreateTaskResultSchema);
 console.log('Conflict task',JSON.stringify(refused));
 if(refused.task.status==='failed') console.log('Conflict result',JSON.stringify(await client.experimental.tasks.getTaskResult(refused.task.taskId,CallToolResultSchema)));
}
console.log('Project run resource',JSON.stringify(await client.readResource({uri:'atoma://projects/c864fc74-9cd5-4532-8a48-6281439306b4/runs/a3ec503e-89b9-4326-94e2-2723a774aa48'})));
await client.close();
