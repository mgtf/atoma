import {mkdtempSync,writeFileSync} from 'node:fs';
import assert from 'node:assert/strict';
import {ToolSandbox} from '/app/dist/tools/sandbox.js';
import {startStaticServerTool,validateHtmlTool} from '/app/dist/tools/builtin.js';
const root=mkdtempSync('/tmp/scroll-proof-');
writeFileSync(root+'/index.html',`<input id="name" value="old"><div style="height:1800px"></div><input id="quantity" type="number" value="0"><div style="height:1800px"></div><button id="save" onclick="document.getElementById('result').textContent=document.getElementById('quantity').value">Save</button><p id="result"></p>`);
const sandbox=new ToolSandbox(root);
try {
 const server=await startStaticServerTool({sandbox}).execute({});assert(server.ok);
 const result=await validateHtmlTool({sandbox}).execute({url:server.url,interactions:[{type:'type',selector:'#name',text:'preserved'},{type:'type',selector:'#quantity',text:'375'},{type:'click',selector:'#save'}],smoke:'(() => ({ok: document.getElementById("result").textContent === "375" && document.getElementById("name").value === "preserved", quantity:document.getElementById("quantity").value, name:document.getElementById("name").value}))()'});
 console.log(JSON.stringify(result,null,2));assert(result.ok);assert.equal(result.smokeResult.quantity,'375');assert.equal(result.smokeResult.name,'preserved');
}finally{await sandbox.cleanup();}
