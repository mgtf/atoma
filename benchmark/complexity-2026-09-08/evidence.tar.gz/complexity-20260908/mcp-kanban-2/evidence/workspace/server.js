const http = require('http');
const fs = require('fs');
const path = require('path');

const DATA_FILE = path.join(__dirname, 'data.json');

// Load tasks from disk on startup
let tasks = [];
function loadTasks() {
  try {
    if (fs.existsSync(DATA_FILE)) {
      const data = fs.readFileSync(DATA_FILE, 'utf8');
      tasks = JSON.parse(data);
    }
  } catch (err) {
    console.error('Error loading tasks:', err.message);
    tasks = [];
  }
}

// Save tasks to disk
function saveTasks() {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(tasks, null, 2));
  } catch (err) {
    console.error('Error saving tasks:', err.message);
  }
}

// Generate unique ID
function generateId() {
  if (tasks.length === 0) return 1;
  const numericIds = tasks
    .map(t => {
      if (typeof t.id === 'number') return t.id;
      if (typeof t.id === 'string') {
        const num = parseInt(t.id, 10);
        return isNaN(num) ? 0 : num;
      }
      return 0;
    })
    .filter(id => id > 0);
  return (numericIds.length > 0 ? Math.max(...numericIds) : 0) + 1;
}

// Validate enum values
function isValidStatus(status) {
  return ['todo', 'doing', 'done'].includes(status);
}

function isValidPriority(priority) {
  return ['low', 'medium', 'high'].includes(priority);
}

// Parse request body
function parseBody(req, callback) {
  let body = '';
  req.on('data', chunk => {
    body += chunk.toString();
  });
  req.on('end', () => {
    try {
      if (body.trim() === '') {
        callback(null, {});
      } else {
        callback(null, JSON.parse(body));
      }
    } catch (err) {
      callback(new Error('Malformed JSON'));
    }
  });
}

// Serve static file
function serveFile(filePath, contentType, res) {
  try {
    const content = fs.readFileSync(filePath, 'utf8');
    res.writeHead(200, { 'Content-Type': contentType });
    res.end(content);
  } catch (err) {
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end('Not Found');
  }
}

const server = http.createServer((req, res) => {
  const parsedUrl = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = parsedUrl.pathname;

  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PATCH, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.writeHead(200);
    res.end();
    return;
  }

  // Static files
  if (pathname === '/' || pathname === '/index.html') {
    serveFile(path.join(__dirname, 'index.html'), 'text/html', res);
    return;
  }

  if (pathname === '/app.js') {
    serveFile(path.join(__dirname, 'app.js'), 'application/javascript', res);
    return;
  }

  if (pathname === '/style.css') {
    serveFile(path.join(__dirname, 'style.css'), 'text/css', res);
    return;
  }

  // API routes
  if (pathname === '/api/tasks' && req.method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(tasks));
    return;
  }

  if (pathname === '/api/tasks' && req.method === 'POST') {
    parseBody(req, (err, data) => {
      if (err) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Malformed JSON' }));
        return;
      }

      // Validate required fields
      const title = data.title;
      const status = data.status;
      const priority = data.priority;

      if (!title || typeof title !== 'string' || title.trim() === '') {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'title is required and must be a non-empty string' }));
        return;
      }

      if (!status || !isValidStatus(status)) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'status must be one of: todo, doing, done' }));
        return;
      }

      if (!priority || !isValidPriority(priority)) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'priority must be one of: low, medium, high' }));
        return;
      }

      // Create task
      const newTask = {
        id: generateId(),
        title: title.trim(),
        status,
        priority
      };

      tasks.push(newTask);
      saveTasks();

      res.writeHead(201, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(newTask));
    });
    return;
  }

  // PATCH /api/tasks/:id
  const patchMatch = pathname.match(/^\/api\/tasks\/(\d+)$/);
  if (patchMatch && req.method === 'PATCH') {
    const id = parseInt(patchMatch[1], 10);
    parseBody(req, (err, data) => {
      if (err) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Malformed JSON' }));
        return;
      }

      const task = tasks.find(t => t.id === id);
      if (!task) {
        res.writeHead(404, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Task not found' }));
        return;
      }

      // Validate and update supplied fields
      if (data.hasOwnProperty('title')) {
        if (!data.title || typeof data.title !== 'string' || data.title.trim() === '') {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'title must be a non-empty string' }));
          return;
        }
        task.title = data.title.trim();
      }

      if (data.hasOwnProperty('status')) {
        if (!isValidStatus(data.status)) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'status must be one of: todo, doing, done' }));
          return;
        }
        task.status = data.status;
      }

      if (data.hasOwnProperty('priority')) {
        if (!isValidPriority(data.priority)) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'priority must be one of: low, medium, high' }));
          return;
        }
        task.priority = data.priority;
      }

      saveTasks();

      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(task));
    });
    return;
  }

  // DELETE /api/tasks/:id
  const deleteMatch = pathname.match(/^\/api\/tasks\/(\d+)$/);
  if (deleteMatch && req.method === 'DELETE') {
    const id = parseInt(deleteMatch[1], 10);
    const index = tasks.findIndex(t => t.id === id);
    if (index === -1) {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Task not found' }));
      return;
    }

    tasks.splice(index, 1);
    saveTasks();

    res.writeHead(204);
    res.end();
    return;
  }

  // 404
  res.writeHead(404, { 'Content-Type': 'text/plain' });
  res.end('Not Found');
});

// Load tasks on startup
loadTasks();

// Start server
const port = Number(process.env.PORT) || 0;
server.listen(port, '0.0.0.0', () => {
  const boundPort = server.address().port;
  console.log('LISTENING_ON_PORT=' + boundPort);
});
