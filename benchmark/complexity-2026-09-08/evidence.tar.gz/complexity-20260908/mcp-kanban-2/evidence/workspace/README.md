# Kanban Task Manager

A polished, lightweight Kanban board web application built with Node.js built-ins only—no external dependencies. Organize your tasks across three workflow states: **To Do**, **Doing**, and **Done**, with priority levels and persistent data storage.

## Overview

This is a full-stack web application that:
- Runs on Node.js using only built-in modules (`http`, `fs`, `path`)
- Provides a responsive Kanban interface with three task columns
- Supports task creation, updating, deletion, and filtering
- Persists all data to a JSON file on disk
- Includes comprehensive REST API for programmatic access
- Features real-time UI updates with no page reloads required

## File Layout

```
.
├── server.js          # HTTP server entry point (Node.js built-ins only)
├── index.html         # Kanban board UI markup
├── app.js             # Client-side CRUD logic and DOM rendering
├── style.css          # Responsive grid layout and component styling
├── data.json          # Persistent task storage (auto-created on first run)
└── README.md          # This file
```

### File Descriptions

- **server.js** (168 lines)
  - HTTP server using Node's `http` module
  - Static file serving (HTML, CSS, JS)
  - REST API endpoints for task CRUD operations
  - JSON request parsing with error handling
  - Automatic task persistence to `data.json`
  - CORS headers for cross-origin requests

- **index.html** (87 lines)
  - Semantic HTML5 structure
  - Form with fields: title (text), status (select), priority (select)
  - Search input and priority filter dropdown
  - Three Kanban columns with task lists and empty states
  - Column count badges that update in real time

- **app.js** (222 lines)
  - Global task state management
  - Fetch-based API client (GET, POST, PATCH, DELETE)
  - Task filtering by search term and priority
  - Real-time DOM rendering with status dropdowns
  - Error handling and display
  - Event listeners for form submission, status changes, deletion

- **style.css** (305 lines)
  - Responsive CSS Grid layout (3-column on desktop, 1-column on mobile)
  - Gradient background (purple 667eea → 764ba2)
  - Flexbox for card layout and spacing
  - Breakpoints: 1024px and 768px for responsive scaling
  - Priority color coding: green (low), orange (medium), red (high)
  - Hover effects on task cards and buttons
  - Accessibility: sr-only class for screen readers

- **data.json** (auto-created)
  - JSON array of task objects
  - Format: `[{ id, title, status, priority }, ...]`
  - Persisted to disk on every POST/PATCH/DELETE operation
  - Loaded into memory on server startup

## Getting Started

### Prerequisites

- Node.js 16+ installed

### Starting the Server

```bash
node server.js
```

**Output:**
```
LISTENING_ON_PORT=3000
```

The port is dynamically assigned. Set `PORT` environment variable to use a specific port:

```bash
PORT=8080 node server.js
```

**Server Configuration:**
- Binds to `0.0.0.0` (all network interfaces)
- Uses port from `PORT` env var, or auto-assigns if omitted (default: 0 = OS picks)
- Prints `LISTENING_ON_PORT=<port>` to stdout on success
- CORS enabled for all origins

### Accessing the Application

Once the server starts, visit:
```
http://localhost:<port>
```

Replace `<port>` with the value printed by `LISTENING_ON_PORT=`.

## API Reference

All API endpoints accept and return JSON. The server respects the `Content-Type: application/json` header.

### GET /api/tasks

Retrieve all tasks.

**Request:**
```http
GET /api/tasks HTTP/1.1
```

**Response (200 OK):**
```json
[
  {
    "id": 2402,
    "title": "Write documentation",
    "status": "todo",
    "priority": "high"
  },
  {
    "id": 2404,
    "title": "Persistence Test",
    "status": "doing",
    "priority": "high"
  }
]
```

**Status Codes:**
- `200 OK` - Array of tasks (may be empty `[]`)

### POST /api/tasks

Create a new task.

**Request:**
```http
POST /api/tasks HTTP/1.1
Content-Type: application/json

{
  "title": "Buy groceries",
  "status": "todo",
  "priority": "medium"
}
```

**Response (201 Created):**
```json
{
  "id": 2405,
  "title": "Buy groceries",
  "status": "todo",
  "priority": "medium"
}
```

**Request Fields:**
| Field | Type | Required | Enum Values | Validation |
|-------|------|----------|-------------|-----------|
| `title` | string | Yes | — | Non-empty, non-whitespace-only |
| `status` | string | Yes | `todo`, `doing`, `done` | Must be one of enum values |
| `priority` | string | Yes | `low`, `medium`, `high` | Must be one of enum values |

**Status Codes:**
- `201 Created` - Task created successfully; body contains new task with assigned `id`
- `400 Bad Request` - Validation failure (see table below)

**Error Responses (400 Bad Request):**
```json
{
  "error": "title is required and must be a non-empty string"
}
```
```json
{
  "error": "status must be one of: todo, doing, done"
}
```
```json
{
  "error": "priority must be one of: low, medium, high"
}
```
```json
{
  "error": "Malformed JSON"
}
```

### PATCH /api/tasks/:id

Update an existing task. Supply only the fields you want to change.

**Request:**
```http
PATCH /api/tasks/2405 HTTP/1.1
Content-Type: application/json

{
  "status": "doing"
}
```

**Response (200 OK):**
```json
{
  "id": 2405,
  "title": "Buy groceries",
  "status": "doing",
  "priority": "medium"
}
```

**Request Fields (all optional):**
| Field | Type | Enum Values | Validation |
|-------|------|-------------|-----------|
| `title` | string | — | Non-empty, non-whitespace-only if provided |
| `status` | string | `todo`, `doing`, `done` | Must be one of enum values if provided |
| `priority` | string | `low`, `medium`, `high` | Must be one of enum values if provided |

**Status Codes:**
- `200 OK` - Task updated; body contains updated full task object
- `400 Bad Request` - Validation failure (invalid enum, blank title, malformed JSON)
- `404 Not Found` - Task with given `id` does not exist

**Error Responses:**
```json
{
  "error": "title must be a non-empty string"
}
```
```json
{
  "error": "status must be one of: todo, doing, done"
}
```
```json
{
  "error": "priority must be one of: low, medium, high"
}
```
```json
{
  "error": "Task not found"
}
```

### DELETE /api/tasks/:id

Delete a task.

**Request:**
```http
DELETE /api/tasks/2405 HTTP/1.1
```

**Response (204 No Content):**
```http
HTTP/1.1 204 No Content
```

**Status Codes:**
- `204 No Content` - Task deleted successfully; no response body
- `404 Not Found` - Task with given `id` does not exist

**Error Response (404):**
```json
{
  "error": "Task not found"
}
```

## Enum Values

### Status
- `todo` - Task is in the To Do column (backlog)
- `doing` - Task is in the Doing column (in progress)
- `done` - Task is in the Done column (completed)

### Priority
- `low` - Low priority (green indicator)
- `medium` - Medium priority (orange indicator)
- `high` - High priority (red indicator)

## Data Persistence

All tasks are persisted automatically to **`data.json`** in the same directory as `server.js`.

- Tasks are loaded from `data.json` on server startup
- Tasks are saved to `data.json` after every POST, PATCH, or DELETE operation
- If `data.json` doesn't exist, it is created with an empty array on first run
- The file is formatted with 2-space indentation for readability and debugging

**File Format:**
```json
[
  {
    "id": 2402,
    "title": "Write documentation",
    "status": "todo",
    "priority": "high"
  }
]
```

## Browser UI Features

The web interface (served at `/`) includes:

- **Form Section**: Add new tasks with title, status, and priority fields
- **Filters Section**: Search by task title; filter by priority level
- **Kanban Board**: Three responsive columns (To Do, Doing, Done)
- **Column Counts**: Real-time badge showing task count per column
- **Empty States**: "No tasks yet" message for empty columns
- **Task Cards**: Display title, priority badge, status dropdown, delete button
- **Error Display**: Inline error messages from API validation
- **Responsive Layout**:
  - Desktop (>1024px): 3 columns, form in 4-column grid
  - Tablet (1024px–768px): 3 columns, form in 2-column grid
  - Mobile (<768px): 1 column, form in 1-column grid

## Testing the API

### Using curl

Create a task:
```bash
curl -X POST http://localhost:3000/api/tasks \
  -H "Content-Type: application/json" \
  -d '{"title":"Test task","status":"todo","priority":"high"}'
```

Get all tasks:
```bash
curl http://localhost:3000/api/tasks
```

Update a task:
```bash
curl -X PATCH http://localhost:3000/api/tasks/2402 \
  -H "Content-Type: application/json" \
  -d '{"status":"doing"}'
```

Delete a task:
```bash
curl -X DELETE http://localhost:3000/api/tasks/2402
```

## Implementation Notes

- **No Dependencies**: Uses only Node.js built-in modules (`http`, `fs`, `path`)
- **Task IDs**: Auto-generated numeric IDs starting from 1, incremented per task
- **Concurrency**: Single-threaded Node.js; file writes are synchronous (suitable for small-to-medium data sets)
- **CORS**: All origins allowed; suitable for development (restrict in production via `Access-Control-Allow-Origin`)
- **Error Handling**: Malformed JSON returns 400 with `"error": "Malformed JSON"`; missing or invalid enum fields return descriptive 400 errors
- **Validation**: Server validates all inputs; client-side validation is decorative only
- **Performance**: File I/O is synchronous; data is kept in memory during runtime
