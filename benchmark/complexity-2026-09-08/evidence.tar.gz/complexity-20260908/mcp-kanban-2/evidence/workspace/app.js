// Global app state
let allTasks = [];

// Fetch all tasks from API
async function loadTasks() {
  try {
    const response = await fetch('/api/tasks');
    if (!response.ok) throw new Error('Failed to load tasks');
    allTasks = await response.json();
    renderFiltered();
  } catch (err) {
    console.error('Error loading tasks:', err);
  }
}

// Get filter values
function getFilters() {
  const searchTerm = document.getElementById('search-title').value.toLowerCase();
  const priorityFilter = document.getElementById('filter-priority').value;
  return { searchTerm, priorityFilter };
}

// Filter tasks based on search and priority
function filterTasks() {
  const { searchTerm, priorityFilter } = getFilters();
  
  return allTasks.filter(task => {
    const matchesSearch = task.title.toLowerCase().includes(searchTerm);
    const matchesPriority = !priorityFilter || task.priority === priorityFilter;
    return matchesSearch && matchesPriority;
  });
}

// Render filtered tasks in columns
function renderFiltered() {
  const filteredTasks = filterTasks();
  renderTasks(filteredTasks, false);
}

// Render tasks in columns
function renderTasks(tasks, updateCounts = true) {
  const columns = {
    todo: document.getElementById('todo'),
    doing: document.getElementById('doing'),
    done: document.getElementById('done')
  };

  const emptyStates = {
    todo: document.getElementById('empty-todo'),
    doing: document.getElementById('empty-doing'),
    done: document.getElementById('empty-done')
  };

  const counts = {
    todo: document.getElementById('count-todo'),
    doing: document.getElementById('count-doing'),
    done: document.getElementById('count-done')
  };

  // Clear columns
  Object.values(columns).forEach(col => col.innerHTML = '');

  // Count tasks per column for filtered view
  const filteredCounts = { todo: 0, doing: 0, done: 0 };
  
  // Count all tasks per column for accurate empty state detection
  const allCounts = { todo: 0, doing: 0, done: 0 };
  allTasks.forEach(task => {
    allCounts[task.status]++;
  });

  // Render each task in its column
  tasks.forEach(task => {
    filteredCounts[task.status]++;
    const taskEl = document.createElement('div');
    taskEl.className = 'task-card';
    taskEl.innerHTML = `
      <div class="task-header">
        <h4>${escapeHtml(task.title)}</h4>
        <button class="delete-btn" data-id="${task.id}" aria-label="Delete task">×</button>
      </div>
      <div class="task-meta">
        <span class="priority priority-${task.priority}">${task.priority}</span>
      </div>
      <div class="task-controls">
        <label for="status-${task.id}" class="sr-only">Change status</label>
        <select class="status-select" id="status-${task.id}" data-id="${task.id}" data-current="${task.status}">
          <option value="todo" ${task.status === 'todo' ? 'selected' : ''}>To Do</option>
          <option value="doing" ${task.status === 'doing' ? 'selected' : ''}>Doing</option>
          <option value="done" ${task.status === 'done' ? 'selected' : ''}>Done</option>
        </select>
      </div>
    `;

    // Delete button handler
    taskEl.querySelector('.delete-btn').addEventListener('click', () => {
      deleteTask(task.id);
    });

    // Status change handler
    taskEl.querySelector('.status-select').addEventListener('change', (e) => {
      updateTask(task.id, { status: e.target.value });
    });

    columns[task.status].appendChild(taskEl);
  });

  // Update counts and empty states based on all tasks, not filtered
  ['todo', 'doing', 'done'].forEach(status => {
    counts[status].textContent = allCounts[status];
    if (allCounts[status] === 0) {
      emptyStates[status].style.display = 'block';
    } else {
      emptyStates[status].style.display = 'none';
    }
  });
}

// Escape HTML to prevent XSS
function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// Create a new task
async function createTask(title, status, priority) {
  try {
    const response = await fetch('/api/tasks', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title, status, priority })
    });

    if (!response.ok) {
      const error = await response.json();
      showError(error.error || 'Failed to create task');
      return;
    }

    clearError();
    document.getElementById('taskForm').reset();
    loadTasks();
  } catch (err) {
    showError('Error creating task: ' + err.message);
  }
}

// Update a task
async function updateTask(id, updates) {
  try {
    const response = await fetch(`/api/tasks/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates)
    });

    if (!response.ok) {
      const error = await response.json();
      showError(error.error || 'Failed to update task');
      loadTasks(); // Reload to undo UI change
      return;
    }

    clearError();
    loadTasks();
  } catch (err) {
    showError('Error updating task: ' + err.message);
    loadTasks();
  }
}

// Delete a task
async function deleteTask(id) {
  try {
    const response = await fetch(`/api/tasks/${id}`, {
      method: 'DELETE'
    });

    if (!response.ok) {
      const error = await response.json();
      showError(error.error || 'Failed to delete task');
      return;
    }

    clearError();
    loadTasks();
  } catch (err) {
    showError('Error deleting task: ' + err.message);
  }
}

// Show error message
function showError(msg) {
  document.getElementById('error').textContent = msg;
}

// Clear error message
function clearError() {
  document.getElementById('error').textContent = '';
}

// Form submission
document.getElementById('taskForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const title = document.getElementById('task-title').value;
  const status = document.getElementById('task-status').value;
  const priority = document.getElementById('task-priority').value;
  createTask(title, status, priority);
});

// Search and filter listeners
document.getElementById('search-title').addEventListener('input', () => {
  renderFiltered();
});

document.getElementById('filter-priority').addEventListener('change', () => {
  renderFiltered();
});

// Initial load
loadTasks();
