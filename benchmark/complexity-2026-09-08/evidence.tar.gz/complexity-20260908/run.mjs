import { mkdirSync, writeFileSync, cpSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { execFileSync } from 'node:child_process';
import Database from 'better-sqlite3';
import { startTask } from '../../dist/run/runner.js';
import { buildProfile } from '../../dist/run/profiles/build.js';
import { acquireRunLeaseWithoutRecovery } from '../../dist/mcp/runLock.js';
const root = resolve('runs/complexity-20260908');
const id = process.argv[2];
const kanbanGoal = 'Build a polished Kanban web app using only Node built-ins (no dependencies), with server.js, index.html, app.js and style.css as real files. Serve the UI and JSON API from the same Node server using process.env.PORT and bind 0.0.0.0. API: GET /api/tasks returns an array; POST /api/tasks accepts {title, status, priority}, returns 201 with generated unique id; PATCH /api/tasks/:id updates supplied fields; DELETE /api/tasks/:id returns 204. Status is todo, doing or done; priority is low, medium or high. Reject blank titles or invalid enum values with 400, missing ids with 404, malformed JSON with 400. Persist tasks to data.json on disk across server restarts. UI: three status columns, create form, edit title and priority, move tasks between columns, delete, search by title, priority filter, visible per-column counts, empty states and responsive layout. Use accessible labels and real DOM controls; give the create title input id task-title and submit button id add-task. Use the actual API for all changes, preserve state on page reload, never fake API responses or use a static server. Start the app and verify both API behavior and a real browser interaction against that same server. Include a README with startup instructions.';
const inventoryGoal = 'Build an inventory management web app using only Node built-ins, no dependencies. Deliver server.js, index.html, app.js, style.css and README.md. Bind 0.0.0.0 using process.env.PORT. Serve the UI and JSON API from the same server. Persist products and movement history in data.json across process restarts. GET /api/products returns an array. POST /api/products accepts {sku,name,quantity,reorderLevel}, returns 201 with a unique id. Require unique nonblank SKU and name, integer nonnegative quantity and reorderLevel, reject bad inputs with 400 and duplicate SKU with 409. POST /api/movements accepts {productId,delta,reason}, requires a nonzero integer delta and nonblank reason, updates quantity and appends an immutable movement record, returns 201; reject negative resulting stock with 409 and unknown product with 404. GET /api/movements returns an array. GET /api/summary returns {productCount,totalUnits,lowStockCount}, low stock means quantity <= reorderLevel. UI has product creation, searchable inventory table, stock adjustment form with reason, movement history, low-stock highlighting and summary totals that refresh after changes. Use accessible labels, responsive layout, loading/empty/error states. Give product-create fields ids sku, product-name, quantity, reorder-level and its submit button id add-product. Verify valid and invalid API operations and real browser creation against the same running Node server. Never fake API responses or use a static server.';
const goal = id.startsWith('inventory') ? inventoryGoal : kanbanGoal;
process.loadEnvFile('.env');
Object.assign(process.env, {ATOMA_DB_PATH: `${root}/state.db`, ATOMA_SKILLS_DIR: `${root}/skills`, ATOMA_RUNS_DIR: `${root}/traces`, ATOMA_BUILD_WORKSPACE: `${root}/${id}/app`, ATOMA_BUILD_TIMEOUT_MS:'900000'});
const lease = acquireRunLeaseWithoutRecovery(`complexity-${id}`);
let handle;
try {
  mkdirSync(`${root}/${id}`, {recursive:true});
  if (existsSync(`${root}/state.db`)) { const db=new Database(`${root}/state.db`); await db.backup(`${root}/${id}/before.db`); db.close(); }
  if (existsSync(`${root}/skills`)) cpSync(`${root}/skills`,`${root}/${id}/skills-before`,{recursive:true});
  writeFileSync(`${root}/${id}/protocol.json`, JSON.stringify({id,goal,head:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),startedAt:new Date().toISOString(),timeoutMs:900000,pins:[process.env.ATOMA_MODEL_L1,process.env.ATOMA_MODEL_L2,process.env.ATOMA_MODEL_L3],initialState:id==='kanban-1'?'fresh':'reused'},null,2));
  handle=await startTask(buildProfile,['--container',goal]);
  const result=await handle.settled;
  writeFileSync(`${root}/${id}/outcome.json`,JSON.stringify(result));
} finally { if(handle) await handle.shutdown(); lease.release(); }
process.exit(0);
