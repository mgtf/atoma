---
name: build-static-crud-json-server
description: Build a zero-dependency Node server serving static files plus a validated, persisted JSON CRUD API.
when_to_use: Task asks for a zero-dependency Node HTTP server exposing REST-style JSON routes (list/create/update/delete) alongside static HTML/JS/CSS files.
kind: llm
---

1. write_file <entry>.js using only http/fs/path built-ins; bind 0.0.0.0 on Number(process.env.PORT)||0; print LISTENING_ON_PORT=<port> once listening.
2. Serve static <index>.html/<app>.js/<style>.css via fs read + extension-based content-type.
3. Implement GET list, POST create (validate required fields & enums, 201+id), PATCH partial update (only given fields, 404 if id missing), DELETE (204).
4. 400 on blank/missing fields, invalid enums, malformed JSON (try/catch JSON.parse); 404 on unknown id.
5. Persist to <data>.json: load on boot if present, write after each mutation.
6. start_node_server the entry; fetch_url every route + every error case; edit_file and re-probe until all match spec.
7. When writing README.md or any doc file, never copy a numeric port observed from a live probe into the file itself: document the start command (e.g. `node <entry>.js` with the PORT env var), the URL pattern as `http://localhost:<port>`, and the stdout marker as `LISTENING_ON_PORT=<port>`, keeping `<port>` as a literal placeholder string. Use live probe results only to confirm the *shape* (status codes, JSON fields, enum values, error behaviour) is correct — never to inject the actual port number or other run-specific concrete values into committed documentation. After writing any doc file, grep it for stray digits following "localhost:" or "PORT=" and replace any match with the placeholder before returning.
