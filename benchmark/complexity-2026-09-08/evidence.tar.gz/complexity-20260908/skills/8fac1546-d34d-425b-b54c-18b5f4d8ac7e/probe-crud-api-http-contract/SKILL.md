---
name: probe-crud-api-http-contract
description: Re-probe a built JSON API's routes and error cases over HTTP against its documented contract.
when_to_use: Task asks to confirm a built JSON API's routes, status codes, and validation errors still match the documented contract.
kind: llm
---

1. start_node_server the entry file; read LISTENING_ON_PORT=<port> from stdout to get the base URL.
2. Extract the expected routes, status codes, and validation rules (blank/enum/malformed JSON -> 400, unknown id -> 404, delete -> 204) from the task's literal API contract.
3. fetch_url each route+method with a valid and an invalid payload; compare status code and body against the extracted expectations.
4. On mismatch, edit_file the server and re-probe until every case matches.
