---
name: recover-hardcoded-port-in-docs
description: Replace literal port numbers in docs with a <port> placeholder throughout
when_to_use: validator rejects README or docs for containing numeric loopback URL or literal port/LISTENING_ON_PORT value instead of portable placeholder
kind: llm
trigger: validator rejects README or docs for containing numeric loopback URL or literal port/LISTENING_ON_PORT value instead of portable placeholder
---

Scan generated docs for numeric localhost URLs, hardcoded port numbers, or literal LISTENING_ON_PORT=NNNN markers. Replace every such occurrence with a generic placeholder like <port> (e.g. http://localhost:<port>, LISTENING_ON_PORT=<port>). Keep any example commands generic (e.g. PORT=3000 as an illustrative example is fine only if also showing the dynamic/placeholder form), but the canonical documented URL/marker must use the placeholder, not a fixed number.
