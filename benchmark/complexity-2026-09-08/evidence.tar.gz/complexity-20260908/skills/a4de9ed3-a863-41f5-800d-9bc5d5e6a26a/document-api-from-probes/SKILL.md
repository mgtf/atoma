---
name: document-api-from-probes
description: Write README documenting an app's endpoints, enums, errors and persistence from recorded evidence.
when_to_use: Task asks to write or update README/docs describing an already-built app's start command, API endpoints, request/response shapes, allowed values, and error behaviour.
kind: llm
---

1. read_file the probe manifest (e.g. .atoma-probes.json) if present to gather recorded evidence; else list_files/read_file <entry> and other sources to learn real behaviour.
2. For any endpoint, status code, or edge case not yet recorded, run_shell to exercise it and record_probe the result before documenting it.
3. write_file README.md: app description; start command derived from <entry> (env var, stdout marker, http://localhost:<port> with literal <port> placeholder, never a hard-coded number).
4. For each endpoint document exact request/response shape, allowed enum values, and error codes (400/404/etc), citing only probe evidence.
5. Document the persistence file and when it is written/loaded, based on observed behaviour.
