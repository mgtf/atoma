import {CallToolResultSchema} from '@modelcontextprotocol/sdk/types.js';
import {Client} from '@modelcontextprotocol/sdk/client/index.js';
import {StreamableHTTPClientTransport} from '@modelcontextprotocol/sdk/client/streamableHttp.js';
import {readFileSync,writeFileSync} from 'node:fs';
const token=readFileSync('/private/tmp/atoma-complexity-mcp-token.txt','utf8').split('\n').find(l=>l.startsWith('atoma_'));
if(!token)throw Error('Missing MCP token');
const client=new Client({name:'atoma-complexity-campaign',version:'1.0'},{capabilities:{tasks:{requests:{tools:{call:{}}}}}});
const transport=new StreamableHTTPClientTransport(new URL('http://127.0.0.1:5173/mcp'),{requestInit:{headers:{Authorization:`Bearer ${token}`}}});
await client.connect(transport);
console.log('Connected',JSON.stringify(client.getServerVersion()));
const root='runs/complexity-20260908';
const id=process.argv[2]??'mcp-kanban-1';
const catalog=await client.listTools();
writeFileSync(`${root}/${id}-catalog.json`,JSON.stringify(catalog,null,2));
console.log('Catalog',catalog.tools.length,'tools');
const protocol=JSON.parse(readFileSync(`${root}/kanban-1/protocol.json`));
const inventory=id.includes('inventory');
const args={projectId:inventory?'c864fc74-9cd5-4532-8a48-6281439306b4':'932675e3-d20f-4865-820c-304fd6a3db2d',goal:inventory?readFileSync(`${root}/inventory-goal.txt`,'utf8')+(id==='mcp-inventory-2'?' Previous independent checks found horizontal document overflow at a 390px mobile viewport. Ensure the document fits that viewport, including forms, selects and the inventory table; any table overflow must stay inside its own scroll region.':''):protocol.goal,idempotencyKey:`complexity-20260908-${id}`};
writeFileSync(`${root}/${id}-request.json`,JSON.stringify({endpoint:'http://127.0.0.1:5173/mcp',...args,startedAt:new Date().toISOString()},null,2));
let taskId,timer,lastStatus;
try {
for await(const message of client.experimental.tasks.callToolStream({name:'atoma_run_start',arguments:args},undefined,{task:{ttl:3600000},timeout:60000})) {
 if(message.type==='taskCreated') {
  taskId=message.task.taskId;
  writeFileSync(`${root}/${id}-task.json`,JSON.stringify(message.task,null,2));
  console.log(JSON.stringify(message));
  timer=setTimeout(async()=>{console.log('Campaign 15-minute limit: cancelling via MCP tasks/cancel');console.log(JSON.stringify(await client.experimental.tasks.cancelTask(taskId)));},900000);
 } else if(message.type==='result') {
  writeFileSync(`${root}/${id}-result.json`,JSON.stringify(message.result,null,2));
  console.log(JSON.stringify(message));
 } else if(message.type==='error') {
  console.log('MCP ERROR',message.error); if(taskId){try{const detail=await client.experimental.tasks.getTaskResult(taskId,CallToolResultSchema);writeFileSync(`${root}/${id}-failure.json`,JSON.stringify(detail,null,2));console.log('TASK FAILURE DETAIL',JSON.stringify(detail));}catch(e){console.log('Task result error',e.message);}} process.exitCode=1;
 } else if(message.type==='taskStatus') {
  writeFileSync(`${root}/${id}-status.json`,JSON.stringify(message.task,null,2));
  const key=JSON.stringify(message.task);
  if(key!==lastStatus){console.log(JSON.stringify(message));lastStatus=key;}
 }
}
}finally{clearTimeout(timer);await client.close();}
