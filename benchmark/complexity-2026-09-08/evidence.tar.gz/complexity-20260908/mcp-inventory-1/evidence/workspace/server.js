const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

const DATA_FILE = path.join(__dirname, 'data.json');

function loadData() {
  try {
    const content = fs.readFileSync(DATA_FILE, 'utf8');
    return JSON.parse(content);
  } catch (err) {
    return { products: [], movements: [] };
  }
}

function saveData(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

function serveStatic(filePath, res) {
  const ext = path.extname(filePath);
  let contentType = 'text/plain';
  if (ext === '.html') contentType = 'text/html';
  else if (ext === '.js') contentType = 'text/javascript';
  else if (ext === '.css') contentType = 'text/css';

  try {
    const content = fs.readFileSync(filePath, 'utf8');
    res.writeHead(200, { 'Content-Type': contentType });
    res.end(content);
  } catch (err) {
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end('Not Found');
  }
}

function readBody(req, callback) {
  let body = '';
  req.on('data', (chunk) => {
    body += chunk.toString();
  });
  req.on('end', () => {
    try {
      const parsed = body ? JSON.parse(body) : {};
      callback(null, parsed);
    } catch (err) {
      callback(err);
    }
  });
}

const server = http.createServer((req, res) => {
  const parsedUrl = url.parse(req.url, true);
  const pathname = parsedUrl.pathname;
  const method = req.method;

  res.setHeader('Content-Type', 'application/json');

  // Static files
  if (method === 'GET' && pathname === '/') {
    return serveStatic(path.join(__dirname, 'index.html'), res);
  }
  if (method === 'GET' && pathname === '/app.js') {
    return serveStatic(path.join(__dirname, 'app.js'), res);
  }
  if (method === 'GET' && pathname === '/style.css') {
    return serveStatic(path.join(__dirname, 'style.css'), res);
  }

  // API endpoints
  if (pathname === '/api/products') {
    if (method === 'GET') {
      const data = loadData();
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(data.products));
    } else if (method === 'POST') {
      readBody(req, (err, body) => {
        if (err) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'Invalid JSON' }));
          return;
        }

        const { sku, name, quantity, reorderLevel } = body;
        const errors = [];

        // Validate sku
        if (!sku || typeof sku !== 'string' || sku.trim() === '') {
          errors.push('sku is required and must be a non-blank string');
        }
        // Validate name
        if (!name || typeof name !== 'string' || name.trim() === '') {
          errors.push('name is required and must be a non-blank string');
        }
        // Validate quantity
        if (!Number.isInteger(quantity) || quantity < 0) {
          errors.push('quantity must be a non-negative integer');
        }
        // Validate reorderLevel
        if (!Number.isInteger(reorderLevel) || reorderLevel < 0) {
          errors.push('reorderLevel must be a non-negative integer');
        }

        if (errors.length > 0) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ errors }));
          return;
        }

        const data = loadData();
        // Check for duplicate SKU
        if (data.products.some((p) => p.sku === sku)) {
          res.writeHead(409, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'SKU already exists' }));
          return;
        }

        const id = String(Date.now());
        const newProduct = {
          id,
          sku,
          name,
          quantity,
          reorderLevel
        };
        data.products.push(newProduct);
        saveData(data);

        res.writeHead(201, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(newProduct));
      });
    }
  } else if (pathname === '/api/movements') {
    if (method === 'GET') {
      const data = loadData();
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(data.movements));
    } else if (method === 'POST') {
      readBody(req, (err, body) => {
        if (err) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'Invalid JSON' }));
          return;
        }

        const { productId, delta, reason } = body;
        const errors = [];

        // Validate delta
        if (!Number.isInteger(delta) || delta === 0) {
          errors.push('delta must be a non-zero integer');
        }
        // Validate reason
        if (!reason || typeof reason !== 'string' || reason.trim() === '') {
          errors.push('reason is required and must be a non-blank string');
        }

        if (errors.length > 0) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ errors }));
          return;
        }

        const data = loadData();
        const product = data.products.find((p) => p.id === productId);

        if (!product) {
          res.writeHead(404, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'Product not found' }));
          return;
        }

        const newQuantity = product.quantity + delta;
        if (newQuantity < 0) {
          res.writeHead(409, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'Insufficient stock' }));
          return;
        }

        product.quantity = newQuantity;
        const movement = {
          id: String(Date.now()),
          productId,
          delta,
          reason,
          timestamp: new Date().toISOString()
        };
        data.movements.push(movement);
        saveData(data);

        res.writeHead(201, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ...movement, quantity: product.quantity }));
      });
    }
  } else if (pathname === '/api/summary') {
    if (method === 'GET') {
      const data = loadData();
      const productCount = data.products.length;
      const totalUnits = data.products.reduce((sum, p) => sum + p.quantity, 0);
      const lowStockCount = data.products.filter(
        (p) => p.quantity <= p.reorderLevel
      ).length;

      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(
        JSON.stringify({
          productCount,
          totalUnits,
          lowStockCount
        })
      );
    }
  } else {
    res.writeHead(404, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Not Found' }));
  }
});

server.listen(Number(process.env.PORT) || 0, '0.0.0.0', () => {
  const port = server.address().port;
  console.log('LISTENING_ON_PORT=' + port);
});
