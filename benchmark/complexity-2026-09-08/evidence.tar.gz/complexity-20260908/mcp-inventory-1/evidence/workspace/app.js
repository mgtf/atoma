// Inventory Management App
// Fetches data from real API endpoints, never uses fabricated data

const API_BASE = '/api';

// State
let products = [];
let movements = [];
let summary = { productCount: 0, totalUnits: 0, lowStockCount: 0 };

// DOM Elements
const productForm = document.getElementById('product-form');
const movementForm = document.getElementById('movement-form');
const productsBody = document.getElementById('products-body');
const productSelect = document.getElementById('product-select');
const searchInput = document.getElementById('search-input');
const summaryProducts = document.getElementById('summary-products');
const summaryUnits = document.getElementById('summary-units');
const summaryLowStock = document.getElementById('summary-low-stock');
const historyContainer = document.getElementById('history-container');
const productMessage = document.getElementById('product-message');
const movementMessage = document.getElementById('movement-message');
const tableError = document.getElementById('table-error');
const historyError = document.getElementById('history-error');

// Utility: fetch with error handling
async function apiFetch(endpoint, options = {}) {
  try {
    const response = await fetch(`${API_BASE}${endpoint}`, {
      headers: { 'Content-Type': 'application/json' },
      ...options
    });
    const data = await response.json();
    if (!response.ok) {
      throw { status: response.status, data };
    }
    return { ok: true, status: response.status, data };
  } catch (err) {
    // Don't log expected API validation errors; they're handled by the UI
    if (!(err.status && (err.status === 400 || err.status === 404 || err.status === 409))) {
      console.error(`API Error on ${endpoint}:`, err);
    }
    throw err;
  }
}

// Load all data from API
async function loadAllData() {
  try {
    tableError.style.display = 'none';
    historyError.style.display = 'none';

    // Fetch products
    const productsResult = await apiFetch('/products');
    products = productsResult.data || [];

    // Fetch movements
    const movementsResult = await apiFetch('/movements');
    movements = movementsResult.data || [];

    // Fetch summary
    const summaryResult = await apiFetch('/summary');
    summary = summaryResult.data || { productCount: 0, totalUnits: 0, lowStockCount: 0 };

    renderAll();
  } catch (err) {
    console.error('Failed to load data:', err);
    tableError.style.display = 'block';
    tableError.textContent = 'Error loading products. Please refresh the page.';
    historyError.style.display = 'block';
    historyError.textContent = 'Error loading movements. Please refresh the page.';
  }
}

// Render summary section
function renderSummary() {
  summaryProducts.textContent = summary.productCount;
  summaryUnits.textContent = summary.totalUnits;
  summaryLowStock.textContent = summary.lowStockCount;
}

// Render products table
function renderProducts() {
  const searchTerm = searchInput.value.toLowerCase();
  const filtered = products.filter(p => 
    p.sku.toLowerCase().includes(searchTerm) || 
    p.name.toLowerCase().includes(searchTerm)
  );

  if (filtered.length === 0) {
    productsBody.innerHTML = '<tr class="empty-state"><td colspan="5">No products found.</td></tr>';
  } else {
    productsBody.innerHTML = filtered.map(product => {
      const isLowStock = product.quantity <= product.reorderLevel;
      const rowClass = isLowStock ? 'low-stock' : '';
      const statusText = isLowStock ? 'LOW STOCK' : 'In Stock';
      return `<tr class="${rowClass}"><td>${escapeHtml(product.sku)}</td><td>${escapeHtml(product.name)}</td><td>${product.quantity}</td><td>${product.reorderLevel}</td><td class="status-cell ${isLowStock ? 'alert' : ''}">${statusText}</td></tr>`;
    }).join('');
  }
}

// Render movement history
function renderHistory() {
  if (movements.length === 0) {
    historyContainer.innerHTML = '<div class="empty-state">No movements recorded yet.</div>';
  } else {
    historyContainer.innerHTML = `
      <div class="history-list">
        ${movements.map(movement => {
          const product = products.find(p => p.id === movement.productId);
          const productName = product ? product.name : 'Unknown Product';
          const timestamp = new Date(movement.timestamp).toLocaleString();
          const deltaClass = movement.delta > 0 ? 'positive' : 'negative';
          return `
            <div class="history-item">
              <div class="history-header">
                <span class="history-product">${escapeHtml(productName)}</span>
                <span class="history-time">${timestamp}</span>
              </div>
              <div class="history-details">
                <span class="history-delta ${deltaClass}">
                  ${movement.delta > 0 ? '+' : ''}${movement.delta}
                </span>
                <span class="history-reason">${escapeHtml(movement.reason)}</span>
              </div>
            </div>
          `;
        }).join('')}
      </div>
    `;
  }
}

// Render product dropdown
function renderProductSelect() {
  const options = products.map(p => `
    <option value="${p.id}">${escapeHtml(p.sku)} - ${escapeHtml(p.name)}</option>
  `).join('');
  productSelect.innerHTML = '<option value="">-- Select a product --</option>' + options;
}

// Render all sections
function renderAll() {
  renderSummary();
  renderProducts();
  renderHistory();
  renderProductSelect();
}

// Utility: escape HTML to prevent XSS
function escapeHtml(text) {
  const map = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;'
  };
  return text.replace(/[&<>"']/g, m => map[m]);
}

// Show message
function showMessage(element, text, type = 'success') {
  element.textContent = text;
  element.className = `form-message ${type}`;
  element.style.display = 'block';
  setTimeout(() => {
    element.style.display = 'none';
  }, 5000);
}

// Handle product form submission
productForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  
  const sku = document.getElementById('sku').value.trim();
  const name = document.getElementById('product-name').value.trim();
  const quantity = parseInt(document.getElementById('quantity').value.trim() || '0', 10);
  const reorderLevel = parseInt(document.getElementById('reorder-level').value.trim() || '0', 10);

  try {
    const result = await apiFetch('/products', {
      method: 'POST',
      body: JSON.stringify({ sku, name, quantity, reorderLevel })
    });

    showMessage(productMessage, 'Product added successfully!', 'success');
    productForm.reset();
    await loadAllData();
  } catch (err) {
    const errorMsg = err.data?.errors?.[0] || err.data?.error || 'Failed to add product';
    showMessage(productMessage, errorMsg, 'error');
  }
});

// Handle movement form submission
movementForm.addEventListener('submit', async (e) => {
  e.preventDefault();

  const productId = document.getElementById('product-select').value;
  const delta = parseInt(document.getElementById('delta').value.trim() || '0', 10);
  const reason = document.getElementById('reason').value.trim();

  if (!productId) {
    showMessage(movementMessage, 'Please select a product', 'error');
    return;
  }

  try {
    const result = await apiFetch('/movements', {
      method: 'POST',
      body: JSON.stringify({ productId, delta, reason })
    });

    showMessage(movementMessage, 'Stock adjusted successfully!', 'success');
    movementForm.reset();
    await loadAllData();
  } catch (err) {
    const errorMsg = err.data?.errors?.[0] || err.data?.error || 'Failed to adjust stock';
    showMessage(movementMessage, errorMsg, 'error');
  }
});

// Handle search input
searchInput.addEventListener('input', () => {
  renderProducts();
});

// Initialize app on page load
document.addEventListener('DOMContentLoaded', () => {
  loadAllData();
});
