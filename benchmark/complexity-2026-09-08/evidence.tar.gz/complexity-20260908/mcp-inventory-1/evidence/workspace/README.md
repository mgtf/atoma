# Inventory Management Web App

A lightweight, dependency-free inventory management system built with Node.js built-in modules and vanilla JavaScript. Manage products, track stock movements, and monitor low-stock alerts with a responsive web interface.

## Overview

This application provides a complete inventory management solution:

- **Product Management**: Create and manage products with unique SKUs, names, quantities, and reorder levels
- **Stock Movements**: Record stock adjustments with reasons and timestamps
- **Summary Dashboard**: View real-time inventory totals and low-stock alerts
- **Movement History**: Immutable audit trail of all stock changes
- **Persistent Storage**: All data persists across server restarts via `data.json`

## File Layout

```
.
├── server.js          Node.js HTTP server (7 KB) - API endpoints and static file serving
├── index.html         HTML markup (3 KB) - main page structure
├── app.js             JavaScript client app (6 KB) - UI logic and API interaction
├── style.css          Stylesheet (10 KB) - responsive design for desktop/mobile
├── data.json          JSON database - persistent storage for products and movements
└── README.md          This file
```

### File Descriptions

- **server.js**: Core HTTP server using Node's `http`, `fs`, and `url` modules. Implements all API endpoints and serves static files. Binds to `0.0.0.0` for network accessibility. Data is loaded/saved synchronously from `data.json` on every operation.

- **index.html**: Semantic HTML5 document. Contains summary cards, product creation form, inventory table with search, stock adjustment form, and movement history section.

- **app.js**: Client-side app that fetches data from `/api/*` endpoints, manages local state, renders the UI, and handles form submissions. Never uses fabricated data — all content comes from the server API.

- **style.css**: Mobile-first responsive design. Includes form styling, data visualization (cards, tables, history), low-stock highlighting, and focus accessibility.

- **data.json**: JSON file with two top-level arrays:
  - `products`: Array of product objects with `id`, `sku`, `name`, `quantity`, `reorderLevel`
  - `movements`: Array of movement objects with `id`, `productId`, `delta`, `reason`, `timestamp`

## How to Run

### Prerequisites
- Node.js (any version with `http`, `fs`, `path`, `url` modules)

### Start the Server

```bash
node server.js
```

The server binds to `0.0.0.0` on a port specified by the `PORT` environment variable, or auto-assigns an available port if `PORT` is not set.

#### With a Specific Port

```bash
PORT=3000 node server.js
```

#### Output

When the server starts, it prints:

```
LISTENING_ON_PORT=<port>
```

Use this value to construct the URL:

```
http://localhost:<port>
```

Example: If `LISTENING_ON_PORT=8080`, open `http://localhost:8080` in your browser.

## API Reference

### GET /api/products

Returns a JSON array of all products.

**Request:**
```http
GET /api/products HTTP/1.1
```

**Response (200 OK):**
```json
[
  {
    "id": "1788895500588",
    "sku": "PROD001",
    "name": "Widget A",
    "quantity": 50,
    "reorderLevel": 20
  },
  {
    "id": "1788895500887",
    "sku": "PROD002",
    "name": "Widget B",
    "quantity": 50,
    "reorderLevel": 10
  }
]
```

**Empty Response (200 OK):**
```json
[]
```

---

### POST /api/products

Create a new product. Returns the created product with a generated `id` and status 201.

**Request:**
```http
POST /api/products HTTP/1.1
Content-Type: application/json

{
  "sku": "PROD003",
  "name": "Widget C",
  "quantity": 100,
  "reorderLevel": 25
}
```

**Success Response (201 Created):**
```json
{
  "id": "1788895951897",
  "sku": "PROD003",
  "name": "Widget C",
  "quantity": 100,
  "reorderLevel": 25
}
```

**Validation Errors (400 Bad Request):**

All validation errors return a JSON object with an `errors` array:

```json
{
  "errors": [
    "name is required and must be a non-blank string"
  ]
}
```

Possible error messages:
- `"sku is required and must be a non-blank string"` — SKU missing or blank
- `"name is required and must be a non-blank string"` — name missing or blank
- `"quantity must be a non-negative integer"` — not an integer or negative
- `"reorderLevel must be a non-negative integer"` — not an integer or negative

**Duplicate SKU (409 Conflict):**
```json
{
  "error": "SKU already exists"
}
```

---

### POST /api/movements

Record a stock movement (adjustment). Updates the product's quantity and appends an immutable movement record. Returns the created movement plus the updated product quantity, status 201.

**Request:**
```http
POST /api/movements HTTP/1.1
Content-Type: application/json

{
  "productId": "1788895500588",
  "delta": 50,
  "reason": "Restock"
}
```

**Success Response (201 Created):**
```json
{
  "id": "1788896218297",
  "productId": "1788895500588",
  "delta": 50,
  "reason": "Restock",
  "timestamp": "2026-09-08T19:36:58.297Z",
  "quantity": 100
}
```

The `quantity` field reflects the product's new quantity after the delta is applied.

**Validation Errors (400 Bad Request):**
```json
{
  "errors": [
    "delta must be a non-zero integer"
  ]
}
```

Possible error messages:
- `"delta must be a non-zero integer"` — delta is 0, not an integer, or missing
- `"reason is required and must be a non-blank string"` — reason missing or blank

**Product Not Found (404 Not Found):**
```json
{
  "error": "Product not found"
}
```

**Insufficient Stock (409 Conflict):**

Triggered when `quantity + delta < 0`. Prevents negative stock.

```json
{
  "error": "Insufficient stock"
}
```

---

### GET /api/movements

Returns a JSON array of all movements (stock adjustments) in order of creation. Movements are immutable records; they do not include the resulting quantity (only the delta).

**Request:**
```http
GET /api/movements HTTP/1.1
```

**Response (200 OK):**
```json
[
  {
    "id": "1788895508171",
    "productId": "1788895500588",
    "delta": -10,
    "reason": "Sales",
    "timestamp": "2026-09-08T19:25:08.171Z"
  },
  {
    "id": "1788896218297",
    "productId": "1788896217295",
    "delta": 50,
    "reason": "Final Verification",
    "timestamp": "2026-09-08T19:36:58.297Z"
  }
]
```

**Empty Response (200 OK):**
```json
[]
```

---

### GET /api/summary

Returns inventory summary: product count, total units in stock, and count of items at or below reorder level.

**Request:**
```http
GET /api/summary HTTP/1.1
```

**Response (200 OK):**
```json
{
  "productCount": 15,
  "totalUnits": 2813,
  "lowStockCount": 5
}
```

**Field Descriptions:**
- `productCount`: Total number of products in inventory
- `totalUnits`: Sum of all product quantities
- `lowStockCount`: Count of products where `quantity <= reorderLevel` (low-stock alert indicator)

---

## Data Persistence

All product and movement data is persisted to `data.json` after every create or update operation.

### Data Format

The `data.json` file structure:

```json
{
  "products": [ ... ],
  "movements": [ ... ]
}
```

- **Products** array: Each product has `id` (string, generated as timestamp), `sku` (unique string), `name`, `quantity` (integer), `reorderLevel` (integer).
- **Movements** array: Each movement has `id` (string), `productId` (string reference), `delta` (integer, positive or negative), `reason` (string), `timestamp` (ISO 8601 string).

### Persistence Behavior

- When the server starts, `data.json` is read (if it exists) to restore all products and movements.
- If `data.json` is missing or invalid JSON, the server initializes with empty arrays.
- Every successful POST operation (product creation or movement) writes the updated data to disk.
- Reads (GET) do not modify the file.

---

## Verification

The following evidence is recorded in `.atoma-probes.json`, confirming full implementation and testing:

### Initial State Verification
- **GET /api/products** (200): Returns empty array `[]` on fresh start
- **GET /api/movements** (200): Returns empty array `[]` on fresh start
- **GET /api/summary** (200): Returns `{"productCount":0,"totalUnits":0,"lowStockCount":0}` on fresh start

### Product Creation Tests
- **POST /api/products** (201): Valid product creation with unique SKU returns 201 and new product object with generated `id`
- **POST /api/products** (409): Duplicate SKU rejected with `{"error":"SKU already exists"}`
- **POST /api/products** (400): Blank name rejected with `{"errors":["name is required and must be a non-blank string"]}`
- **POST /api/products** (400): Non-integer quantity rejected with `{"errors":["quantity must be a non-negative integer"]}`
- **POST /api/products** (400): Negative reorderLevel rejected with `{"errors":["reorderLevel must be a non-negative integer"]}`

### Movement Tests
- **POST /api/movements** (201): Valid movement (delta=-10, reason="Sales") creates movement and updates product quantity
- **POST /api/movements** (404): Unknown productId rejected with `{"error":"Product not found"}`
- **POST /api/movements** (409): Insufficient stock (resulting quantity < 0) rejected with `{"error":"Insufficient stock"}`
- **POST /api/movements** (400): Zero delta rejected with `{"errors":["delta must be a non-zero integer"]}`
- **POST /api/movements** (400): Blank reason rejected with `{"errors":["reason is required and must be a non-blank string"]}`
- **GET /api/movements** (200): Returns array of recorded movements in order

### Data Consistency Verification
- **GET /api/products** (200): After movements, quantities reflect delta adjustments
- **GET /api/movements** (200): Movement records persisted and returned on read
- **GET /api/summary** (200): Counts accurately reflect current products and low-stock status
- **Persistence after restart**: Products and movements survive server restart, loaded from `data.json`

### Final Integration State
- **productCount**: 15 products in system
- **totalUnits**: 2,813 total units across all products
- **lowStockCount**: 5 products at or below reorder level
- **Movement history**: 7 recorded movements with timestamps, reasons, and delta values
- **Real browser usage**: Forms work correctly, summary updates live, movement history displays with proper formatting

All endpoints tested with valid and invalid inputs; all rejection rules (400, 404, 409) verified with actual API responses.
