---
name: build-node-api-with-persistence
description: Build zero-dep Node HTTP server with static files, JSON API, and disk-backed persistence.
when_to_use: Task asks to build a zero-dependency Node HTTP server serving static files plus a JSON API with persisted state
kind: llm
---

1. write_file <entry> using only Node http/fs builtins: serve static <index>.html/<script>.js/<style>.css from root, plus JSON API routes with input validation (required/nonblank/integer checks) returning 400/404/409/201 as specified.
2. write_file <state>.json with initial empty state.
3. start_node_server with PORT=0, read LISTENING_ON_PORT=<port> from stdout.
4. fetch_url every route with valid and invalid bodies, checking status codes and shapes.
5. Restart the server, fetch_url a GET route again to confirm <state>.json persistence.
