---
name: probe-api-endpoints-and-persistence
description: Boot a built API, hit every documented endpoint, and confirm state survives a restart.
when_to_use: Task asks to verify an already-built HTTP API's endpoints and confirm its state persists across a process restart
kind: llm
---

1. read_file <entry> to enumerate its routes, required fields, and expected status codes.
2. start_node_server with PORT=0; capture LISTENING_ON_PORT=<port> from stdout.
3. fetch_url each route with valid and invalid payloads; assert the status codes/shapes match what <entry> implements.
4. Restart the server process, fetch_url a GET route again, and diff the body against the pre-restart response to confirm persistence.
