import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {spawn} from 'node:child_process';
const id=process.argv[2];
const protocol=JSON.parse(readFileSync('runs/complexity-20260908/kanban-1/protocol.json'));
mkdirSync(`runs/complexity-20260908/${id}`,{recursive:true});
writeFileSync(`runs/complexity-20260908/${id}/protocol.json`,JSON.stringify({...protocol,id,startedAt:new Date().toISOString(),context:'organisation project; default project lifecycle; previous delivered workspace is seeded when available'},null,2));
const child=spawn(process.execPath,['--import','tsx','src/cli/projects.ts','run','--project','kanban-progression','--as','32daa08f-a001-4e5c-be42-41c3a4b949ef','--timeout','900',protocol.goal],{stdio:'inherit',env:process.env});
for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>child.kill(signal));
child.on('exit',code=>process.exit(code??1));
