const fs = require('node:fs');
const {spawn} = require('node:child_process');
const puppeteer = require('/app/node_modules/puppeteer');
const assert = require('node:assert/strict');
fs.cpSync('/deliverable','/tmp/app',{recursive:true});
const results=[]; let server,browser;
const base='http://127.0.0.1:4187';
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function check(name, fn) {try{await fn();results.push({name,pass:true});}catch(e){results.push({name,pass:false,error:e.message});}}
async function start(){server=spawn('node',['server.js'],{cwd:'/tmp/app',env:{...process.env,PORT:'4187'},stdio:['ignore','pipe','pipe']}); server.stdout.on('data',()=>{});server.stderr.on('data',()=>{});for(let i=0;i<100;i++){try{await fetch(base+'/api/tasks');return;}catch{await sleep(100);}}throw Error('Server did not start on PORT=4187');}
async function stop(){if(!server||server.exitCode!==null)return;const exited=new Promise(r=>server.once('exit',r));server.kill('SIGTERM');await exited;}
async function req(path,method='GET',data){return fetch(base+path,{method,headers:{'Content-Type':'application/json'},body:data===undefined?undefined:JSON.stringify(data)});}
(async()=>{try{
await check('Required files',async()=>{for(const f of ['server.js','index.html','app.js','style.css','README.md'])assert(fs.existsSync('/tmp/app/'+f),f);});
await start();
await check('Dynamic port and exact served assets',async()=>{for(const [url,file] of [['/','index.html'],['/app.js','app.js'],['/style.css','style.css']]){const r=await req(url);assert.equal(r.status,200);assert.equal(await r.text(),fs.readFileSync('/tmp/app/'+file,'utf8'));}});
let task;
await check('Create and read task',async()=>{const r=await req('/api/tasks','POST',{title:'Scorer unique task',status:'todo',priority:'high'});assert.equal(r.status,201);task=await r.json();assert(task.id!==undefined);const list=await (await req('/api/tasks')).json();assert(Array.isArray(list));assert(list.some(t=>t.id===task.id&&t.title==='Scorer unique task'));});
await check('Update task fields',async()=>{assert(task);const r=await req('/api/tasks/'+task.id,'PATCH',{title:'Scorer moved',status:'doing',priority:'low'});assert(r.ok);const list=await (await req('/api/tasks')).json();const t=list.find(t=>t.id===task.id);assert.equal(t.title,'Scorer moved');assert.equal(t.status,'doing');assert.equal(t.priority,'low');});
await check('Invalid input rejected',async()=>{for(const data of [{title:'   ',status:'todo',priority:'low'},{title:'bad',status:'invalid',priority:'low'},{title:'bad',status:'todo',priority:'invalid'}])assert.equal((await req('/api/tasks','POST',data)).status,400);assert.equal((await fetch(base+'/api/tasks',{method:'POST',headers:{'Content-Type':'application/json'},body:'{broken'})).status,400);});
await check('Missing ids return 404',async()=>{assert.equal((await req('/api/tasks/scorer-missing','PATCH',{title:'x'})).status,404);assert.equal((await req('/api/tasks/scorer-missing','DELETE')).status,404);});
await check('Disk persistence across process restart',async()=>{assert(task);await stop();await start();const list=await (await req('/api/tasks')).json();assert(list.some(t=>t.id===task.id&&t.title==='Scorer moved'&&t.status==='doing'));});
browser=await puppeteer.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});const page=await browser.newPage();const errors=[];page.on('response',r=>{if(r.status()>=400)errors.push(`${r.status()} ${r.url()}`);});page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
await check('Browser renders API task',async()=>{await page.goto(base,{waitUntil:'networkidle0'});assert((await page.$eval('body',e=>e.innerText)).includes('Scorer moved'));});
await check('Browser create writes real API and survives reload',async()=>{await page.type('#task-title','Browser scorer task');await page.click('#add-task');await page.waitForFunction(()=>document.body.innerText.includes('Browser scorer task'),{timeout:7000});const list=await (await req('/api/tasks')).json();assert(list.some(t=>t.title==='Browser scorer task'));await page.reload({waitUntil:'networkidle0'});assert((await page.$eval('body',e=>e.innerText)).includes('Browser scorer task'));});
await page.screenshot({path:'/output/desktop.png',fullPage:true});
await check('Mobile layout has no horizontal overflow',async()=>{await page.setViewport({width:390,height:844});await sleep(200);assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1));});
await page.screenshot({path:'/output/mobile.png',fullPage:true});
await check('No browser errors',async()=>{assert.deepEqual(errors,[]);});
await check('Delete removes task',async()=>{assert(task);assert.equal((await req('/api/tasks/'+task.id,'DELETE')).status,204);const list=await (await req('/api/tasks')).json();assert(!list.some(t=>t.id===task.id));});
}catch(e){results.push({name:'Scorer completion',pass:false,error:e.message});}finally{if(browser)await browser.close();await stop();fs.writeFileSync('/output/score.json',JSON.stringify(results,null,2));console.log(JSON.stringify(results,null,2));process.exit(results.some(r=>!r.pass)?1:0);}})();
