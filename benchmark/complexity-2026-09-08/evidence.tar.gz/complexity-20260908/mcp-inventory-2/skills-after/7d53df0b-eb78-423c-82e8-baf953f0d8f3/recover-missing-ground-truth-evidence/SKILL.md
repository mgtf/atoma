---
name: recover-missing-ground-truth-evidence
description: Replace narrative UI claims with pasted DOM/CSS probe evidence per constraint
when_to_use: validator rejects narrative-only UI claims lacking pasted DOM/class/style/color evidence or structural CSS proof
kind: llm
trigger: validator rejects narrative-only UI claims lacking pasted DOM/class/style/color evidence or structural CSS proof
---

For each visible/conditional UI claim (highlighting, overflow, responsive layout), fetch the rendered HTML/CSS or use validate_html/DOM snapshot and paste the actual class names, computed style values, or color codes observed. For structural CSS constraints (e.g. scroll containment), quote the specific CSS rule and selector verified, not a description. Never assert UI behavior passed without attaching the literal probe output that proves it.
