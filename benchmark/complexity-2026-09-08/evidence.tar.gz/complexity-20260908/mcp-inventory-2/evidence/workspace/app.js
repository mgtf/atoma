// State for products and movements
let products = [];
let movements = [];
let summary = { productCount: 0, totalUnits: 0, lowStockCount: 0 };

// DOM elements
const productForm = document.getElementById('product-form');
const productFormMessage = document.getElementById('product-form-message');
const inventoryTable = document.getElementById('inventory-table');
const inventoryBody = document.getElementById('inventory-body');
const inventoryLoading = document.getElementById('inventory-loading');
const inventoryEmpty = document.getElementById('inventory-empty');
const inventoryError = document.getElementById('inventory-error');
const movementForm = document.getElementById('movement-form');
const movementFormMessage = document.getElementById('movement-form-message');
const movementProductSelect = document.getElementById('movement-product');
const movementsList = document.getElementById('movements-list');
const movementsLoading = document.getElementById('movements-loading');
const movementsEmpty = document.getElementById('movements-empty');
const movementsError = document.getElementById('movements-error');
const productCountEl = document.getElementById('product-count');
const totalUnitsEl = document.getElementById('total-units');
const lowStockCountEl = document.getElementById('low-stock-count');

// API Base URL
const API_BASE = window.location.origin;

// Helper to clear message after 3 seconds
function clearMessageAfter(element, ms = 3000) {
  setTimeout(() => {
    element.textContent = '';
    element.className = 'message';
  }, ms);
}

// Fetch products from API
async function fetchProducts() {
  try {
    inventoryLoading.classList.remove('hidden');
    inventoryError.classList.add('hidden');
    inventoryEmpty.classList.add('hidden');
    inventoryTable.classList.add('hidden');

    const response = await fetch(`${API_BASE}/api/products`);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    
    products = await response.json();
    renderInventory();
    updateProductSelect();
  } catch (error) {
    console.error('Error fetching products:', error);
    inventoryError.textContent = `Error loading inventory: ${error.message}`;
    inventoryError.classList.remove('hidden');
  } finally {
    inventoryLoading.classList.add('hidden');
  }
}

// Fetch movements from API
async function fetchMovements() {
  try {
    movementsLoading.classList.remove('hidden');
    movementsError.classList.add('hidden');
    movementsEmpty.classList.add('hidden');

    const response = await fetch(`${API_BASE}/api/movements`);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    
    movements = await response.json();
    renderMovements();
  } catch (error) {
    console.error('Error fetching movements:', error);
    movementsError.textContent = `Error loading movements: ${error.message}`;
    movementsError.classList.remove('hidden');
  } finally {
    movementsLoading.classList.add('hidden');
  }
}

// Fetch summary from API
async function fetchSummary() {
  try {
    const response = await fetch(`${API_BASE}/api/summary`);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    
    summary = await response.json();
    renderSummary();
  } catch (error) {
    console.error('Error fetching summary:', error);
  }
}

// Render inventory table
function renderInventory() {
  if (products.length === 0) {
    inventoryEmpty.classList.remove('hidden');
    inventoryTable.classList.add('hidden');
    inventoryBody.innerHTML = '';
    return;
  }

  inventoryEmpty.classList.add('hidden');
  inventoryTable.classList.remove('hidden');
  inventoryBody.innerHTML = '';

  products.forEach(product => {
    const row = document.createElement('tr');
    const isLowStock = product.quantity <= product.reorderLevel;
    if (isLowStock) {
      row.classList.add('low-stock');
    }

    row.innerHTML = `
      <td>${escapeHtml(product.sku)}</td>
      <td>${escapeHtml(product.name)}</td>
      <td>${product.quantity}</td>
      <td>${product.reorderLevel}</td>
    `;
    inventoryBody.appendChild(row);
  });
}

// Render summary
function renderSummary() {
  productCountEl.textContent = summary.productCount;
  totalUnitsEl.textContent = summary.totalUnits;
  lowStockCountEl.textContent = summary.lowStockCount;
}

// Render movements
function renderMovements() {
  if (movements.length === 0) {
    movementsEmpty.classList.remove('hidden');
    movementsList.innerHTML = '';
    return;
  }

  movementsEmpty.classList.add('hidden');
  movementsList.innerHTML = '';

  // Display movements in reverse chronological order
  [...movements].reverse().forEach(movement => {
    const product = products.find(p => p.id === movement.productId);
    const productName = product ? product.name : 'Unknown Product';
    const sign = movement.delta > 0 ? '+' : '';

    const li = document.createElement('li');
    li.className = 'movement-item';
    li.innerHTML = `
      <div class="movement-info">
        <strong>${escapeHtml(productName)}</strong>
        <span class="movement-delta ${movement.delta > 0 ? 'positive' : 'negative'}">${sign}${movement.delta}</span>
      </div>
      <div class="movement-details">
        <p><em>${escapeHtml(movement.reason)}</em></p>
        <p class="movement-time">${new Date(movement.timestamp).toLocaleString()}</p>
      </div>
    `;
    movementsList.appendChild(li);
  });
}

// Update product select dropdown
function updateProductSelect() {
  movementProductSelect.innerHTML = '<option value="">-- Select a product --</option>';
  products.forEach(product => {
    const option = document.createElement('option');
    option.value = product.id;
    option.textContent = `${product.sku} - ${product.name}`;
    movementProductSelect.appendChild(option);
  });
}

// Handle product form submission
productForm.addEventListener('submit', async (e) => {
  e.preventDefault();

  const sku = document.getElementById('sku').value.trim();
  const name = document.getElementById('product-name').value.trim();
  const quantity = parseInt(document.getElementById('quantity').value, 10);
  const reorderLevel = parseInt(document.getElementById('reorder-level').value, 10);

  // Basic client-side validation
  if (!sku || !name) {
    productFormMessage.textContent = 'SKU and product name are required';
    productFormMessage.className = 'message error';
    clearMessageAfter(productFormMessage);
    return;
  }

  try {
    const response = await fetch(`${API_BASE}/api/products`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sku, name, quantity, reorderLevel })
    });

    const data = await response.json();

    if (!response.ok) {
      productFormMessage.textContent = data.error || 'Error adding product';
      productFormMessage.className = 'message error';
      clearMessageAfter(productFormMessage);
      return;
    }

    // Success
    productFormMessage.textContent = 'Product added successfully';
    productFormMessage.className = 'message success';
    productForm.reset();
    clearMessageAfter(productFormMessage);

    // Refresh data
    await fetchProducts();
    await fetchSummary();
  } catch (error) {
    console.error('Error adding product:', error);
    productFormMessage.textContent = `Error: ${error.message}`;
    productFormMessage.className = 'message error';
    clearMessageAfter(productFormMessage);
  }
});

// Handle movement form submission
movementForm.addEventListener('submit', async (e) => {
  e.preventDefault();

  const productId = document.getElementById('movement-product').value.trim();
  const delta = parseInt(document.getElementById('delta').value, 10);
  const reason = document.getElementById('reason').value.trim();

  if (!productId) {
    movementFormMessage.textContent = 'Please select a product';
    movementFormMessage.className = 'message error';
    clearMessageAfter(movementFormMessage);
    return;
  }

  if (!reason) {
    movementFormMessage.textContent = 'Reason is required';
    movementFormMessage.className = 'message error';
    clearMessageAfter(movementFormMessage);
    return;
  }

  try {
    const response = await fetch(`${API_BASE}/api/movements`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ productId, delta, reason })
    });

    const data = await response.json();

    if (!response.ok) {
      movementFormMessage.textContent = data.error || 'Error recording movement';
      movementFormMessage.className = 'message error';
      clearMessageAfter(movementFormMessage);
      return;
    }

    // Success
    movementFormMessage.textContent = 'Movement recorded successfully';
    movementFormMessage.className = 'message success';
    movementForm.reset();
    clearMessageAfter(movementFormMessage);

    // Refresh data
    await fetchProducts();
    await fetchMovements();
    await fetchSummary();
  } catch (error) {
    console.error('Error recording movement:', error);
    movementFormMessage.textContent = `Error: ${error.message}`;
    movementFormMessage.className = 'message error';
    clearMessageAfter(movementFormMessage);
  }
});

// Escape HTML special characters
function escapeHtml(text) {
  const map = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;'
  };
  return text.replace(/[&<>"']/g, m => map[m]);
}

// Initialize the app on page load
document.addEventListener('DOMContentLoaded', async () => {
  await fetchProducts();
  await fetchMovements();
  await fetchSummary();
});
