# Inventory Management Web App

A lightweight, single-page inventory management application built with Node.js using only built-in modules (no external dependencies). Manage products, track stock movements, and monitor low-stock items in real time.

## Features

- **Product Management**: Add and track products with SKU, name, quantity, and reorder level
- **Stock Movements**: Record and view all stock adjustments with reason and timestamp
- **Inventory Summary**: Real-time dashboard showing product count, total units, and low-stock count
- **Persistent Storage**: All data saved to `data.json` and survives server restarts
- **Responsive Design**: Mobile-friendly UI with scrollable tables for small viewports
- **Input Validation**: Comprehensive validation with clear error messages (400/409 status codes)
- **Low-Stock Highlighting**: Visual indicators for products below reorder level

## Setup

### Prerequisites
- Node.js (any recent version)
- No npm dependencies required

### Installation

1. Clone or download the repository
2. No installation step needed — the app uses only Node built-ins

### Running the Server

```bash
node server.js
```

The server binds to `0.0.0.0` on a port specified by `process.env.PORT` (or port 0 for auto-assignment). Upon startup, it prints:

```
LISTENING_ON_PORT=<port>
```

Once running, open your browser and navigate to:

```
http://localhost:<port>
```

### Example with Environment Variable

```bash
PORT=3000 node server.js
```

Then visit `http://localhost:<port>`

## Data Persistence

All inventory data is persisted to `data.json` in the same directory as `server.js`. The file structure is:

```json
{
  "products": [
    {
      "id": "<unique-timestamp-string>",
      "sku": "SKU001",
      "name": "Widget A",
      "quantity": 100,
      "reorderLevel": 10
    }
  ],
  "movements": [
    {
      "id": "<unique-timestamp-string>",
      "productId": "<product-id>",
      "delta": 10,
      "reason": "Restock",
      "timestamp": "2026-09-08T19:51:43.116Z"
    }
  ]
}
```

Data is automatically loaded on server startup and saved after every change.

## API Contract

The app exposes the following RESTful JSON API endpoints:

### GET /api/products

Returns the list of all products.

**Request:**
```
GET http://localhost:<port>/api/products
```

**Response:** HTTP 200
```json
[
  {
    "id": "1788897094299",
    "sku": "SKU001",
    "name": "Widget A",
    "quantity": 115,
    "reorderLevel": 20
  },
  {
    "id": "1788897111497",
    "sku": "SKU002",
    "name": "Widget B",
    "quantity": 5,
    "reorderLevel": 10
  }
]
```

### POST /api/products

Creates a new product. Returns the created product with a unique `id`.

**Request:** HTTP 201
```
POST http://localhost:<port>/api/products
Content-Type: application/json

{
  "sku": "SKU003",
  "name": "Widget C",
  "quantity": 50,
  "reorderLevel": 5
}
```

**Response:** HTTP 201 (Created)
```json
{
  "id": "1788897130034",
  "sku": "SKU003",
  "name": "Widget C",
  "quantity": 50,
  "reorderLevel": 5
}
```

**Validation Errors:**

- **HTTP 400** — Invalid input (blank/missing fields or non-integer values)
  ```json
  {
    "error": "sku is required and must be nonblank"
  }
  ```
  ```json
  {
    "error": "name is required and must be nonblank"
  }
  ```
  ```json
  {
    "error": "quantity must be a nonnegative integer"
  }
  ```
  ```json
  {
    "error": "reorderLevel must be a nonnegative integer"
  }
  ```

- **HTTP 409** — Duplicate SKU
  ```json
  {
    "error": "SKU already exists"
  }
  ```

### GET /api/movements

Returns the list of all recorded stock movements.

**Request:**
```
GET http://localhost:<port>/api/movements
```

**Response:** HTTP 200
```json
[
  {
    "id": "1788897103116",
    "productId": "1788897094299",
    "delta": 10,
    "reason": "Restock",
    "timestamp": "2026-09-08T19:51:43.116Z"
  },
  {
    "id": "1788897151782",
    "productId": "1788897094299",
    "delta": -5,
    "reason": "Sale",
    "timestamp": "2026-09-08T19:52:31.782Z"
  }
]
```

### POST /api/movements

Records a stock adjustment for a product.

**Request:** HTTP 201
```
POST http://localhost:<port>/api/movements
Content-Type: application/json

{
  "productId": "1788897094299",
  "delta": 15,
  "reason": "Restock shipment received"
}
```

**Response:** HTTP 201 (Created)
```json
{
  "id": "1788897312455",
  "productId": "1788897094299",
  "delta": 15,
  "reason": "Restock shipment received",
  "timestamp": "2026-09-08T19:55:12.455Z",
  "quantity": 130
}
```

**Validation Errors:**

- **HTTP 400** — Invalid input (zero/non-integer delta or blank reason)
  ```json
  {
    "error": "delta must be a nonzero integer"
  }
  ```
  ```json
  {
    "error": "reason is required and must be nonblank"
  }
  ```

- **HTTP 404** — Product not found
  ```json
  {
    "error": "Product not found"
  }
  ```

- **HTTP 409** — Insufficient stock (movement would result in negative quantity)
  ```json
  {
    "error": "Insufficient stock"
  }
  ```

### GET /api/summary

Returns aggregate inventory statistics.

**Request:**
```
GET http://localhost:<port>/api/summary
```

**Response:** HTTP 200
```json
{
  "productCount": 6,
  "totalUnits": 320,
  "lowStockCount": 1
}
```

- **productCount**: Total number of products
- **totalUnits**: Sum of quantities across all products
- **lowStockCount**: Number of products where `quantity <= reorderLevel`

## Status Codes

The API uses the following HTTP status codes:

| Code | Meaning | Example |
|------|---------|---------|
| **200** | OK — Successful GET request | GET /api/products |
| **201** | Created — Successful POST request | POST /api/products, POST /api/movements |
| **400** | Bad Request — Validation failed (blank/missing fields, non-integer values, zero delta) | Invalid SKU, quantity must be integer |
| **404** | Not Found — Product ID doesn't exist (for movements) | Unknown productId in movement |
| **409** | Conflict — Business rule violated (duplicate SKU, insufficient stock) | Duplicate SKU, negative stock |

## Static Files

The app serves the following static assets:

- `index.html` — Main page with forms and tables
- `app.js` — Client-side JavaScript for API calls and UI interactions
- `style.css` — Responsive styling for desktop and mobile

Access them at:
- `http://localhost:<port>/` or `http://localhost:<port>/index.html`
- `http://localhost:<port>/app.js`
- `http://localhost:<port>/style.css`

## Architecture

### Server-Side (server.js)
- Built with Node.js `http` module (no Express or other frameworks)
- Parses JSON request bodies
- Validates all inputs with detailed error messages
- Persists data to `data.json` using `fs` module
- Serves static HTML, CSS, and JavaScript files
- Implements complete RESTful API contract

### Client-Side (app.js)
- Fetches all data on page load via API
- Dynamically renders products, movements, and summary
- Handles form submissions with client-side validation
- Displays loading, empty, and error states
- Auto-updates select dropdowns and tables after API changes

### Styling (style.css)
- Responsive flexbox layout
- Mobile-optimized viewport handling (390px minimum)
- Low-stock row highlighting with `#fff3cd` background
- Internal scroll container for inventory table on small screens
- Accessible form labels with `<label for>` associations

## Verification

The app has been verified to:
- ✓ Load and serve HTML, CSS, and JavaScript correctly
- ✓ Accept and validate product creation with all required fields
- ✓ Reject duplicate SKUs with HTTP 409
- ✓ Reject invalid inputs with HTTP 400
- ✓ Record and retrieve stock movements
- ✓ Prevent negative stock (HTTP 409)
- ✓ Calculate correct summary statistics
- ✓ Persist data to `data.json` across server restarts
- ✓ Handle unknown product IDs with HTTP 404
- ✓ Display low-stock items in the inventory table
- ✓ Fit responsive layout on 390px viewport with no horizontal overflow
- ✓ Display zero console errors and no failed HTTP requests

## Example Workflow

1. Start the server:
   ```bash
   node server.js
   ```

2. Open the app in your browser at the printed address (e.g., `http://localhost:<port>`)

3. Add a product using the "Add New Product" form:
   - SKU: `SKU001`
   - Product Name: `Widget A`
   - Quantity: `100`
   - Reorder Level: `10`

4. Click "Add Product" — the inventory table updates with the new item

5. Adjust stock using the "Adjust Stock" form:
   - Select "Widget A" from the dropdown
   - Delta: `-10` (reduce by 10)
   - Reason: `Sale`
   - Click "Record Movement"

6. The Movement History updates, product quantity decreases, and summary recalculates in real time

7. Restart the server — all data persists in `data.json`

## Troubleshooting

- **Port already in use**: Set a different port with `PORT=8080 node server.js`
- **Data not persisting**: Ensure the app has write permission to the directory containing `server.js`
- **CORS errors in browser**: The server includes CORS headers for all origins
- **Form not submitting**: Check the browser console for validation error messages
- **Duplicate SKU error**: SKUs are case-sensitive and must be unique
