const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

const DATA_FILE = path.join(__dirname, 'data.json');

// Load data from file
function loadData() {
  try {
    if (fs.existsSync(DATA_FILE)) {
      const data = fs.readFileSync(DATA_FILE, 'utf-8');
      return JSON.parse(data);
    }
  } catch (e) {
    console.error('Error loading data:', e.message);
  }
  return { products: [], movements: [] };
}

// Save data to file
function saveData(data) {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (e) {
    console.error('Error saving data:', e.message);
  }
}

// Serve static file
function serveStaticFile(filePath, res) {
  const fullPath = path.join(__dirname, filePath);
  fs.readFile(fullPath, 'utf-8', (err, content) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('Not Found');
      return;
    }
    
    let contentType = 'text/plain';
    if (filePath.endsWith('.html')) contentType = 'text/html';
    else if (filePath.endsWith('.js')) contentType = 'application/javascript';
    else if (filePath.endsWith('.css')) contentType = 'text/css';
    
    res.writeHead(200, { 'Content-Type': contentType });
    res.end(content);
  });
}

// Parse JSON body
function parseBody(req, callback) {
  let body = '';
  req.on('data', chunk => {
    body += chunk.toString();
  });
  req.on('end', () => {
    try {
      const data = JSON.parse(body);
      callback(null, data);
    } catch (e) {
      callback(e);
    }
  });
}

// Validate product input
function validateProduct(product) {
  if (!product.sku || typeof product.sku !== 'string' || product.sku.trim() === '') {
    return { valid: false, error: 'sku is required and must be nonblank' };
  }
  if (!product.name || typeof product.name !== 'string' || product.name.trim() === '') {
    return { valid: false, error: 'name is required and must be nonblank' };
  }
  if (!Number.isInteger(product.quantity) || product.quantity < 0) {
    return { valid: false, error: 'quantity must be a nonnegative integer' };
  }
  if (!Number.isInteger(product.reorderLevel) || product.reorderLevel < 0) {
    return { valid: false, error: 'reorderLevel must be a nonnegative integer' };
  }
  return { valid: true };
}

// Validate movement input
function validateMovement(movement) {
  if (!Number.isInteger(movement.delta) || movement.delta === 0) {
    return { valid: false, error: 'delta must be a nonzero integer' };
  }
  if (!movement.reason || typeof movement.reason !== 'string' || movement.reason.trim() === '') {
    return { valid: false, error: 'reason is required and must be nonblank' };
  }
  return { valid: true };
}

const server = http.createServer((req, res) => {
  const parsedUrl = url.parse(req.url, true);
  const pathname = parsedUrl.pathname;

  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.writeHead(200);
    res.end();
    return;
  }

  // Serve static files
  if (pathname === '/' || pathname === '/index.html') {
    serveStaticFile('index.html', res);
    return;
  }
  if (pathname === '/app.js') {
    serveStaticFile('app.js', res);
    return;
  }
  if (pathname === '/style.css') {
    serveStaticFile('style.css', res);
    return;
  }

  // API routes
  if (pathname === '/api/products' && req.method === 'GET') {
    const data = loadData();
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(data.products));
    return;
  }

  if (pathname === '/api/products' && req.method === 'POST') {
    parseBody(req, (err, product) => {
      if (err) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Invalid JSON' }));
        return;
      }

      const validation = validateProduct(product);
      if (!validation.valid) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: validation.error }));
        return;
      }

      const data = loadData();
      
      // Check for duplicate SKU
      if (data.products.some(p => p.sku === product.sku)) {
        res.writeHead(409, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'SKU already exists' }));
        return;
      }

      // Create new product with unique id
      const newProduct = {
        id: Date.now().toString(),
        sku: product.sku,
        name: product.name,
        quantity: product.quantity,
        reorderLevel: product.reorderLevel
      };

      data.products.push(newProduct);
      saveData(data);

      res.writeHead(201, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(newProduct));
    });
    return;
  }

  if (pathname === '/api/movements' && req.method === 'GET') {
    const data = loadData();
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(data.movements));
    return;
  }

  if (pathname === '/api/movements' && req.method === 'POST') {
    parseBody(req, (err, movement) => {
      if (err) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Invalid JSON' }));
        return;
      }

      const validation = validateMovement(movement);
      if (!validation.valid) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: validation.error }));
        return;
      }

      const data = loadData();

      // Find product
      const product = data.products.find(p => p.id === movement.productId);
      if (!product) {
        res.writeHead(404, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Product not found' }));
        return;
      }

      // Check if movement would result in negative stock
      const newQuantity = product.quantity + movement.delta;
      if (newQuantity < 0) {
        res.writeHead(409, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Insufficient stock' }));
        return;
      }

      // Update product quantity
      product.quantity = newQuantity;

      // Record movement
      const newMovement = {
        id: Date.now().toString(),
        productId: movement.productId,
        delta: movement.delta,
        reason: movement.reason,
        timestamp: new Date().toISOString()
      };
      data.movements.push(newMovement);

      saveData(data);

      res.writeHead(201, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ...newMovement, quantity: product.quantity }));
    });
    return;
  }

  if (pathname === '/api/summary' && req.method === 'GET') {
    const data = loadData();
    const summary = {
      productCount: data.products.length,
      totalUnits: data.products.reduce((sum, p) => sum + p.quantity, 0),
      lowStockCount: data.products.filter(p => p.quantity <= p.reorderLevel).length
    };
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(summary));
    return;
  }

  // 404
  res.writeHead(404, { 'Content-Type': 'text/plain' });
  res.end('Not Found');
});

const PORT = Number(process.env.PORT) || 0;
server.listen(PORT, '0.0.0.0', () => {
  const actualPort = server.address().port;
  console.log(`LISTENING_ON_PORT=${actualPort}`);
});
