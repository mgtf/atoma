const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

// Data persistence
const dataFile = path.join(__dirname, 'data.json');

function loadTasks() {
  try {
    if (fs.existsSync(dataFile)) {
      const data = fs.readFileSync(dataFile, 'utf8');
      return JSON.parse(data);
    }
  } catch (e) {
    console.error('Error loading tasks:', e.message);
  }
  return [];
}

function saveTasks(tasks) {
  try {
    fs.writeFileSync(dataFile, JSON.stringify(tasks, null, 2), 'utf8');
  } catch (e) {
    console.error('Error saving tasks:', e.message);
  }
}

// In-memory task storage
let tasks = loadTasks();

// Generate unique ID
function generateId() {
  return Math.max(0, ...tasks.map(t => t.id || 0)) + 1;
}

// Validation helpers
function isValidStatus(status) {
  return ['todo', 'doing', 'done'].includes(status);
}

function isValidPriority(priority) {
  return ['low', 'medium', 'high'].includes(priority);
}

function parseJson(body) {
  try {
    return [JSON.parse(body), null];
  } catch (e) {
    return [null, 'Malformed JSON'];
  }
}

function sendResponse(res, statusCode, data) {
  res.writeHead(statusCode, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify(data));
}

function sendFile(res, filePath, contentType) {
  try {
    const content = fs.readFileSync(filePath, 'utf8');
    res.writeHead(200, { 'Content-Type': contentType });
    res.end(content);
  } catch (e) {
    res.writeHead(404, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Not Found' }));
  }
}

// Create server
const server = http.createServer((req, res) => {
  const parsedUrl = url.parse(req.url, true);
  const pathname = parsedUrl.pathname;
  const method = req.method;

  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PATCH, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (method === 'OPTIONS') {
    res.writeHead(200);
    res.end();
    return;
  }

  // Static files
  if (pathname === '/' || pathname === '/index.html') {
    return sendFile(res, path.join(__dirname, 'index.html'), 'text/html');
  }
  if (pathname === '/app.js') {
    return sendFile(res, path.join(__dirname, 'app.js'), 'text/javascript');
  }
  if (pathname === '/style.css') {
    return sendFile(res, path.join(__dirname, 'style.css'), 'text/css');
  }

  // API routes
  if (pathname === '/api/tasks' && method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(tasks));
    return;
  }

  if (pathname === '/api/tasks' && method === 'POST') {
    let body = '';
    req.on('data', chunk => {
      body += chunk.toString();
    });
    req.on('end', () => {
      const [data, err] = parseJson(body);
      if (err) {
        return sendResponse(res, 400, { error: 'Malformed JSON' });
      }

      // Validation
      if (!data.title || typeof data.title !== 'string' || !data.title.trim()) {
        return sendResponse(res, 400, { error: 'Title is required and cannot be blank' });
      }
      if (!data.status || !isValidStatus(data.status)) {
        return sendResponse(res, 400, { error: 'Status must be one of: todo, doing, done' });
      }
      if (!data.priority || !isValidPriority(data.priority)) {
        return sendResponse(res, 400, { error: 'Priority must be one of: low, medium, high' });
      }

      const newTask = {
        id: generateId(),
        title: data.title.trim(),
        status: data.status,
        priority: data.priority
      };
      tasks.push(newTask);
      saveTasks(tasks);

      res.writeHead(201, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(newTask));
    });
    return;
  }

  // PATCH /api/tasks/:id
  const patchMatch = pathname.match(/^\/api\/tasks\/(\d+)$/);
  if (patchMatch && method === 'PATCH') {
    const taskId = parseInt(patchMatch[1], 10);
    let body = '';
    req.on('data', chunk => {
      body += chunk.toString();
    });
    req.on('end', () => {
      const [data, err] = parseJson(body);
      if (err) {
        return sendResponse(res, 400, { error: 'Malformed JSON' });
      }

      const task = tasks.find(t => t.id === taskId);
      if (!task) {
        return sendResponse(res, 404, { error: 'Task not found' });
      }

      // Validate and update only supplied fields
      if (data.title !== undefined) {
        if (typeof data.title !== 'string' || !data.title.trim()) {
          return sendResponse(res, 400, { error: 'Title cannot be blank' });
        }
        task.title = data.title.trim();
      }
      if (data.status !== undefined) {
        if (!isValidStatus(data.status)) {
          return sendResponse(res, 400, { error: 'Status must be one of: todo, doing, done' });
        }
        task.status = data.status;
      }
      if (data.priority !== undefined) {
        if (!isValidPriority(data.priority)) {
          return sendResponse(res, 400, { error: 'Priority must be one of: low, medium, high' });
        }
        task.priority = data.priority;
      }

      saveTasks(tasks);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(task));
    });
    return;
  }

  // DELETE /api/tasks/:id
  const deleteMatch = pathname.match(/^\/api\/tasks\/(\d+)$/);
  if (deleteMatch && method === 'DELETE') {
    const taskId = parseInt(deleteMatch[1], 10);
    const index = tasks.findIndex(t => t.id === taskId);
    if (index === -1) {
      return sendResponse(res, 404, { error: 'Task not found' });
    }
    tasks.splice(index, 1);
    saveTasks(tasks);
    res.writeHead(204);
    res.end();
    return;
  }

  // Not found
  res.writeHead(404, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ error: 'Not Found' }));
});

const port = Number(process.env.PORT) || 0;
server.listen(port, '0.0.0.0', () => {
  const boundPort = server.address().port;
  console.log('LISTENING_ON_PORT=' + boundPort);
});
