# Kanban Board App

A polished Kanban web application built with Node.js (no dependencies), featuring task management with status tracking (todo, doing, done), priority levels (low, medium, high), search, and filtering capabilities.

## Quick Start

### Prerequisites
- Node.js (any modern version)

### Installation & Running

```bash
# Run the server
PORT=3000 node server.js

# Output:
# LISTENING_ON_PORT=3000

# Server will be available at:
# http://localhost:3000
```

The server accepts any PORT via the `PORT` environment variable and will bind to a random available port if `PORT` is not specified.

### File Structure

```
.
├── server.js       # HTTP server with API endpoints
├── index.html      # HTML interface
├── app.js          # Client-side JavaScript
├── style.css       # Styling
└── data.json       # Persistent task storage (auto-created)
```

## API Endpoints

All API responses are JSON. The server supports CORS for development.

### GET /api/tasks

Returns a list of all tasks.

**Request:**
```
GET /api/tasks
```

**Response (200 OK):**
```json
[
  {
    "id": 1,
    "title": "Buy groceries",
    "status": "doing",
    "priority": "low"
  },
  {
    "id": 2,
    "title": "Write documentation",
    "status": "doing",
    "priority": "low"
  }
]
```

**Status Code:** `200 OK`

---

### POST /api/tasks

Creates a new task.

**Request:**
```
POST /api/tasks
Content-Type: application/json

{
  "title": "Test Task",
  "status": "todo",
  "priority": "medium"
}
```

**Response (201 Created):**
```json
{
  "id": 14,
  "title": "Test Task",
  "status": "todo",
  "priority": "medium"
}
```

**Status Code:** `201 Created`

The server auto-generates a unique `id` for each task.

#### Valid Enum Values

- **status**: `"todo"`, `"doing"`, `"done"`
- **priority**: `"low"`, `"medium"`, `"high"`

#### Error Cases

**Blank/Missing Title (400 Bad Request):**
```
POST /api/tasks
Content-Type: application/json

{
  "title": "",
  "status": "todo",
  "priority": "medium"
}
```

Response:
```json
{
  "error": "Title is required and cannot be blank"
}
```

**Whitespace-Only Title (400 Bad Request):**
```
POST /api/tasks
Content-Type: application/json

{
  "title": "   ",
  "status": "todo",
  "priority": "medium"
}
```

Response:
```json
{
  "error": "Title is required and cannot be blank"
}
```

**Invalid Status (400 Bad Request):**
```
POST /api/tasks
Content-Type: application/json

{
  "title": "Task",
  "status": "invalid",
  "priority": "medium"
}
```

Response:
```json
{
  "error": "Status must be one of: todo, doing, done"
}
```

**Missing Status (400 Bad Request):**
```
POST /api/tasks
Content-Type: application/json

{
  "title": "Task",
  "priority": "medium"
}
```

Response:
```json
{
  "error": "Status must be one of: todo, doing, done"
}
```

**Invalid Priority (400 Bad Request):**
```
POST /api/tasks
Content-Type: application/json

{
  "title": "Task",
  "status": "todo",
  "priority": "urgent"
}
```

Response:
```json
{
  "error": "Priority must be one of: low, medium, high"
}
```

**Missing Priority (400 Bad Request):**
```
POST /api/tasks
Content-Type: application/json

{
  "title": "Task",
  "status": "todo"
}
```

Response:
```json
{
  "error": "Priority must be one of: low, medium, high"
}
```

**Malformed JSON (400 Bad Request):**
```
POST /api/tasks
Content-Type: application/json

{ invalid json }
```

Response:
```json
{
  "error": "Malformed JSON"
}
```

---

### PATCH /api/tasks/:id

Updates one or more fields of an existing task. Only supplied fields are modified.

**Request:**
```
PATCH /api/tasks/14
Content-Type: application/json

{
  "status": "doing"
}
```

**Response (200 OK):**
```json
{
  "id": 14,
  "title": "Test Task",
  "status": "doing",
  "priority": "medium"
}
```

**Status Code:** `200 OK`

#### Update Multiple Fields

```
PATCH /api/tasks/1
Content-Type: application/json

{
  "title": "Updated title",
  "status": "done",
  "priority": "high"
}
```

Response:
```json
{
  "id": 1,
  "title": "Updated title",
  "status": "done",
  "priority": "high"
}
```

#### Error Cases

**Non-Existent Task ID (404 Not Found):**
```
PATCH /api/tasks/999
Content-Type: application/json

{
  "status": "doing"
}
```

Response:
```json
{
  "error": "Task not found"
}
```

**Status Code:** `404 Not Found`

**Blank Title (400 Bad Request):**
```
PATCH /api/tasks/14
Content-Type: application/json

{
  "title": ""
}
```

Response:
```json
{
  "error": "Title cannot be blank"
}
```

**Status Code:** `400 Bad Request`

**Invalid Status (400 Bad Request):**
```
PATCH /api/tasks/14
Content-Type: application/json

{
  "status": "invalid"
}
```

Response:
```json
{
  "error": "Status must be one of: todo, doing, done"
}
```

**Status Code:** `400 Bad Request`

**Invalid Priority (400 Bad Request):**
```
PATCH /api/tasks/14
Content-Type: application/json

{
  "priority": "urgent"
}
```

Response:
```json
{
  "error": "Priority must be one of: low, medium, high"
}
```

**Status Code:** `400 Bad Request`

**Malformed JSON (400 Bad Request):**
```
PATCH /api/tasks/14
Content-Type: application/json

{ invalid json }
```

Response:
```json
{
  "error": "Malformed JSON"
}
```

**Status Code:** `400 Bad Request`

---

### DELETE /api/tasks/:id

Deletes an existing task.

**Request:**
```
DELETE /api/tasks/14
```

**Response (204 No Content):**
```
(empty body)
```

**Status Code:** `204 No Content`

#### Error Cases

**Non-Existent Task ID (404 Not Found):**
```
DELETE /api/tasks/999
```

Response:
```json
{
  "error": "Task not found"
}
```

**Status Code:** `404 Not Found`

---

## Data Persistence

Tasks are automatically persisted to `data.json` in the application directory. The persistence system works as follows:

- **On Startup:** The server loads all tasks from `data.json` if it exists, otherwise starts with an empty task list.
- **On Modification:** After every POST, PATCH, or DELETE operation, the updated task list is written back to `data.json`.
- **Format:** The file stores a JSON array of task objects with `id`, `title`, `status`, and `priority` fields.

### Example data.json

```json
[
  {
    "id": 1,
    "title": "Buy groceries",
    "status": "doing",
    "priority": "low"
  },
  {
    "id": 4,
    "title": "Write documentation",
    "status": "doing",
    "priority": "low"
  },
  {
    "id": 5,
    "title": "Review pull request",
    "status": "done",
    "priority": "medium"
  }
]
```

Tasks persist across server restarts.

## User Interface

The web interface provides:

- **Create Form:** Add new tasks with title, status, and priority
- **Search:** Filter tasks by title in real-time
- **Priority Filter:** Filter by low, medium, or high priority
- **Kanban Board:** Three-column layout (Todo, Doing, Done)
- **Task Cards:** Display task ID, title, priority badge, status
- **Task Actions:** Edit (update title and priority), Move (change status), Delete (remove task)
- **Column Counters:** Show the number of tasks in each status column

## Testing

All four API endpoints have been tested with:

- ✅ Valid payloads returning appropriate success codes (201 for creation, 200 for updates, 204 for deletion, 200 for retrieval)
- ✅ Invalid enums (status and priority) returning 400 errors
- ✅ Blank or missing required fields returning 400 errors
- ✅ Malformed JSON returning 400 errors
- ✅ Non-existent task IDs returning 404 errors
- ✅ Partial updates (PATCH with only some fields)
- ✅ Task persistence across multiple operations and server restarts
- ✅ Auto-incremented ID generation
- ✅ Static file serving (index.html, app.js, style.css)

All documented examples are based on recorded probes from earlier test phases.

## Notes

- The app requires no npm dependencies; it uses only Node.js built-in modules (`http`, `fs`, `path`, `url`)
- All data is stored in `data.json` in the same directory as `server.js`
- CORS headers are enabled for cross-origin requests during development
- Task IDs are auto-generated as sequential integers starting from 1
