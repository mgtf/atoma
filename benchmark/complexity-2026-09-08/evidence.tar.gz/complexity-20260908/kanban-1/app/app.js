let tasks = [];
let filteredTasks = [];
let searchQuery = '';
let priorityFilter = '';

async function loadTasks() {
  try {
    const response = await fetch('/api/tasks');
    if (response.ok) {
      tasks = await response.json();
      applyFilters();
      renderBoard();
    }
  } catch (e) {
    console.error('Error loading tasks:', e);
  }
}

function applyFilters() {
  filteredTasks = tasks.filter(task => {
    const matchesSearch = task.title.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesPriority = !priorityFilter || task.priority === priorityFilter;
    return matchesSearch && matchesPriority;
  });
}

function renderBoard() {
  const columns = ['todo', 'doing', 'done'];
  
  columns.forEach(status => {
    const columnEl = document.getElementById(status);
    columnEl.innerHTML = '';
    
    const tasksInColumn = filteredTasks.filter(t => t.status === status);
    
    if (tasksInColumn.length === 0) {
      columnEl.innerHTML = '<div class="empty-state">No tasks yet</div>';
    } else {
      tasksInColumn.forEach(task => {
        const taskEl = createTaskElement(task);
        columnEl.appendChild(taskEl);
      });
    }

    // Update column count
    const allTasksInColumn = tasks.filter(t => t.status === status);
    document.getElementById(`${status}-count`).textContent = allTasksInColumn.length;
  });
}

function createTaskElement(task) {
  const taskEl = document.createElement('div');
  taskEl.className = `task priority-${task.priority}`;
  taskEl.id = `task-${task.id}`;
  
  taskEl.innerHTML = `
    <div class="task-header">
      <h3 class="task-title">${escapeHtml(task.title)}</h3>
      <span class="task-id">#${task.id}</span>
    </div>
    <div class="task-meta">
      <span class="priority-badge priority-${task.priority}">${task.priority}</span>
      <span class="status-badge">${task.status}</span>
    </div>
    <div class="task-actions">
      <button class="btn-edit" data-id="${task.id}" aria-label="Edit task">Edit</button>
      <select class="btn-move" data-id="${task.id}" aria-label="Move task to">
        <option value="">Move to...</option>
        <option value="todo" ${task.status === 'todo' ? 'selected' : ''}>Todo</option>
        <option value="doing" ${task.status === 'doing' ? 'selected' : ''}>Doing</option>
        <option value="done" ${task.status === 'done' ? 'selected' : ''}>Done</option>
      </select>
      <button class="btn-delete" data-id="${task.id}" aria-label="Delete task">Delete</button>
    </div>
  `;

  // Edit button handler
  taskEl.querySelector('.btn-edit').addEventListener('click', () => {
    editTask(task.id);
  });

  // Move select handler
  taskEl.querySelector('.btn-move').addEventListener('change', (e) => {
    const newStatus = e.target.value;
    if (newStatus) {
      moveTask(task.id, newStatus);
      e.target.value = '';
    }
  });

  // Delete button handler
  taskEl.querySelector('.btn-delete').addEventListener('click', () => {
    deleteTask(task.id);
  });

  return taskEl;
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

async function addTask(e) {
  e.preventDefault();
  
  const title = document.getElementById('task-title').value.trim();
  const status = document.getElementById('task-status').value;
  const priority = document.getElementById('task-priority').value;

  if (!title) {
    alert('Please enter a task title');
    return;
  }

  try {
    const response = await fetch('/api/tasks', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title, status, priority })
    });

    if (response.status === 201) {
      document.getElementById('task-title').value = '';
      document.getElementById('task-status').value = 'todo';
      document.getElementById('task-priority').value = 'low';
      await loadTasks();
    } else {
      const error = await response.json();
      alert('Error: ' + (error.error || 'Unknown error'));
    }
  } catch (e) {
    console.error('Error adding task:', e);
  }
}

async function editTask(id) {
  const task = tasks.find(t => t.id === id);
  if (!task) return;

  const newTitle = prompt('Edit task title:', task.title);
  if (newTitle === null) return;

  if (!newTitle.trim()) {
    alert('Title cannot be empty');
    return;
  }

  const newPriority = prompt('Edit priority (low/medium/high):', task.priority);
  if (newPriority === null) return;

  if (!['low', 'medium', 'high'].includes(newPriority.toLowerCase())) {
    alert('Invalid priority. Use: low, medium, or high');
    return;
  }

  try {
    const response = await fetch(`/api/tasks/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        title: newTitle.trim(),
        priority: newPriority.toLowerCase()
      })
    });

    if (response.ok) {
      await loadTasks();
    } else {
      const error = await response.json();
      alert('Error: ' + (error.error || 'Unknown error'));
    }
  } catch (e) {
    console.error('Error editing task:', e);
  }
}

async function moveTask(id, newStatus) {
  try {
    const response = await fetch(`/api/tasks/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: newStatus })
    });

    if (response.ok) {
      await loadTasks();
    } else {
      const error = await response.json();
      alert('Error: ' + (error.error || 'Unknown error'));
    }
  } catch (e) {
    console.error('Error moving task:', e);
  }
}

async function deleteTask(id) {
  if (!confirm('Are you sure you want to delete this task?')) {
    return;
  }

  try {
    const response = await fetch(`/api/tasks/${id}`, { method: 'DELETE' });
    if (response.status === 204 || response.ok) {
      await loadTasks();
    } else {
      const error = await response.json();
      alert('Error: ' + (error.error || 'Unknown error'));
    }
  } catch (e) {
    console.error('Error deleting task:', e);
  }
}

// Event listeners
document.getElementById('task-form').addEventListener('submit', addTask);

document.getElementById('search-input').addEventListener('input', (e) => {
  searchQuery = e.target.value;
  applyFilters();
  renderBoard();
});

document.getElementById('priority-filter').addEventListener('change', (e) => {
  priorityFilter = e.target.value;
  applyFilters();
  renderBoard();
});

// Load tasks on page load
document.addEventListener('DOMContentLoaded', () => {
  loadTasks();
});
