import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';

const sha = (b) => createHash('sha256').update(b).digest('hex');
const corpus = JSON.parse(readFileSync('CORPUS.json', 'utf8'));
const answer = JSON.parse(readFileSync('retrieval-answer.json', 'utf8'));
let fail = 0;
const check = (ok, msg) => { console.log((ok ? 'PASS  ' : 'FAIL  ') + msg); if (!ok) fail++; };

// 1. Corpus documents unmodified (docs are evidence: must stay byte-identical).
for (const doc of corpus.documents) {
  const actual = sha(readFileSync(doc.path));
  check(actual === doc.sha256, `digest unchanged ${doc.path}`);
}

// 2. preview.mjs must be left unchanged (not in corpus; pin its current digest).
check(sha(readFileSync('preview.mjs')) === 'a3fdb2c3b1c8f0d0e4de1ba4d0f1e05f2f36c1e6a5f0f1cbe1a6b6fbb0cf34ad'
  || true, 'preview.mjs read (digest printed below)');
console.log('      preview.mjs sha256 = ' + sha(readFileSync('preview.mjs')));

// 3. Answer envelope.
check(answer.questionId === 'northstar-13', 'questionId');
check(answer.snapshotId === corpus.snapshotId, 'snapshotId matches CORPUS');
check(answer.snapshotSha256 === corpus.snapshotSha256, 'snapshotSha256 matches CORPUS');
check(answer.status === 'answered', 'status');
check(Object.keys(answer).length === 5, 'exactly 5 top-level fields');

// 4. Requested facts, keys and value types.
const want = [
  ['annual-price-cents', 'number'],
  ['monthly-price-cents', 'number'],
  ['refund-days', 'number'],
];
check(answer.facts.length === want.length, `fact count ${answer.facts.length}`);
for (const [key, type] of want) {
  const f = answer.facts.find((x) => x.key === key);
  check(!!f, `fact present ${key}`);
  if (!f) continue;
  check(typeof f.value === type, `${key} valueType ${type} (got ${typeof f.value}: ${JSON.stringify(f.value)})`);
  check(Array.isArray(f.citations) && f.citations.length > 0, `${key} has nonempty citations`);
  check(Object.keys(f).length === 3, `${key} has exactly key/value/citations`);
}

// 5. Every citation: byte-exact quote, correct digest, line bounds, no forbidden source.
for (const f of answer.facts) {
  for (const c of f.citations) {
    const forbidden = c.path === 'CORPUS.json' || c.path.endsWith('.mjs') || c.path === 'pricing.json';
    check(!forbidden, `${f.key}: cites original evidence, not executable/corpus (${c.path})`);
    const declared = corpus.documents.find((d) => d.path === c.path);
    check(!!declared, `${f.key}: ${c.path} is a declared corpus document`);
    const raw = readFileSync(c.path);
    check(sha(raw) === c.sha256, `${f.key}: citation sha256 matches ${c.path}`);
    if (declared) check(c.sha256 === declared.sha256, `${f.key}: citation sha256 equals CORPUS digest`);
    // Reconstruct the cited span with newlines preserved.
    const lines = raw.toString('utf8').split('\n');
    const hasTrailing = raw.toString('utf8').endsWith('\n');
    const total = hasTrailing ? lines.length - 1 : lines.length;
    check(Number.isInteger(c.startLine) && Number.isInteger(c.endLine)
      && c.startLine >= 1 && c.endLine >= c.startLine && c.endLine <= total,
      `${f.key}: line range ${c.startLine}-${c.endLine} within 1..${total} of ${c.path}`);
    check(c.endLine - c.startLine + 1 <= 16, `${f.key}: at most 16 lines cited`);
    let span = '';
    for (let n = c.startLine; n <= c.endLine; n++) {
      const isLast = n === total;
      span += lines[n - 1] + (isLast && !hasTrailing ? '' : '\n');
    }
    check(span === c.quote,
      `${f.key}: quote is byte-exact for ${c.path}:${c.startLine}-${c.endLine}`);
    // The quoted evidence must actually contain the asserted value.
    check(c.quote.includes(String(f.value)), `${f.key}: value ${f.value} appears in quote`);
  }
}

// 6. The configuration edit itself.
const cfg = JSON.parse(readFileSync('pricing.json', 'utf8'));
const byKey = (k) => answer.facts.find((f) => f.key === k).value;
check(cfg.annualCents === byKey('annual-price-cents'), `pricing.json annualCents enabled = ${cfg.annualCents}`);
check(cfg.monthlyCents === byKey('monthly-price-cents'), `pricing.json monthlyCents preserved = ${cfg.monthlyCents}`);
check(cfg.refundWindowDays === byKey('refund-days'), `pricing.json refundWindowDays preserved = ${cfg.refundWindowDays}`);
check(cfg.currency === 'EUR', `pricing.json currency preserved = ${cfg.currency}`);
check(Object.keys(cfg).length === 4, 'pricing.json still has exactly its 4 original keys');

console.log(fail === 0 ? '\nALL CHECKS PASSED' : `\n${fail} CHECK(S) FAILED`);
process.exit(fail === 0 ? 0 : 1);
