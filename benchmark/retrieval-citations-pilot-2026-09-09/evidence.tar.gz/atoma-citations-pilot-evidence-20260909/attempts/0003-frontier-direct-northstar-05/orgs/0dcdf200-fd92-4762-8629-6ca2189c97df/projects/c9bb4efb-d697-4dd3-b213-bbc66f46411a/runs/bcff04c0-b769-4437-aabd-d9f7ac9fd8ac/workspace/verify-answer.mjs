#!/usr/bin/env node
// Verifies retrieval-answer.json against the supplied corpus.
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';

const sha256 = (buf) => createHash('sha256').update(buf).digest('hex');
const fails = [];
const check = (ok, label) => {
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${label}`);
  if (!ok) fails.push(label);
};

const corpus = JSON.parse(readFileSync('CORPUS.json', 'utf8'));
const byPath = new Map(corpus.documents.map((d) => [d.path, d]));
const answer = JSON.parse(readFileSync('retrieval-answer.json', 'utf8'));

// 1. Corpus integrity: supplied files unchanged.
for (const doc of corpus.documents) {
  const bytes = readFileSync(doc.path);
  check(sha256(bytes) === doc.sha256 && bytes.length === doc.bytes,
    `corpus intact: ${doc.path}`);
}

// 2. Envelope: exactly the required fields, with required values.
check(
  JSON.stringify(Object.keys(answer).sort()) ===
    JSON.stringify(['facts', 'questionId', 'snapshotId', 'snapshotSha256', 'status']),
  'exactly the 5 required top-level fields');
check(answer.questionId === 'northstar-05', 'questionId === northstar-05');
check(answer.snapshotId === 'northstar-v1', 'snapshotId === northstar-v1');
check(answer.snapshotSha256 === corpus.snapshotSha256, 'snapshotSha256 matches CORPUS.json');
check(answer.status === 'answered' || answer.status === 'not_found', 'status in {answered,not_found}');
check(Array.isArray(answer.facts), 'facts is an array');

// 3. Requested fact contract.
const requested = [{ key: 'refund-days', valueType: 'number' }];
if (answer.status === 'not_found') {
  check(answer.facts.length === 0, 'not_found implies empty facts');
} else {
  check(
    JSON.stringify(answer.facts.map((f) => f.key)) === JSON.stringify(requested.map((r) => r.key)),
    'fact keys match the requested keys exactly');
  for (const req of requested) {
    const fact = answer.facts.find((f) => f.key === req.key);
    if (!fact) { check(false, `fact present: ${req.key}`); continue; }
    check(
      JSON.stringify(Object.keys(fact).sort()) === JSON.stringify(['citations', 'key', 'value']),
      `fact ${req.key}: exactly key/value/citations`);
    check(typeof fact.value === req.valueType, `fact ${req.key}: value is ${req.valueType} (got ${JSON.stringify(fact.value)})`);
    check(fact.value !== null && typeof fact.value !== 'object',
      `fact ${req.key}: value is a JSON scalar`);
    check(Array.isArray(fact.citations) && fact.citations.length > 0,
      `fact ${req.key}: citations nonempty`);

    for (const [i, c] of (fact.citations ?? []).entries()) {
      const tag = `fact ${req.key} citation[${i}]`;
      check(
        JSON.stringify(Object.keys(c).sort()) ===
          JSON.stringify(['endLine', 'path', 'quote', 'sha256', 'startLine']),
        `${tag}: exactly the 5 citation fields`);

      const doc = byPath.get(c.path);
      check(Boolean(doc), `${tag}: path is a declared corpus document (${c.path})`);
      check(!/^CORPUS\.json$|\.mjs$|\.js$/.test(c.path),
        `${tag}: not CORPUS.json nor an executable asset`);
      if (!doc) continue;
      check(c.sha256 === doc.sha256, `${tag}: sha256 matches the document digest`);

      // Line numbers: 1-based, inclusive, within range, <= 16 lines.
      const raw = readFileSync(c.path, 'utf8');
      const hasTrailingNewline = raw.endsWith('\n');
      const lines = raw.split('\n');
      if (hasTrailingNewline) lines.pop(); // drop artefact of trailing newline
      check(Number.isInteger(c.startLine) && Number.isInteger(c.endLine),
        `${tag}: line numbers are integers`);
      check(c.startLine >= 1 && c.endLine >= c.startLine && c.endLine <= lines.length,
        `${tag}: lines ${c.startLine}-${c.endLine} in range 1-${lines.length}`);
      check(c.endLine - c.startLine + 1 <= 16, `${tag}: cites at most 16 lines`);

      // Byte-exact quote, including the final newline when present in the file.
      const slice = lines.slice(c.startLine - 1, c.endLine);
      const isLastLine = c.endLine === lines.length;
      const expected = slice.join('\n') + (!isLastLine || hasTrailingNewline ? '\n' : '');
      check(c.quote === expected,
        `${tag}: quote is byte-exact for lines ${c.startLine}-${c.endLine}`);

      // The quote must actually be present verbatim in the cited document.
      check(raw.includes(c.quote), `${tag}: quote occurs verbatim in ${c.path}`);

      // The quoted evidence must support the claimed value.
      check(c.quote.includes(String(fact.value)),
        `${tag}: quote contains the asserted value ${JSON.stringify(fact.value)}`);
    }
  }
}

console.log(fails.length === 0
  ? '\nAll checks passed.'
  : `\n${fails.length} check(s) failed:\n- ${fails.join('\n- ')}`);
process.exit(fails.length === 0 ? 0 : 1);
