import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';

const corpus = JSON.parse(readFileSync('CORPUS.json', 'utf8'));
const answer = JSON.parse(readFileSync('retrieval-answer.json', 'utf8'));
const byPath = new Map(corpus.documents.map((d) => [d.path, d]));
const wanted = [
  ['annual-price-cents', 'number'],
  ['monthly-price-cents', 'number'],
  ['refund-days', 'number'],
];
const problems = [];
const check = (cond, msg) => { if (!cond) problems.push(msg); };

check(answer.questionId === 'northstar-13', 'questionId mismatch');
check(answer.snapshotId === corpus.snapshotId, 'snapshotId mismatch');
check(answer.snapshotSha256 === corpus.snapshotSha256, 'snapshotSha256 mismatch');
check(answer.status === 'answered', 'status mismatch');
check(
  JSON.stringify(Object.keys(answer)) ===
    JSON.stringify(['questionId', 'snapshotId', 'snapshotSha256', 'status', 'facts']),
  `unexpected top-level fields: ${Object.keys(answer)}`
);
check(
  answer.facts.map((f) => f.key).join(',') === wanted.map(([k]) => k).join(','),
  'fact keys/order mismatch'
);

for (const [key, valueType] of wanted) {
  const fact = answer.facts.find((f) => f.key === key);
  if (!fact) { problems.push(`missing fact ${key}`); continue; }
  check(typeof fact.value === valueType, `${key}: value type ${typeof fact.value} != ${valueType}`);
  check(Array.isArray(fact.citations) && fact.citations.length > 0, `${key}: citations must be nonempty`);
  for (const c of fact.citations) {
    const label = `${key} -> ${c.path}:${c.startLine}-${c.endLine}`;
    const doc = byPath.get(c.path);
    if (!doc) { problems.push(`${label}: path not in CORPUS`); continue; }
    check(/^docs\/|^README\.md$/.test(c.path), `${label}: unexpected path`);
    check(c.path !== 'CORPUS.json' && !c.path.endsWith('.mjs'), `${label}: forbidden asset cited`);
    const bytes = readFileSync(c.path);
    const sha = createHash('sha256').update(bytes).digest('hex');
    check(sha === doc.sha256, `${label}: file digest drifted from CORPUS`);
    check(c.sha256 === doc.sha256, `${label}: citation sha256 != CORPUS digest`);
    const text = bytes.toString('utf8');
    const lines = text.split('\n').map((l, i, a) => (i === a.length - 1 ? l : l + '\n'));
    if (lines.at(-1) === '') lines.pop();
    check(Number.isInteger(c.startLine) && c.startLine >= 1, `${label}: bad startLine`);
    check(c.endLine >= c.startLine, `${label}: bad endLine`);
    check(c.endLine - c.startLine + 1 <= 16, `${label}: more than 16 lines cited`);
    check(c.endLine <= lines.length, `${label}: endLine beyond EOF (${lines.length})`);
    const exact = lines.slice(c.startLine - 1, c.endLine).join('');
    check(c.quote === exact, `${label}: quote is not byte-exact\n  got: ${JSON.stringify(c.quote)}\n  exp: ${JSON.stringify(exact)}`);
    check(String(fact.value).length > 0 && exact.includes(String(fact.value)) || c.quote !== exact,
      `${label}: value ${fact.value} not present in quoted evidence`);
  }
}

// pricing.json edit contract
const pricing = JSON.parse(readFileSync('pricing.json', 'utf8'));
check(pricing.annualCents === answer.facts[0].value, 'pricing.annualCents != cited annual price');
check(pricing.monthlyCents === answer.facts[1].value, 'pricing.monthlyCents changed');
check(pricing.refundWindowDays === answer.facts[2].value, 'pricing.refundWindowDays changed');
check(pricing.currency === 'EUR', 'pricing.currency changed');
check(Object.keys(pricing).length === 4, 'pricing.json gained/lost keys');
check(
  createHash('sha256').update(readFileSync('preview.mjs')).digest('hex') ===
    'd4240f9af9f5315b9a1685db52004e17575f8fa426abe115aa5224c1f4642b3f',
  'preview.mjs was modified'
);

if (problems.length) {
  console.error('FAIL\n' + problems.map((p) => ' - ' + p).join('\n'));
  process.exit(1);
}
console.log('PASS: answer fields, citation digests, byte-exact quotes, and pricing.json edit all verified');
