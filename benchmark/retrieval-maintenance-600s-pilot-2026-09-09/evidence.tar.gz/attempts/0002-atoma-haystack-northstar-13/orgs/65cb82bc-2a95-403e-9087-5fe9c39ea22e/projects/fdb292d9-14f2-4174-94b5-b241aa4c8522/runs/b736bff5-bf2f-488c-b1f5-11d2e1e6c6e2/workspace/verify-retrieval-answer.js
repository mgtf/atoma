#!/usr/bin/env node

const fs = require('fs');

try {
  const data = JSON.parse(fs.readFileSync('retrieval-answer.json', 'utf8'));
  
  // Assert all required top-level fields exist
  const requiredFields = ['questionId', 'snapshotId', 'snapshotSha256', 'status', 'facts'];
  for (const field of requiredFields) {
    if (!(field in data)) {
      throw new Error(`Missing required field: ${field}`);
    }
  }
  
  // Assert status value
  if (data.status !== 'answered' && data.status !== 'not_found') {
    throw new Error(`Invalid status value: ${data.status}`);
  }
  
  // Assert facts is an array with exactly 3 entries
  if (!Array.isArray(data.facts)) {
    throw new Error('facts is not an array');
  }
  if (data.facts.length !== 3) {
    throw new Error(`Expected 3 facts, got ${data.facts.length}`);
  }
  
  // Expected keys in order
  const expectedKeys = ['monthly-price-cents', 'annual-price-cents', 'refund-days'];
  const actualKeys = data.facts.map(f => f.key);
  
  for (let i = 0; i < expectedKeys.length; i++) {
    if (actualKeys[i] !== expectedKeys[i]) {
      throw new Error(`Fact ${i}: expected key "${expectedKeys[i]}", got "${actualKeys[i]}"`);
    }
  }
  
  // Assert each fact has correct value type (number) and citations
  for (let i = 0; i < data.facts.length; i++) {
    const fact = data.facts[i];
    
    if (typeof fact.value !== 'number') {
      throw new Error(`Fact ${i} (${fact.key}): value is not a number, got ${typeof fact.value}`);
    }
    
    if (!Array.isArray(fact.citations)) {
      throw new Error(`Fact ${i} (${fact.key}): citations is not an array`);
    }
    
    if (fact.citations.length === 0) {
      throw new Error(`Fact ${i} (${fact.key}): citations array is empty`);
    }
    
    for (let j = 0; j < fact.citations.length; j++) {
      const citation = fact.citations[j];
      if (!citation.quote || citation.quote.length === 0) {
        throw new Error(`Fact ${i} (${fact.key}): citation ${j} has empty quote`);
      }
    }
  }
  
  console.log('✓ All validations passed');
  console.log(`✓ questionId: ${data.questionId}`);
  console.log(`✓ snapshotId: ${data.snapshotId}`);
  console.log(`✓ snapshotSha256: ${data.snapshotSha256}`);
  console.log(`✓ status: ${data.status}`);
  console.log(`✓ facts[0]: key="${data.facts[0].key}", value=${data.facts[0].value}, citations=${data.facts[0].citations.length}`);
  console.log(`✓ facts[1]: key="${data.facts[1].key}", value=${data.facts[1].value}, citations=${data.facts[1].citations.length}`);
  console.log(`✓ facts[2]: key="${data.facts[2].key}", value=${data.facts[2].value}, citations=${data.facts[2].citations.length}`);
  process.exit(0);
} catch (err) {
  console.error('✗ Validation failed:', err.message);
  process.exit(1);
}
