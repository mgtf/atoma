const fs = require('fs');
const crypto = require('crypto');
const path = require('path');

// Parse retrieval-answer.json
const answerContent = fs.readFileSync('retrieval-answer.json', 'utf8');
const answer = JSON.parse(answerContent);

// Verify exact field set and value types
console.log('Verifying JSON structure...');
const requiredFields = ['questionId', 'snapshotId', 'snapshotSha256', 'status', 'facts'];
for (const field of requiredFields) {
  if (!(field in answer)) {
    throw new Error(`Missing required field: ${field}`);
  }
}

if (typeof answer.questionId !== 'string') throw new Error('questionId must be string');
if (typeof answer.snapshotId !== 'string') throw new Error('snapshotId must be string');
if (typeof answer.snapshotSha256 !== 'string') throw new Error('snapshotSha256 must be string');
if (typeof answer.status !== 'string') throw new Error('status must be string');
if (!Array.isArray(answer.facts)) throw new Error('facts must be array');

console.log('✓ JSON structure valid');

// Verify facts content
if (answer.status === 'answered') {
  if (answer.facts.length !== 1) {
    throw new Error(`Expected 1 fact for status 'answered', got ${answer.facts.length}`);
  }

  const fact = answer.facts[0];
  if (fact.key !== 'refund-days') {
    throw new Error(`Expected key 'refund-days', got '${fact.key}'`);
  }
  if (typeof fact.value !== 'number') {
    throw new Error(`Expected numeric value, got ${typeof fact.value}`);
  }
  if (!Array.isArray(fact.citations) || fact.citations.length === 0) {
    throw new Error('Expected non-empty citations array');
  }

  console.log('✓ Facts structure valid');

  // Verify each citation
  for (const citation of fact.citations) {
    console.log(`\nVerifying citation: ${citation.path}`);

    // Check required fields
    const citationFields = ['path', 'sha256', 'startLine', 'endLine', 'quote'];
    for (const field of citationFields) {
      if (!(field in citation)) {
        throw new Error(`Missing citation field: ${field}`);
      }
    }

    // Re-read the cited file
    const filePath = citation.path;
    const fileContent = fs.readFileSync(filePath, 'utf8');

    // Recompute SHA-256
    const actualHash = crypto.createHash('sha256').update(fileContent).digest('hex');
    if (actualHash !== citation.sha256) {
      throw new Error(
        `SHA-256 mismatch for ${filePath}:\n  expected: ${citation.sha256}\n  actual: ${actualHash}`
      );
    }
    console.log(`✓ SHA-256 verified: ${actualHash}`);

    // Extract the cited line range (1-based inclusive)
    const lines = fileContent.split('\n');
    let extractedQuote = '';
    for (let i = citation.startLine; i <= citation.endLine; i++) {
      if (i < 1 || i > lines.length) {
        throw new Error(`Line ${i} out of range (file has ${lines.length} lines)`);
      }
      // Line numbers are 1-based
      const lineIndex = i - 1;
      extractedQuote += lines[lineIndex];
      // Add newline if not the last line in the file, or if the original file had a trailing newline
      if (i < citation.endLine || (i === lines.length && fileContent.endsWith('\n'))) {
        extractedQuote += '\n';
      }
    }

    // Compare quote byte-for-byte
    if (extractedQuote !== citation.quote) {
      throw new Error(
        `Quote mismatch for ${filePath} lines ${citation.startLine}-${citation.endLine}:\n` +
        `  expected: ${JSON.stringify(citation.quote)}\n` +
        `  actual: ${JSON.stringify(extractedQuote)}`
      );
    }
    console.log(`✓ Quote verified (${citation.quote.length} bytes)`);
  }
}

console.log('\n✅ All assertions passed');
