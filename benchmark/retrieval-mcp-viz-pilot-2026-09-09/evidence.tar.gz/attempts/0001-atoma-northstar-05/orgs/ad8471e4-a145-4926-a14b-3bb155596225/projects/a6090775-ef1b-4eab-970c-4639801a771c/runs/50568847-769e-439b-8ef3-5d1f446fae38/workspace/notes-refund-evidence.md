# Refund Policy Evidence

## Document Information
- **Relative Path**: docs/billing.md
- **SHA-256 (from CORPUS.json)**: 98efd32bfe73a29b17086fc9be347ae3acfa5b5f061d1b17561295a85fe51e9b

## Evidence Location
- **Start Line (1-based)**: 13
- **End Line (1-based)**: 13

## Exact Quote
```
The refund request window is 14 calendar days after the initial payment.
```

## Refund Days
- **Numeric Value**: 14

## Summary
The document explicitly states that clients have 14 calendar days after the initial payment to request a refund of the first payment. This statement is found in the "Cancellation and refunds" section of the billing policy.
