// Verifies retrieval-answer.json against the supplied corpus, byte for byte.
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';

const REQUIRED_FACTS = [{ key: 'refund-days', valueType: 'number' }];
const fail = [];
const ok = (c, m) => (c ? console.log('  ok   ' + m) : (fail.push(m), console.log('  FAIL ' + m)));

const corpus = JSON.parse(readFileSync('CORPUS.json', 'utf8'));
const ans = JSON.parse(readFileSync('retrieval-answer.json', 'utf8'));

console.log('-- envelope --');
ok(Object.keys(ans).sort().join() === 'facts,questionId,snapshotId,snapshotSha256,status',
  'exactly the required top-level fields: ' + Object.keys(ans).join(','));
ok(ans.questionId === 'northstar-05', 'questionId = northstar-05');
ok(ans.snapshotId === corpus.snapshotId, 'snapshotId matches CORPUS.json');
ok(ans.snapshotSha256 === corpus.snapshotSha256, 'snapshotSha256 matches CORPUS.json');
ok(ans.status === 'answered' || ans.status === 'not_found', 'status is a legal value: ' + ans.status);

console.log('-- corpus integrity (files unchanged) --');
for (const d of corpus.documents) {
  const buf = readFileSync(d.path);
  ok(createHash('sha256').update(buf).digest('hex') === d.sha256 && buf.length === d.bytes,
    `${d.path} matches declared sha256 + ${d.bytes} bytes`);
}

console.log('-- facts --');
ok(ans.facts.length === REQUIRED_FACTS.length, `fact count = ${REQUIRED_FACTS.length}`);
for (const spec of REQUIRED_FACTS) {
  const f = ans.facts.find((x) => x.key === spec.key);
  if (!ok(!!f, `fact "${spec.key}" present`) === undefined && !f) continue;
  if (!f) continue;
  ok(typeof f.value === spec.valueType, `"${spec.key}" value is ${spec.valueType} (got ${typeof f.value}: ${JSON.stringify(f.value)})`);
  ok(Array.isArray(f.citations) && f.citations.length > 0, `"${spec.key}" citations nonempty`);

  for (const [i, c] of f.citations.entries()) {
    const tag = `"${spec.key}" citation[${i}]`;
    const doc = corpus.documents.find((d) => d.path === c.path);
    ok(!!doc, `${tag} path "${c.path}" is a corpus document`);
    ok(c.path !== 'CORPUS.json' && !/\.(mjs|js|json)$/.test(c.path), `${tag} is original evidence, not CORPUS.json or an executable asset`);
    if (!doc) continue;
    const raw = readFileSync(c.path, 'utf8');
    ok(c.sha256 === doc.sha256, `${tag} sha256 matches the document`);
    // 1-based inclusive line slice, preserving the final newline when present.
    const lines = raw.split('\n');
    const total = raw.endsWith('\n') ? lines.length - 1 : lines.length;
    ok(Number.isInteger(c.startLine) && Number.isInteger(c.endLine) &&
       c.startLine >= 1 && c.endLine >= c.startLine && c.endLine <= total,
      `${tag} lines ${c.startLine}-${c.endLine} in range 1..${total}`);
    ok(c.endLine - c.startLine + 1 <= 16, `${tag} spans <= 16 lines`);
    const slice = lines.slice(c.startLine - 1, c.endLine)
      .map((l, j) => (c.startLine - 1 + j < total - 1 || raw.endsWith('\n') ? l + '\n' : l))
      .join('');
    ok(c.quote === slice, `${tag} quote is byte-exact for lines ${c.startLine}-${c.endLine}`);
    if (c.quote !== slice) console.log('    expected: ' + JSON.stringify(slice) + '\n    got:      ' + JSON.stringify(c.quote));
    ok(slice.includes(String(f.value)), `${tag} cited lines actually contain the value ${JSON.stringify(f.value)}`);
  }
}

console.log(fail.length ? `\nFAILED (${fail.length}):\n- ` + fail.join('\n- ') : '\nALL CHECKS PASSED');
process.exit(fail.length ? 1 : 0);
