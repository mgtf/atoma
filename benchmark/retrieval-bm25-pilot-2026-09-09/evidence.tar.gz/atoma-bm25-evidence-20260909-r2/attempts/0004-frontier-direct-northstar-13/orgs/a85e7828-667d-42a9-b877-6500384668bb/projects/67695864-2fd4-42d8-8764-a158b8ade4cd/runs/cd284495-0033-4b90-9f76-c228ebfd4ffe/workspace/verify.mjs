// Verifier: checks pricing.json edit + retrieval-answer.json citations against CORPUS.json.
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';

const fail = [];
const ok = [];
const check = (cond, msg) => (cond ? ok : fail).push(msg);
const sha = (b) => createHash('sha256').update(b).digest('hex');

const corpus = JSON.parse(readFileSync('CORPUS.json', 'utf8'));
const answer = JSON.parse(readFileSync('retrieval-answer.json', 'utf8'));
const pricing = JSON.parse(readFileSync('pricing.json', 'utf8'));

// --- config edit ---
check(pricing.annualCents === 19000, `pricing.annualCents === 19000 (got ${pricing.annualCents})`);
check(pricing.monthlyCents === 1900, `monthly preserved: 1900 (got ${pricing.monthlyCents})`);
check(pricing.currency === 'EUR', `currency preserved: EUR (got ${pricing.currency})`);
check(pricing.refundWindowDays === 14, `refund preserved: 14 (got ${pricing.refundWindowDays})`);
check(Object.keys(pricing).length === 4, `no extra keys: ${Object.keys(pricing).join(',')}`);

// --- documents must be byte-identical to the corpus snapshot ---
for (const d of corpus.documents) {
  check(sha(readFileSync(d.path)) === d.sha256, `document unchanged: ${d.path}`);
}

// --- answer envelope ---
check(answer.questionId === 'northstar-13', 'questionId');
check(answer.snapshotId === corpus.snapshotId, 'snapshotId matches corpus');
check(answer.snapshotSha256 === corpus.snapshotSha256, 'snapshotSha256 matches corpus');
check(answer.status === 'answered', `status: ${answer.status}`);
check(
  JSON.stringify(Object.keys(answer)) ===
    JSON.stringify(['questionId', 'snapshotId', 'snapshotSha256', 'status', 'facts']),
  `exact top-level fields: ${Object.keys(answer).join(',')}`,
);

const expected = {
  'annual-price-cents': 'number',
  'monthly-price-cents': 'number',
  'refund-days': 'number',
};
check(
  JSON.stringify(answer.facts.map((f) => f.key)) === JSON.stringify(Object.keys(expected)),
  `fact keys/order: ${answer.facts.map((f) => f.key).join(',')}`,
);

for (const f of answer.facts) {
  check(typeof f.value === expected[f.key], `${f.key} valueType ${expected[f.key]} (got ${typeof f.value}: ${f.value})`);
  check(Array.isArray(f.citations) && f.citations.length > 0, `${f.key} has citations`);
  for (const c of f.citations) {
    const doc = corpus.documents.find((d) => d.path === c.path);
    check(!!doc, `${f.key}: ${c.path} is a corpus document`);
    check(c.path !== 'CORPUS.json' && c.path !== 'preview.mjs' && c.path !== 'pricing.json',
      `${f.key}: ${c.path} is original evidence (not corpus index / executable / config)`);
    if (!doc) continue;
    check(c.sha256 === doc.sha256, `${f.key}: ${c.path} sha256 matches corpus`);
    check(c.endLine - c.startLine + 1 <= 16, `${f.key}: ${c.path} cites <=16 lines`);
    const raw = readFileSync(c.path, 'utf8');
    const withNl = raw.split('\n').map((l, i, a) => (i === a.length - 1 ? l : l + '\n'));
    const slice = withNl.slice(c.startLine - 1, c.endLine).join('');
    check(slice === c.quote,
      `${f.key}: ${c.path}:${c.startLine}-${c.endLine} quote is byte-exact`);
    check(String(f.value).length > 0 && c.quote.includes(String(f.value)),
      `${f.key}: value ${f.value} appears in quote`);
  }
}

for (const m of ok) console.log(`PASS  ${m}`);
for (const m of fail) console.log(`FAIL  ${m}`);
console.log(`\n${ok.length} passed, ${fail.length} failed`);
process.exit(fail.length === 0 ? 0 : 1);
