#!/usr/bin/env node

const fs = require('fs');
const crypto = require('crypto');

// Helper function to compute SHA-256 hash of a file
function computeSha256(filePath) {
  const content = fs.readFileSync(filePath, 'utf8');
  return crypto.createHash('sha256').update(content).digest('hex');
}

// Helper function to extract lines from a file (1-based, inclusive)
function extractLines(filePath, startLine, endLine) {
  const content = fs.readFileSync(filePath, 'utf8');
  const lines = content.split('\n');
  
  // Convert 1-based to 0-based indexing
  const result = lines.slice(startLine - 1, endLine).join('\n') + '\n';
  return result;
}

// Main verification
try {
  // Read and parse retrieval-answer.json
  const answerContent = fs.readFileSync('retrieval-answer.json', 'utf8');
  const answer = JSON.parse(answerContent);
  
  console.log('✓ retrieval-answer.json is valid JSON');
  
  // Verify exact field set
  const requiredFields = ['questionId', 'snapshotId', 'snapshotSha256', 'status', 'facts'];
  const actualFields = Object.keys(answer).sort();
  const expectedFields = requiredFields.sort();
  
  if (JSON.stringify(actualFields) !== JSON.stringify(expectedFields)) {
    console.error(`✗ Field set mismatch. Expected: ${expectedFields.join(', ')}, Got: ${actualFields.join(', ')}`);
    process.exit(1);
  }
  console.log('✓ Exact field set verified:', requiredFields.join(', '));
  
  // Verify status and required literal values
  if (answer.questionId !== 'northstar-01') {
    console.error(`✗ questionId mismatch: expected 'northstar-01', got '${answer.questionId}'`);
    process.exit(1);
  }
  console.log('✓ questionId is correct');
  
  if (answer.snapshotId !== 'northstar-v1') {
    console.error(`✗ snapshotId mismatch: expected 'northstar-v1', got '${answer.snapshotId}'`);
    process.exit(1);
  }
  console.log('✓ snapshotId is correct');
  
  if (answer.status !== 'answered') {
    console.error(`✗ status mismatch: expected 'answered', got '${answer.status}'`);
    process.exit(1);
  }
  console.log('✓ status is "answered"');
  
  // Verify facts array exists and is an array
  if (!Array.isArray(answer.facts)) {
    console.error('✗ facts is not an array');
    process.exit(1);
  }
  console.log('✓ facts is an array');
  
  // Check annual-price-cents is a number when status is "answered"
  let foundAnnualPrice = false;
  for (const fact of answer.facts) {
    if (fact.key === 'annual-price-cents') {
      if (typeof fact.value !== 'number') {
        console.error(`✗ annual-price-cents is not a number, got type: ${typeof fact.value}`);
        process.exit(1);
      }
      console.log(`✓ annual-price-cents is a number: ${fact.value}`);
      foundAnnualPrice = true;
      
      // Now verify each citation
      if (!Array.isArray(fact.citations)) {
        console.error('✗ citations is not an array');
        process.exit(1);
      }
      console.log(`✓ Found ${fact.citations.length} citation(s)`);
      
      for (let i = 0; i < fact.citations.length; i++) {
        const citation = fact.citations[i];
        const citationNum = i + 1;
        
        // Verify citation has required fields
        if (!citation.path || !citation.sha256 || !('startLine' in citation) || !('endLine' in citation) || !citation.quote) {
          console.error(`✗ Citation ${citationNum} missing required fields`);
          process.exit(1);
        }
        
        // Compute SHA-256 of cited file
        let actualSha256;
        try {
          actualSha256 = computeSha256(citation.path);
        } catch (err) {
          console.error(`✗ Citation ${citationNum} cannot read file '${citation.path}': ${err.message}`);
          process.exit(1);
        }
        
        if (actualSha256 !== citation.sha256) {
          console.error(`✗ Citation ${citationNum} SHA-256 mismatch for '${citation.path}':`);
          console.error(`  Expected: ${citation.sha256}`);
          console.error(`  Got: ${actualSha256}`);
          process.exit(1);
        }
        console.log(`✓ Citation ${citationNum} ('${citation.path}') SHA-256 verified`);
        
        // Extract and verify line range
        let extractedText;
        try {
          extractedText = extractLines(citation.path, citation.startLine, citation.endLine);
        } catch (err) {
          console.error(`✗ Citation ${citationNum} cannot extract lines from '${citation.path}': ${err.message}`);
          process.exit(1);
        }
        
        if (extractedText !== citation.quote) {
          console.error(`✗ Citation ${citationNum} line range mismatch for '${citation.path}' (lines ${citation.startLine}-${citation.endLine}):`);
          console.error(`  Expected quote (${citation.quote.length} bytes): ${JSON.stringify(citation.quote)}`);
          console.error(`  Got extracted (${extractedText.length} bytes): ${JSON.stringify(extractedText)}`);
          process.exit(1);
        }
        console.log(`✓ Citation ${citationNum} line range (${citation.startLine}-${citation.endLine}) quote verified`);
      }
    }
  }
  
  if (!foundAnnualPrice) {
    console.error('✗ annual-price-cents fact not found');
    process.exit(1);
  }
  
  console.log('\n✓✓✓ All verification checks passed ✓✓✓');
  process.exit(0);
  
} catch (err) {
  console.error(`✗ Fatal error: ${err.message}`);
  if (err.code === 'SyntaxError') {
    console.error('JSON parse error in retrieval-answer.json');
  }
  process.exit(1);
}
