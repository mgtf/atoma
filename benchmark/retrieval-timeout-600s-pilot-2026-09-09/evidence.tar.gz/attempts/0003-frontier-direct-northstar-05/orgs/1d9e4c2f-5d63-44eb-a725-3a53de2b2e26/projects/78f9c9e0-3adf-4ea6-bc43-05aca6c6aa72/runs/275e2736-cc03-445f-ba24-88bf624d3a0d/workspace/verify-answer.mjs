// Validates retrieval-answer.json against CORPUS.json and the original documents.
// Exits non-zero on any failure. Byte-exact quote and digest checks.
import { readFileSync } from "node:fs";
import { createHash } from "node:crypto";

const fail = [];
const ok = [];
const check = (cond, msg) => (cond ? ok : fail).push(msg);

const corpus = JSON.parse(readFileSync("CORPUS.json", "utf8"));
const raw = readFileSync("retrieval-answer.json", "utf8");
const ans = JSON.parse(raw);

// 1. Exact field set, no extras, no omissions.
const expected = ["questionId", "snapshotId", "snapshotSha256", "status", "facts"];
const got = Object.keys(ans).sort();
check(
  JSON.stringify(got) === JSON.stringify([...expected].sort()),
  `field set is exactly ${expected.join(",")} (got ${got.join(",")})`
);

check(ans.questionId === "northstar-05", `questionId === "northstar-05" (got ${JSON.stringify(ans.questionId)})`);
check(ans.snapshotId === "northstar-v1", `snapshotId === "northstar-v1" (got ${JSON.stringify(ans.snapshotId)})`);
check(
  ans.snapshotSha256 === "31d63c88fa2aac63a8220091713f04c30b50a29a40019b4839b21e72d289654c",
  "snapshotSha256 matches the task-supplied digest"
);
check(
  ans.snapshotSha256 === corpus.snapshotSha256,
  "snapshotSha256 matches CORPUS.json snapshotSha256"
);
check(["answered", "not_found"].includes(ans.status), `status is answered|not_found (got ${JSON.stringify(ans.status)})`);
check(Array.isArray(ans.facts), "facts is an array");

// 2. Requested fact contract: exactly one fact, key refund-days, valueType number.
const requested = [{ key: "refund-days", valueType: "number" }];
check(
  ans.facts.length === requested.length,
  `facts has ${requested.length} entry (got ${ans.facts.length})`
);
check(
  JSON.stringify(ans.facts.map((f) => f.key)) === JSON.stringify(requested.map((r) => r.key)),
  "fact keys match the requested keys exactly"
);

// 3. Corpus digests: every supplied document is unmodified.
const docByPath = new Map();
for (const d of corpus.documents) {
  const buf = readFileSync(d.path);
  const sha = createHash("sha256").update(buf).digest("hex");
  check(sha === d.sha256, `${d.path} digest matches CORPUS.json (unmodified)`);
  check(buf.length === d.bytes, `${d.path} byte length is ${d.bytes} (got ${buf.length})`);
  docByPath.set(d.path, { buf, sha });
}

// 4. Per-fact and per-citation validation.
const forbidden = [/^CORPUS\.json$/, /\.mjs$/, /\.js$/, /^pricing\.json$/];

for (const f of ans.facts) {
  const spec = requested.find((r) => r.key === f.key);
  const tag = `fact ${f.key}`;
  check(!!spec, `${tag} is a requested key`);
  if (!spec) continue;

  const fk = Object.keys(f).sort();
  check(
    JSON.stringify(fk) === JSON.stringify(["citations", "key", "value"]),
    `${tag} has exactly key,value,citations (got ${fk.join(",")})`
  );

  // Declared JSON value type, and scalar-ness.
  check(typeof f.value === spec.valueType, `${tag} value typeof === ${spec.valueType} (got ${typeof f.value})`);
  check(f.value !== null && typeof f.value !== "object", `${tag} value is a JSON scalar`);
  if (spec.valueType === "number") {
    check(Number.isFinite(f.value), `${tag} value is a finite number`);
    // Must survive a JSON round-trip as a number, not a string.
    check(typeof JSON.parse(raw).facts.find((x) => x.key === f.key).value === "number",
      `${tag} value is a number in the serialized file (not a quoted string)`);
  }

  check(Array.isArray(f.citations) && f.citations.length > 0, `${tag} citations is a nonempty array`);

  for (const [i, c] of (f.citations ?? []).entries()) {
    const ct = `${tag} citation[${i}]`;
    const ck = Object.keys(c).sort();
    check(
      JSON.stringify(ck) === JSON.stringify(["endLine", "path", "quote", "sha256", "startLine"]),
      `${ct} has exactly path,sha256,startLine,endLine,quote (got ${ck.join(",")})`
    );

    // Original evidence only.
    check(docByPath.has(c.path), `${ct} path "${c.path}" is a declared corpus document`);
    check(!forbidden.some((re) => re.test(c.path)), `${ct} path is not CORPUS.json nor an executable asset`);
    if (!docByPath.has(c.path)) continue;

    const { buf, sha } = docByPath.get(c.path);
    check(c.sha256 === sha, `${ct} sha256 matches the on-disk digest of ${c.path}`);

    // 1-based inclusive line range, <= 16 lines.
    const lines = buf.toString("utf8").split(/(?<=\n)/);
    check(Number.isInteger(c.startLine) && c.startLine >= 1, `${ct} startLine is a 1-based integer`);
    check(Number.isInteger(c.endLine) && c.endLine >= c.startLine, `${ct} endLine >= startLine`);
    check(c.endLine <= lines.length, `${ct} endLine ${c.endLine} within file (${lines.length} lines)`);
    const span = c.endLine - c.startLine + 1;
    check(span <= 16, `${ct} cites ${span} line(s), <= 16`);

    // Byte-exact quote of those lines, including final newline when present.
    const actual = lines.slice(c.startLine - 1, c.endLine).join("");
    check(
      c.quote === actual,
      `${ct} quote is byte-exact for lines ${c.startLine}-${c.endLine}` +
        (c.quote === actual ? "" : `\n     expected ${JSON.stringify(actual)}\n     got      ${JSON.stringify(c.quote)}`)
    );
    check(
      Buffer.byteLength(c.quote, "utf8") === Buffer.byteLength(actual, "utf8"),
      `${ct} quote byte length matches (${Buffer.byteLength(actual, "utf8")})`
    );

    // The quote must actually support the value.
    check(
      String(actual).includes(String(f.value)),
      `${ct} quoted evidence literally contains the value ${JSON.stringify(f.value)}`
    );
  }
}

// 5. Cross-check: the cited value is the accepted policy, not a draft/archived one.
const billing = docByPath.get("docs/billing.md")?.buf.toString("utf8") ?? "";
const decisions = docByPath.get("docs/decisions.md")?.buf.toString("utf8") ?? "";
const m = billing.match(/refund request window is (\d+) calendar days/);
check(!!m, "docs/billing.md states a refund request window in calendar days");
check(m && Number(m[1]) === ans.facts[0].value, `answered value ${ans.facts[0].value} equals the billing-policy window ${m?.[1]}`);
check(
  /D-003[\s\S]*?draft; not approved for implementation[\s\S]*?30-day refund window/.test(decisions),
  "the competing 30-day window is confined to D-003, marked draft/not approved (correctly rejected)"
);
check(ans.facts[0].value !== 30, "answer does not use the unapproved 30-day draft value");

console.log("PASS:");
for (const m2 of ok) console.log("  ✓ " + m2);
if (fail.length) {
  console.log("\nFAIL:");
  for (const m2 of fail) console.log("  ✗ " + m2);
  console.log(`\n${ok.length} passed, ${fail.length} failed`);
  process.exit(1);
}
console.log(`\nAll ${ok.length} checks passed.`);
