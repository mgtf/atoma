#!/usr/bin/env node
/**
 * verify-answer.js
 * Validates retrieval-answer.json structure and content integrity
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const REQUIRED_FIELDS = ['questionId', 'snapshotId', 'snapshotSha256', 'status', 'facts'];
const VALID_STATUSES = ['answered', 'not_found'];
const FORBIDDEN_PATHS = ['CORPUS.json'];
const EXECUTABLE_EXTENSIONS = ['.sh', '.bat', '.exe', '.com'];
const MAX_CITATION_LINES = 16;

let checksRun = 0;
let checksFailed = 0;

function logCheck(name, passed, details = '') {
  checksRun++;
  const status = passed ? '✓' : '✗';
  console.log(`${status} Check ${checksRun}: ${name}${details ? ' — ' + details : ''}`);
  if (!passed) {
    checksFailed++;
  }
}

function computeFileSha256(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf8');
    return crypto.createHash('sha256').update(content).digest('hex');
  } catch (err) {
    throw new Error(`Failed to read file ${filePath}: ${err.message}`);
  }
}

function getFileLines(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf8');
    return content.split('\n');
  } catch (err) {
    throw new Error(`Failed to read file ${filePath}: ${err.message}`);
  }
}

function extractQuoteFromFile(filePath, startLine, endLine) {
  const lines = getFileLines(filePath);
  const result = [];
  
  // Lines are 1-based inclusive
  for (let i = startLine; i <= endLine; i++) {
    if (i < 1 || i > lines.length) {
      throw new Error(`Line ${i} out of bounds in ${filePath} (file has ${lines.length} lines)`);
    }
    result.push(lines[i - 1]);
  }
  
  // Join with newlines and add trailing newline if needed
  let quote = result.join('\n');
  if (result.length > 0 && !quote.endsWith('\n')) {
    quote += '\n';
  }
  
  return quote;
}

function isExecutable(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  return EXECUTABLE_EXTENSIONS.includes(ext);
}

function validateAnswer(data) {
  // Check 1: File structure — top-level is object
  logCheck('file is JSON object', typeof data === 'object' && data !== null);
  
  // Check 2: Five required fields exist
  logCheck(
    'has exactly 5 required fields',
    REQUIRED_FIELDS.every(f => f in data),
    REQUIRED_FIELDS.join(', ')
  );
  
  // Check 3: questionId literal value
  logCheck(
    'questionId has exact literal value',
    data.questionId === 'northstar-05',
    `expected "northstar-05", got "${data.questionId}"`
  );
  
  // Check 4: snapshotId literal value
  logCheck(
    'snapshotId has exact literal value',
    data.snapshotId === 'northstar-v1',
    `expected "northstar-v1", got "${data.snapshotId}"`
  );
  
  // Check 5: snapshotSha256 literal value
  logCheck(
    'snapshotSha256 has exact literal value',
    data.snapshotSha256 === '31d63c88fa2aac63a8220091713f04c30b50a29a40019b4839b21e72d289654c',
    `got "${data.snapshotSha256}"`
  );
  
  // Check 6: status is valid enum
  logCheck(
    'status is "answered" or "not_found"',
    VALID_STATUSES.includes(data.status),
    `got "${data.status}"`
  );
  
  // Check 7: facts is array
  logCheck('facts is an array', Array.isArray(data.facts));
  
  // Check 8: When status is "not_found", facts must be empty
  if (data.status === 'not_found') {
    logCheck(
      'when status is "not_found", facts is empty',
      Array.isArray(data.facts) && data.facts.length === 0,
      `facts has ${data.facts.length} items`
    );
  }
  
  // Check 9+: Validate each fact
  if (Array.isArray(data.facts)) {
    data.facts.forEach((fact, idx) => {
      logCheck(
        `fact[${idx}] is object`,
        typeof fact === 'object' && fact !== null
      );
      
      logCheck(
        `fact[${idx}] has key field`,
        'key' in fact,
        `key="${fact.key}"`
      );
      
      logCheck(
        `fact[${idx}] has value field`,
        'value' in fact
      );
      
      logCheck(
        `fact[${idx}] has citations array`,
        Array.isArray(fact.citations),
        `citations type: ${typeof fact.citations}`
      );
      
      // Type validation for specific keys
      if (fact.key === 'refund-days') {
        logCheck(
          `fact[${idx}] refund-days value is number (not string)`,
          typeof fact.value === 'number',
          `got ${typeof fact.value}`
        );
      }
      
      // Validate citations
      if (Array.isArray(fact.citations)) {
        logCheck(
          `fact[${idx}] citations is non-empty`,
          fact.citations.length > 0,
          `length: ${fact.citations.length}`
        );
        
        fact.citations.forEach((citation, citIdx) => {
          const citPrefix = `fact[${idx}].citations[${citIdx}]`;
          
          logCheck(
            `${citPrefix} has path`,
            'path' in citation,
            `path="${citation.path}"`
          );
          
          logCheck(
            `${citPrefix} has sha256`,
            'sha256' in citation,
            `length: ${citation.sha256 ? citation.sha256.length : 'N/A'}`
          );
          
          logCheck(
            `${citPrefix} has startLine`,
            'startLine' in citation && typeof citation.startLine === 'number',
            `startLine=${citation.startLine}`
          );
          
          logCheck(
            `${citPrefix} has endLine`,
            'endLine' in citation && typeof citation.endLine === 'number',
            `endLine=${citation.endLine}`
          );
          
          logCheck(
            `${citPrefix} has quote`,
            'quote' in citation,
            `length: ${citation.quote ? citation.quote.length : 'N/A'}`
          );
          
          // Validate path constraints
          if (citation.path) {
            const isForbidden = FORBIDDEN_PATHS.includes(citation.path);
            logCheck(
              `${citPrefix} path is not CORPUS.json`,
              !isForbidden,
              `path="${citation.path}"`
            );
            
            logCheck(
              `${citPrefix} path is not executable`,
              !isExecutable(citation.path),
              `path="${citation.path}"`
            );
          }
          
          // Verify file exists and compute SHA-256
          if (citation.path) {
            const fileExists = fs.existsSync(citation.path);
            logCheck(
              `${citPrefix} file exists on disk`,
              fileExists,
              `path="${citation.path}"`
            );
            
            if (fileExists) {
              try {
                const computedSha256 = computeFileSha256(citation.path);
                logCheck(
                  `${citPrefix} file SHA-256 matches`,
                  computedSha256 === citation.sha256,
                  `expected "${citation.sha256}", got "${computedSha256}"`
                );
                
                // Validate line count
                const lines = getFileLines(citation.path);
                const maxLine = Math.max(citation.startLine, citation.endLine);
                logCheck(
                  `${citPrefix} endLine <= file line count`,
                  maxLine <= lines.length,
                  `endLine=${citation.endLine}, file has ${lines.length} lines`
                );
                
                // Validate line range size
                const lineCount = citation.endLine - citation.startLine + 1;
                logCheck(
                  `${citPrefix} line range <= ${MAX_CITATION_LINES}`,
                  lineCount <= MAX_CITATION_LINES,
                  `${lineCount} lines (${citation.startLine}..${citation.endLine})`
                );
                
                // Extract and validate quote
                if (citation.startLine >= 1 && citation.endLine >= citation.startLine && maxLine <= lines.length) {
                  try {
                    const extractedQuote = extractQuoteFromFile(
                      citation.path,
                      citation.startLine,
                      citation.endLine
                    );
                    
                    logCheck(
                      `${citPrefix} quote matches file content exactly`,
                      extractedQuote === citation.quote,
                      extractedQuote.length === citation.quote.length
                        ? `(both ${extractedQuote.length} bytes, last bytes: ...${extractedQuote.slice(-10).replace(/\n/g, '\\n')})`
                        : `expected ${citation.quote.length} bytes, got ${extractedQuote.length}`
                    );
                  } catch (err) {
                    logCheck(
                      `${citPrefix} quote extraction`,
                      false,
                      err.message
                    );
                  }
                }
              } catch (err) {
                logCheck(
                  `${citPrefix} SHA-256 computation`,
                  false,
                  err.message
                );
              }
            }
          }
        });
      }
    });
  }
}

try {
  const filePath = 'retrieval-answer.json';
  console.log(`Validating ${filePath}...\n`);
  
  const jsonContent = fs.readFileSync(filePath, 'utf8');
  const data = JSON.parse(jsonContent);
  
  validateAnswer(data);
  
  console.log(`\n=== Summary ===`);
  console.log(`Total checks: ${checksRun}`);
  console.log(`Failed checks: ${checksFailed}`);
  
  if (checksFailed === 0) {
    console.log('\n✓ All validation checks passed!');
    process.exit(0);
  } else {
    console.log(`\n✗ ${checksFailed} check(s) failed`);
    process.exit(1);
  }
} catch (err) {
  console.error(`\n✗ Fatal error: ${err.message}`);
  process.exit(1);
}
