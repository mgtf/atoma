
import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';
const root='/tmp/atoma-live-recovery-aa8hid',base='/tmp/atoma-depth-validation-20260914/repo/dist';
const {ContainerToolExecutor}=await import(base+'/tools/containerExecutor.js');
const {acquireRunLeaseWithoutRecovery}=await import(base+'/mcp/runLock.js');
const {runBackup}=await import(base+'/cli/backup.js');
const lease=acquireRunLeaseWithoutRecovery('recovery-postcheck-'+Date.now());
const result={checkedAt:new Date().toISOString(),cases:[]};
try{
 for(const name of ['fresh','seeded']){
  const copy=path.join(root,'independent-'+name);fs.cpSync(path.join(root,name),copy,{recursive:true});
  const p=new ContainerToolExecutor({workspaceHostPath:copy,image:'sha256:9fc3d7899a6e8eeac8eff6dd14109158d6d0dd6f40d7d1933ea5100f2d7c5715',forwardWorkerLogs:false});
  try{const server=await p.execute('start_static_server',{});
   const smoke="(() => {const b=document.getElementById('increment'),v=document.getElementById('value');const initial=v.textContent.trim();b.click();b.click();b.click();const before=v.textContent.trim();"+(name==='seeded'?"document.getElementById('reset').click();const after=v.textContent.trim();return {ok:initial==='0'&&before==='3'&&after==='0',initial,before,after};":"return {ok:initial==='0'&&before==='3',initial,before};")+"})()";
   const proof=await p.execute('validate_html',{url:server.url,smoke,waitMs:100});assert.equal(proof.ok,true);result.cases.push({name,proof});
  }finally{await p.drain();}
  fs.cpSync(path.join(root,name),path.join(root,'archive','live-workspaces',name),{recursive:true});
 }
 result.snapshot=await runBackup({dest:path.join(root,'backups'),keep:14,storeDb:path.join(root,'store.db'),skillsDir:path.join(root,'skills'),runsDir:path.join(root,'runs'),archiveDir:path.join(root,'archive'),projectsRoot:path.join(root,'projects'),supervisorDir:path.join(root,'supervisor'),repoRoot:'/tmp/atoma-depth-validation-20260914/repo'});
 fs.writeFileSync(path.join(root,'postcheck.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result));
}finally{lease.release();}
