
import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';
const root='/tmp/atoma-live-recovery-aa8hid',base='/tmp/atoma-depth-validation-20260914/repo/dist';
const {ContainerToolExecutor}=await import(base+'/tools/containerExecutor.js');
const {acquireRunLeaseWithoutRecovery}=await import(base+'/mcp/runLock.js');
const lease=acquireRunLeaseWithoutRecovery('pointer-recovery-check-'+Date.now());const results=[];
try{
 for(const origin of ['original','restored'])for(const name of ['fresh','seeded']){
  const source=origin==='original'?path.join(root,name):path.join(root,'restored/archive/archive/live-workspaces',name);
  const copy=path.join(root,'pointer-'+origin+'-'+name);fs.mkdirSync(copy);fs.copyFileSync(path.join(source,'index.html'),path.join(copy,'index.html'));
  const executor=new ContainerToolExecutor({workspaceHostPath:copy,image:'sha256:9fc3d7899a6e8eeac8eff6dd14109158d6d0dd6f40d7d1933ea5100f2d7c5715',callTimeoutMs:30000,forwardWorkerLogs:false});
  try{
   const server=await executor.execute('start_static_server',{});
   const code=`const assert=require('node:assert/strict');const puppeteer=require('/app/node_modules/puppeteer');(async()=>{const b=await puppeteer.launch({headless:true,executablePath:'/usr/bin/chromium',args:['--no-sandbox','--disable-dev-shm-usage']});try{const p=await b.newPage();await p.goto(process.argv[1]);const value=()=>p.$eval('#value',e=>e.textContent.trim());assert.equal(await value(),'0');for(let i=0;i<3;i++)await p.click('#increment');assert.equal(await value(),'3');if(process.argv[2]==='seeded'){await p.click('#reset');assert.equal(await value(),'0');await p.click('#increment');assert.equal(await value(),'1');}console.log(JSON.stringify({ok:true,method:'puppeteer-page-click',final:await value()}));}finally{await b.close();}})().catch(e=>{console.error(e);process.exitCode=1;});`;
   const observed=await executor.execute('run_shell',{command:'node',args:['-e',code,server.url,name]});assert.equal(observed.exitCode,0,observed.stderr);results.push({origin,name,...JSON.parse(observed.stdout.trim())});
  }finally{await executor.drain();}
 }
 fs.writeFileSync(path.join(root,'pointer-check.json'),JSON.stringify(results,null,2));console.log(JSON.stringify(results));
}finally{lease.release();}
