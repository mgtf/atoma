const assert = require('node:assert/strict');
const puppeteer = require('/app/node_modules/puppeteer');
(async () => {
  const browser = await puppeteer.launch({ headless: true, executablePath: '/usr/bin/chromium', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const results = [];
  try {
    const page = await browser.newPage();
    page.setDefaultTimeout(10000);
    let receive;
    await page.setRequestInterception(true);
    page.on('request', request => {
      if (new URL(request.url()).pathname === '/api/network') receive(request);
      else void request.continue();
    });
    await page.goto(process.argv[2]);
    await page.evaluate(() => {
      window.__downloads = [];
      const original = URL.createObjectURL.bind(URL);
      URL.createObjectURL = blob => { window.__downloads.push(blob.text()); return original(blob); };
    });
    const disabled = () => page.evaluate(() => ({ check: document.querySelector('#checkConnection').disabled, export: document.querySelector('#exportJson').disabled }));
    assert.deepEqual(await disabled(), { check: false, export: true });
    await page.click('#exportJson');
    assert.equal(await page.evaluate(() => window.__downloads.length), 0);
    results.push('initial export disabled; no download');
    async function attempt(label, reply, expected) {
      const waiting = new Promise(resolve => { receive = resolve; });
      await page.click('#checkConnection');
      const request = await waiting;
      assert.deepEqual(await disabled(), { check: true, export: true });
      const count = await page.evaluate(() => window.__downloads.length);
      await page.click('#exportJson');
      assert.equal(await page.evaluate(() => window.__downloads.length), count);
      if (reply.abort) await request.abort('failed');
      else await request.respond({ status: reply.status, contentType: 'application/json', body: reply.body ?? JSON.stringify(reply.json) });
      await page.waitForFunction(() => !document.querySelector('#checkConnection').disabled);
      assert.deepEqual(await disabled(), { check: false, export: false });
      await page.click('#exportJson');
      const exported = await page.evaluate(async () => JSON.parse(await window.__downloads.at(-1)));
      for (const [key, value] of Object.entries(expected)) assert.equal(exported[key], value, label + ': ' + key);
      const actual = await page.evaluate(() => window.__networkPostcard.latestResult);
      assert.deepEqual(exported, actual);
      if (expected.ok) assert.ok((await page.$eval('.detail', e => e.textContent)).includes(exported.timestamp));
      results.push(label);
    }
    await attempt('successful result and Blob match', { status: 200, json: { ok: true, status: 200, bytes: 42 } }, { ok: true, httpStatus: 200, receivedBytes: 42 });
    await attempt('pending next request disables both buttons, then replaces prior result', { status: 200, json: { ok: true, status: 200, bytes: 99 } }, { ok: true, receivedBytes: 99 });
    await attempt('HTTP 502 replaces success with its own error', { status: 502, json: { ok: false, error: 'controlled upstream failure' } }, { ok: false, httpStatus: 502, error: 'controlled upstream failure' });
    await attempt('transport rejection replaces previous result', { abort: true }, { ok: false, httpStatus: null, receivedBytes: 0 });
    await attempt('invalid JSON replaces previous result', { status: 502, body: '{broken' }, { ok: false, httpStatus: 502, error: 'The server returned an unreadable response.' });
    await attempt('recovery exports the new successful result', { status: 200, json: { ok: true, status: 204, bytes: 123 } }, { ok: true, httpStatus: 200, receivedBytes: 123 });
    console.log(JSON.stringify({ ok: true, method: 'real Chromium pointer clicks; intercepted deterministic API responses', externalNetworkTested: false, checks: results }));
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; });
