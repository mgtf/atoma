import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
const base = '/tmp/atoma-depth-validation-20260914/repo/dist';
const { ContainerToolExecutor } = await import(base + '/tools/containerExecutor.js');
const { acquireRunLeaseWithoutRecovery } = await import(base + '/mcp/runLock.js');
const workspace = '/tmp/atoma-production-audit-20260914/app';
const lease = acquireRunLeaseWithoutRecovery('published-artifact-check-' + Date.now());
const executor = new ContainerToolExecutor({ workspaceHostPath: workspace, image: 'sha256:9fc3d7899a6e8eeac8eff6dd14109158d6d0dd6f40d7d1933ea5100f2d7c5715', callTimeoutMs: 90000, forwardWorkerLogs: false });
const report = { commit: '8fda88b6ff491aa31e7a3a667dc072cb889fc232', checks: [] };
try {
  const tests = await executor.execute('run_shell', { command: 'npm', args: ['test'] });
  report.checks.push({ name: 'published regression suite', ...tests });
  assert.equal(tests.exitCode, 0, tests.stderr);
  const server = await executor.execute('start_node_server', { entry: 'server.js' });
  assert.equal(server.ok, true, JSON.stringify(server));
  for (const suffix of ['health', '', 'app.js']) {
    const response = await executor.execute('fetch_url', { url: new URL(suffix, server.url).href });
    report.checks.push({ name: 'HTTP /' + suffix, status: response.status });
    assert.equal(response.status, 200, JSON.stringify(response));
  }
  const browser = await executor.execute('run_shell', { command: 'node', args: ['browser-check.cjs', server.url] });
  report.checks.push({ name: 'browser', ...browser });
  assert.equal(browser.exitCode, 0, browser.stderr);
  report.ok = true;
} catch (error) { report.ok = false; report.error = String(error); process.exitCode = 1; }
finally { await executor.drain(); lease.release(); fs.writeFileSync(path.join(workspace, '..', 'report.json'), JSON.stringify(report, null, 2)); }
console.log(JSON.stringify(report));
