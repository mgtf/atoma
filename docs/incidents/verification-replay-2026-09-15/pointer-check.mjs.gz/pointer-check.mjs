// Independent pointer check of the campaign's delivered counters, outside any
// run: real Puppeteer clicks, assertions interleaved, no LLM, no product code.
import puppeteer from 'puppeteer';
import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { createServer } from 'node:http';

const cases = [
  { label: 'fresh', file: '/tmp/atoma-ledger-campaign-20260915/seed/index.html', reset: false },
  { label: 'seeded', file: '/tmp/atoma-ledger-campaign-20260915/workspace/index.html', reset: true },
];

const results = [];
const browser = await puppeteer.launch({ headless: true, args: ['--no-sandbox'] });
try {
  for (const c of cases) {
    const bytes = readFileSync(c.file);
    const sha256 = createHash('sha256').update(bytes).digest('hex');
    const server = createServer((_req, res) => {
      res.setHeader('content-type', 'text/html; charset=utf-8');
      res.end(bytes);
    });
    await new Promise((r) => server.listen(0, '127.0.0.1', r));
    const { port } = server.address();
    const page = await browser.newPage();
    const errors = [];
    page.on('pageerror', (e) => errors.push(String(e)));
    page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
    await page.goto(`http://127.0.0.1:${port}/index.html`, { waitUntil: 'load' });
    const value = () => page.$eval('#value', (el) => el.textContent.trim());
    const seq = [await value()];
    for (let i = 0; i < 3; i++) { await page.click('#increment'); seq.push(await value()); }
    if (c.reset) { await page.click('#reset'); seq.push(await value()); await page.click('#increment'); seq.push(await value()); }
    const expected = c.reset ? ['0', '1', '2', '3', '0', '1'] : ['0', '1', '2', '3'];
    const ok = JSON.stringify(seq) === JSON.stringify(expected) && errors.length === 0;
    results.push({ label: c.label, sha256, sequence: seq, expected, pageErrors: errors, ok });
    await page.close();
    server.close();
  }
} finally {
  await browser.close();
}
console.log(JSON.stringify({ checkedAt: new Date().toISOString(), results }, null, 2));
process.exit(results.every((r) => r.ok) ? 0 : 1);
