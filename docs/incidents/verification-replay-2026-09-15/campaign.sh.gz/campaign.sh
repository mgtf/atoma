#!/bin/bash
# Live campaign for the validation ledger — one run at a time, isolated state,
# same goals and worker image as 2026-09-14, 300 s budget per run.
set -u
export PATH="$HOME/.local/node24/bin:$PATH"
REPO=/tmp/atoma-backup-check
ROOT=/tmp/atoma-ledger-campaign-20260915
IMAGE=sha256:9fc3d7899a6e8eeac8eff6dd14109158d6d0dd6f40d7d1933ea5100f2d7c5715
mkdir -p "$ROOT/state/skills" "$ROOT/state/runs" "$ROOT/workspace" "$ROOT/logs" "$ROOT/seed"

export ATOMA_MODEL_L1=sub:anthropic:haiku ATOMA_MODEL_L2=sub:anthropic:sonnet ATOMA_MODEL_L3=sub:anthropic:opus
export ATOMA_DB_PATH="$ROOT/state/atoma.db" ATOMA_SKILLS_DIR="$ROOT/state/skills" ATOMA_RUNS_DIR="$ROOT/state/runs"
export ATOMA_BUILD_WORKSPACE="$ROOT/workspace" ATOMA_BUILD_TIMEOUT_MS=300000
unset ATOMA_SEED ATOMA_BASELINE

FRESH_GOAL='Build only a single self-contained index.html, no dependencies. A simple counter displays 0 in an element with id value. A button with id increment increments it by one on each click. Use inline CSS. Verify actual browser clicks. Keep the scope minimal.'
SEEDED_GOAL='Modify the existing index.html. Preserve the working counter (#value and #increment). Add a button with id reset that sets the counter to 0. Keep the application self-contained, with no dependencies or additional files. Verify increment and reset through actual browser clicks.'

cd "$REPO" || exit 1
echo "revision: $(git rev-parse --short HEAD) + ledger patch ($(git status --short | wc -l) files)"
docker image inspect "$IMAGE" --format 'image: {{.Id}} {{.Created}}' || exit 1

run_one() {
  local label="$1"; shift
  local log="$ROOT/logs/$label.log"
  echo "== $label: start $(date -u +%FT%TZ)"
  npx tsx src/cli/build-app.ts "$@" > "$log" 2>&1 &
  local pid=$!
  local waited=0
  while kill -0 "$pid" 2>/dev/null; do
    if grep -qE '✓ build finished|--- run failed ---|⏱ TIMEOUT after|✖ build failed|--- spawn failed ---' "$log"; then
      sleep 8
      break
    fi
    if [ "$waited" -ge 420 ]; then echo "$label: hard timeout at ${waited}s" | tee -a "$log"; break; fi
    sleep 5; waited=$((waited+5))
  done
  if kill -0 "$pid" 2>/dev/null; then
    kill -INT "$pid" 2>/dev/null
    for _ in $(seq 1 12); do kill -0 "$pid" 2>/dev/null || break; sleep 5; done
    kill -0 "$pid" 2>/dev/null && kill -TERM "$pid" 2>/dev/null
  fi
  wait "$pid" 2>/dev/null
  echo "== $label: end $(date -u +%FT%TZ) exit=$?"
  grep -E '✓ build finished|--- run failed ---|⏱ TIMEOUT after|✖ build failed|^TOTAL|ATOMA_RUN_STATS|INTERNAL VALIDATION|rejected pre-flight|deepening|run timeout' "$log" | head -30
}

run_one fresh --container --worker-image "$IMAGE" --clean-workspace "$FRESH_GOAL"
echo "== workspace after fresh:"; ls -la "$ROOT/workspace" | head
rm -rf "$ROOT/seed"/* && cp -a "$ROOT/workspace"/. "$ROOT/seed"/ && ls "$ROOT/seed"
sha256sum "$ROOT/seed"/index.html 2>/dev/null

run_one seeded --container --worker-image "$IMAGE" --clean-workspace --seed "$ROOT/seed" "$SEEDED_GOAL"
echo "== workspace after seeded:"; ls -la "$ROOT/workspace" | head
sha256sum "$ROOT/workspace"/index.html 2>/dev/null
echo "== traces:"; ls -la "$ROOT/state/runs"
echo "== containers left:"; docker ps --format '{{.Names}} {{.Image}}' | head
