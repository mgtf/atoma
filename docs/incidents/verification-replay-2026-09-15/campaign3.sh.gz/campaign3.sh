#!/bin/bash
# Third live campaign — the two-call guidance, WITH the worker image rebuilt
# from the patched source (the tool code runs inside the worker container).
set -u
export PATH="$HOME/.local/node24/bin:$PATH"
S=/mnt/c/Users/mgf/AppData/Local/Temp/claude/c--Users-mgf-dev-atoma/29b09eee-42d1-45b2-b664-321d7b10f653/scratchpad
REPO=/tmp/atoma-backup-check
ROOT=/tmp/atoma-guidance2-campaign-20260915
mkdir -p "$ROOT/state/skills" "$ROOT/state/runs" "$ROOT/workspace" "$ROOT/logs" "$ROOT/seed"

cd "$REPO" || exit 1
git checkout -q -- . && git clean -fdq
git fetch -q origin main && git checkout -q -B guidance-campaign origin/main
git apply "$S/guidance.patch" || { echo "patch failed"; exit 1; }
echo "revision: $(git rev-parse --short HEAD) + guidance patch ($(git status --short | wc -l) files)"

echo "== live containers before build: $(docker ps -q | wc -l)"
echo "== compile dist (tsc only: the worker image copies dist/tools, dist/core, dist/contracts)"
rm -rf dist && npx tsc -p tsconfig.json || { echo "tsc failed"; exit 1; }
grep -c "Two shapes are accepted" dist/tools/builtin.js
echo "== build worker image from patched dist"
docker build -q -f docker/worker.Dockerfile -t atoma-worker:latest . || { echo "docker build failed"; exit 1; }
IMAGE=$(docker image inspect atoma-worker:latest --format '{{.Id}}')
echo "image: $IMAGE $(docker image inspect atoma-worker:latest --format '{{.Created}}')"
echo "== new text inside the image:"
docker run --rm --entrypoint sh "$IMAGE" -c 'grep -c "Two shapes are accepted" /app/dist/tools/builtin.js; grep -c "SMOKE_TWO_CALL_LINES" /app/dist/contracts/probeManifest.js'

export ATOMA_MODEL_L1=sub:anthropic:haiku ATOMA_MODEL_L2=sub:anthropic:sonnet ATOMA_MODEL_L3=sub:anthropic:opus
export ATOMA_DB_PATH="$ROOT/state/atoma.db" ATOMA_SKILLS_DIR="$ROOT/state/skills" ATOMA_RUNS_DIR="$ROOT/state/runs"
export ATOMA_BUILD_WORKSPACE="$ROOT/workspace" ATOMA_BUILD_TIMEOUT_MS=300000
unset ATOMA_SEED ATOMA_BASELINE

FRESH_GOAL='Build only a single self-contained index.html, no dependencies. A simple counter displays 0 in an element with id value. A button with id increment increments it by one on each click. Use inline CSS. Verify actual browser clicks. Keep the scope minimal.'
SEEDED_GOAL='Modify the existing index.html. Preserve the working counter (#value and #increment). Add a button with id reset that sets the counter to 0. Keep the application self-contained, with no dependencies or additional files. Verify increment and reset through actual browser clicks.'

run_one() {
  local label="$1"; shift
  local log="$ROOT/logs/$label.log"
  echo "== $label: start $(date -u +%FT%TZ)"
  npx tsx src/cli/build-app.ts "$@" > "$log" 2>&1 &
  local pid=$!
  local waited=0
  while kill -0 "$pid" 2>/dev/null; do
    if grep -qE '✓ build finished|--- run failed ---|⏱ TIMEOUT after|✖ build failed|--- spawn failed ---' "$log"; then
      sleep 8
      break
    fi
    if [ "$waited" -ge 420 ]; then echo "$label: hard timeout at ${waited}s" | tee -a "$log"; break; fi
    sleep 5; waited=$((waited+5))
  done
  if kill -0 "$pid" 2>/dev/null; then
    kill -INT "$pid" 2>/dev/null
    for _ in $(seq 1 12); do kill -0 "$pid" 2>/dev/null || break; sleep 5; done
    kill -0 "$pid" 2>/dev/null && kill -TERM "$pid" 2>/dev/null
  fi
  wait "$pid" 2>/dev/null
  echo "== $label: end $(date -u +%FT%TZ) exit=$?"
  grep -E '✓ build finished|--- run failed ---|⏱ TIMEOUT after|✖ build failed|^TOTAL|ATOMA_RUN_STATS|run timeout' "$log" | head -12
}

run_one fresh --container --worker-image "$IMAGE" --clean-workspace "$FRESH_GOAL"
echo "== workspace after fresh:"; ls -la "$ROOT/workspace" | head
rm -rf "$ROOT/seed"/* && cp -a "$ROOT/workspace"/. "$ROOT/seed"/ && ls "$ROOT/seed"
sha256sum "$ROOT/seed"/index.html 2>/dev/null

run_one seeded --container --worker-image "$IMAGE" --clean-workspace --seed "$ROOT/seed" "$SEEDED_GOAL"
echo "== workspace after seeded:"; ls -la "$ROOT/workspace" | head
sha256sum "$ROOT/workspace"/index.html 2>/dev/null
echo "== traces:"; ls -la "$ROOT/state/runs"
sleep 30
echo "== containers left:"; docker ps --format '{{.Names}} {{.Image}} {{.Status}}' | head
